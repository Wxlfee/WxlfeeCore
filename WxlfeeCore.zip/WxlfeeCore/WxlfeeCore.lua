local WxlfeeCore = {}
local WxlfeeCoreMain = {}
WxlfeeCoreSettings = {}
WxlfeeCoreDRGSettings = {}
FSHAddonIcon = GetLuaModsPath().."\\WxlfeeCore\\Icons\\FSHAddonIcon.jpg"
MinaBotIcon = GetLuaModsPath().."\\WxlfeeCore\\Icons\\MinaBotIcon.png"
CasuallyACRIcon = GetLuaModsPath().."\\WxlfeeCore\\Icons\\CasuallyACRIcon.png"
WxlfeeCoreSettingsIcon = GetLuaModsPath().."\\WxlfeeCore\\Icons\\WxlfeeCore-Settings.png"
MINIONFiles = GetLuaModsPath()
WX_Version = GetLuaModsPath().."\\WxlfeeCore\\version.txt"
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .."WxlfeeCore\\Settings\\"
local ModuleSettings = ModulePath.."WxlfeeCoreSettings.lua"
local v = table.valid


WxlfeeCoreMain.GUI = {

	open = false,
	visible = true,
	name = "WxlfeeCore",
	
}

local WX_Settings = {

	wx_cAssist = false,
	wx_FG_AFK = false,
	
}

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("WxlfeeCoreSettings.lua","w")
		localfile:write(WX_Settings)
		localfile:close()
	end
end

function WXSave()
	FileSave(ModuleSettings,WX_Settings)
end

-- SHOW UP IN MINION MENU

local function CheckMenu()
    local menuiconpath = "pathtoicon"
    local Status = false
    local Menu = ml_gui.ui_mgr.menu.components
    if table.valid(Menu) then
        for i,e in pairs(Menu) do
            if (e.members ~= nil) then
                for k,v in pairs(e.members) do
                    if (v.name ~= nil and v.name == "WxlfeeCore") then
                        Status = true
                    end
                end
            end
        end
    end
    if (not Status) then
        local menuiconpath = GetLuaModsPath().."\\WxlfeeCore\\Icons\\WxlfeeLogo.png"
        local iconpath = GetLuaModsPath().."\\WxlfeeCore\\Icons\\WxlfeeLogo.png"
        ml_gui.ui_mgr:AddMember({ id = "FFXIVMINION##WxlfeeCore", name = "WxlfeeCore", onClick = function() WxlfeeCoreMain.GUI.open = not WxlfeeCoreMain.GUI.open end, tooltip = "Open WxlfeeCore", texture = menuiconpath,},"FFXIVMINION##MENU_HEADER")
        local iconpath = GetLuaModsPath().."\\WxlfeeCore\\Icons\\WxlfeeLogo.png"
        
    end
end

-- END OF MINION UI
function checkVersion()
	local file = io.open(WX_Version, "r")
	if file then
		local wx_currentVersion = file:read("*all")
		file:close()
            
		if wx_currentVersion then
			WX_Version_Text = "Version: " .. wx_currentVersion
			d(WX_Version_Text)
		else
			d("Error reading content from file 'version.txt'")
		end
	else
		d("Error opening file 'version.txt'")
	end
end


-- Load ACR

WxlfeeCore.routinePath = GetStartupPath()..[[\LuaMods\WxlfeeCore\CombatRoutines\]]

function WxlfeeCore.LoadCombatProfile(filename,alias)
	if (WxlfeeCore.ModuleFunctions and WxlfeeCore.ModuleFunctions.ReadModuleFile) then
		local fileInfo = { p = "CombatRoutines" , m = "WxlfeeCore" , f = filename }
		local fileString = WxlfeeCore.ModuleFunctions.ReadModuleFile(fileInfo)
		if (fileString) then
			local fileFunction, errorMessage = loadstring(fileString)
			if (fileFunction) then
				local ok, profileData = pcall(fileFunction)
				if (ok and profileData ~= nil) then
					ACR.AddPrivateProfile(profileData,alias)
				end
			end
		end
		filename = filename
	else
		if (filename ~= "" and FileExists(WxlfeeCore.routinePath..filename)) then
			local profileData,e = persistence.load(WxlfeeCore.routinePath..filename)
			if (ValidTable(profileData)) then
				ACR.AddPrivateProfile(profileData,alias)
			end
		end
		filename = filename
	end	
end

function CheckActiveACR()
local loadedProfile = gACRSelectedProfiles[Player.job]
if loadedProfile == nil then 
	ActiveACRname = "Invalid ACR"
	return
end
local ACRWord = "Casually"
	if string.find(loadedProfile, ACRWord) then
		ActiveACRname = gACRSelectedProfiles[Player.job]
	else
		ActiveACRname = "Invalid ACR"
	end
end

local index = index or "Main"

function FG_AFK()
local is_queuing = Duty:IsQueued()
local target = MGetTarget()
local target_npc_id = 4305183047

if Player.localmapid == 1197 then -- Pre Game Hub
	if is_queuing == false then
		if target == nil or target.id ~= target_npc_id then
			Player:MoveTo(-13.37,0.05,-37.59)
			if not Player:IsMoving() then
				d("Trying to set target")
				Player:SetTarget(target_npc_id)
			end
		elseif MGetTarget().id == target_npc_id then
			Player:Interact(target_npc_id)
			local control = GetControl("FGSEnterDialog")
			if control ~= nil then
				control:DoAction(0)
			else
				return false
			end
		end
	elseif is_queuing then
		local dutycontrol = GetControl("ContentsFinderConfirm")
		if dutycontrol ~= nil then
			dutycontrol:DoAction(8)
		else
			return false
		end
	end
		
		
elseif Player.localmapid == 1165 then
	-- Do nothing I guess as we're in game.
	local specmenu = GetControl("FGSSpectatorMenu")
	local exitmenu = GetControl("FGSExitDialog")
	if specmenu ~= nil and exitmenu == nil then
		specmenu:DoAction(4)
	end
	if exitmenu ~= nil then
		exitmenu:DoAction(0)
	end
elseif Player.localmapid == 0 or Player.localmapid == nil then
	d("[WxlfeeCore] - Map ID Invalid")
else
	ffxiv_dialog_manager.IssueNotice("WxlfeeCore - Warning", "Please move to Fall Guys Hub Area.")
	WX_Settings.wx_FG_AFK = false
end
		
	
end

-- Start Draw Main UI
Incog_CB = false
function WxlfeeCoreMain.Draw( event,ticks )
	if (WxlfeeCoreMain.GUI.open) then
		GUI:SetNextWindowSize(400,600)
		WxlfeeCoreMain.GUI.visible, WxlfeeCoreMain.GUI.open = GUI:Begin(WxlfeeCoreMain.GUI.name, WxlfeeCoreMain.GUI.open, GUI.WindowFlags_NoResize)
		CheckActiveACR()
		if (WxlfeeCoreMain.GUI.visible) then
			Incog_CB, WX_CB = GUI:Checkbox("Incognito Mode",Incog_CB)
			if GUI:IsItemHovered() then
				GUI:SetTooltip("Hides character name, mostly for taking a full screenshot without exposing your name")
			end
			if Incog_CB then
				WX_USER = "WxlfeeCore User"
			else
				WX_USER = Player.name
			end
			GUI:SameLine(150,150)
			GUI:Button("Update!",90,30)
			if GUI:IsItemHovered() then
				GUI:SetTooltip("Update WxlfeeCore!")
			end
			if GUI:IsItemClicked() then
				-- Getting the location of both lua and ps1 files
				local function getScriptDirectory()
					local scriptDir = MINIONFiles.."\\WxlfeeCore\\"
					return scriptDir or ""
				end

				-- Lua script path
				local scriptPath = getScriptDirectory()

				-- Powershell path
				local powershellScript = "test.ps1"
				local powershellScriptPath = scriptPath .. powershellScript

				-- Command this :himASS:
				local powershellCommand = string.format('powershell -NoProfile -ExecutionPolicy Bypass -File "%s"', powershellScriptPath)

				local handle = io.popen(powershellCommand, "r")
				d("[WxlfeeCore] - [Updater] - Executing Powershell command.")
				local result = handle:read("*a")
				d("[WxlfeeCore] - [Updater] - Reading data.")
				local exitCode = {handle:close()}
				d("[WxlfeeCore] - [Updater] - Closing Powershell command.")
				if exitCode then
					ffxiv_dialog_manager.IssueNotice("WxlfeeCore - Warning", "Please reload Lua to apply update changes.")
				end
			end
			if WX_Version_Text == nil then
				checkVersion()
			end
			GUI:Separator()
			GUI:Text(WX_Version_Text)
			GUI:Text("Welcome ".. WX_USER.." to WxlfeeCore!")
			GUI:Text("Active ACR: "..ActiveACRname)
			if not CasuallyVersion == nil then
				GUI:SameLine()
				GUI:Text("Version: "..CasuallyVersion)
			end				
			GUI:Spacing()
			GUI:Separator()
			GUI:Spacing()
			GUI:Text("Addons")
			GUI:Spacing()
			GUI:Separator()
			GUI:Spacing()
		-- WxlfeeCore Main Menu
		if index == "Main" then			
			GUI:SetCursorPos(35,155)
			GUI:ImageButton(1,FSHAddonIcon,140,140)
			if GUI:IsItemClicked() then
				if FishingAddonMain ~= nil then
					FishingAddonMain.GUI.open = not FishingAddonMain.GUI.open
				elseif FishingAddonMain == nil then
					ffxiv_dialog_manager.IssueNotice("WxlfeeCore - Warning", "Addon not installed.")
				end
			end
			if GUI:IsItemHovered() then
				GUI:SetTooltip("Wxlfee's Fishing Addon")
			end
			GUI:SameLine()
			GUI:SetCursorPos(220,155)
			GUI:ImageButton(1,CasuallyACRIcon,140,140)
			if GUI:IsItemClicked() then
				index = "ACRList"
			end
			if GUI:IsItemHovered() then
				GUI:SetTooltip("Casually ACR List")
			end
			GUI:SetCursorPos(35,320)
			GUI:ImageButton(1,MinaBotIcon,140,140)
			if GUI:IsItemClicked() then
				if minabotmain ~= nil then
					minabot.gui.open = not minabot.gui.open
				elseif minabotmain == nil then
					ffxiv_dialog_manager.IssueNotice("WxlfeeCore - Warning", "Addon not installed.")
				end
			end
			if GUI:IsItemHovered() then
				GUI:SetTooltip("MinaBot")
			end
			GUI:SetCursorPos(220,320)
			GUI:ImageButton(1,WxlfeeCoreSettingsIcon,140,140)
			if GUI:IsItemClicked() then
				index = "CoreSettings"
			end
		end
		-- Casually ACR List Menu
		if (index == "ACRList") then
			GUI:Button("Back",90,30)
			if GUI:IsItemClicked() then
				index = "Main"
			end
			GUI:Text("Here is the list of ACRs:")
			--DummyThiccSpacingFunction()
			-- Tanks			
			TanksHeader, tHead = GUI:CollapsingHeader("Tanks:")
			if TanksHeader then
				GUI:Indent()
				-- Dark Knight
				GUI:Text("Casually Dark Knight:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Dark Knight.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Warrior
				GUI:Text("Casually Warrior:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Warrior.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Paladin
				GUI:Text("Casually Paladin:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Paladin.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Gunbreaker
				GUI:Text("Casually Gunbreaker:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Gunbreaker.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				GUI:Unindent()
			end
			HealersHeader, hHead = GUI:CollapsingHeader("Healers:")
			if HealersHeader then
				GUI:Indent()
				-- White Mage
				GUI:Text("Casually White Mage:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually White Mage.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Astrologian
				GUI:Text("Casually Astrologian:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Astrologian.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Scholar
				GUI:Text("Casually Scholar:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Scholar.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Sage
				GUI:Text("Casually Sage:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Sage.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				GUI:Unindent()
			end
			MeleesHeader, mHead = GUI:CollapsingHeader("Melee:")
			if MeleesHeader then
				GUI:Indent()
				-- Reaper
				GUI:Text("Casually Reaper:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Reaper.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Samurai
				GUI:Text("Casually Samurai:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Samurai.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Monk
				GUI:Text("Casually Monk:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Monk.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Dragoon
				GUI:Text("Casually Dragoon:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Dragoon.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Ninja
				GUI:Text("Casually Ninja:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Ninja.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- 7.0 Melee 
				GUI:Text("Casually Was Reaper not good enough:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually ShitClass.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				GUI:Unindent()
			end
			PhysHeader, pHead = GUI:CollapsingHeader("Physical Range:")
			if PhysHeader then
				GUI:Indent()
				-- Machinist
				GUI:Text("Casually Machinist:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Machinist.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end			
				-- Bard
				GUI:Text("Casually Bard:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Bard.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Dancer
				GUI:Text("Casually Dancer:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Dancer.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				GUI:Unindent()
			end
			MagicsHeader, mgHead = GUI:CollapsingHeader("Magical Range:")
			if MagicsHeader then
				GUI:Indent()
				-- Black Mage
				GUI:Text("Casually Black Mage:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Black Mage.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Summoner
				GUI:Text("Casually Summoner:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Summoner.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- Red Mage
				GUI:Text("Casually Red Mage:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Red Mage.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				-- 7.0 Caster
				GUI:Text("Casually Dawntrail Caster:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Geomancer.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				GUI:Unindent()
			end
			MiscJOBHeader, mjHead = GUI:CollapsingHeader("Misc ACRs:")
			if MiscJOBHeader then
				GUI:Indent()
				-- Blue Mage
				GUI:Text("Casually Blue Mage:")
				GUI:SameLine()
				if (FileExists(WxlfeeCore.routinePath.."Casually Blue Mage.lua")) then
					GUI:TextColored(0.3,1,0.14,1," installed")
				else
					GUI:TextColored(1,0.2,0.2,1," not installed")
				end
				GUI:Unindent()
			end			
		end
		if index == "CoreSettings" then
			GUI:Button("Back",90,30)
			if GUI:IsItemClicked() then
				index = "Main"
			end
			CoreHeader,coreHead = GUI:CollapsingHeader("Core Settings")
				if CoreHeader then
					GUI:Indent()
					WX_Settings.wx_cAssist, cAssist = GUI:Checkbox("Custom Assist", WX_Settings.wx_cAssist)
					GUI:Unindent()
				end
			ExtraHeader,extraHead = GUI:CollapsingHeader("Extra")
				if ExtraHeader then
					GUI:Indent()
					WX_Settings.wx_FG_AFK, fgAFK = GUI:Checkbox("Fall Guys AFK", WX_Settings.wx_FG_AFK)
					if GUI:IsItemHovered() then
						GUI:SetTooltip("Auto Queues and AFKs in the Fall Guys event.")
					end
					if WX_Settings.wx_FG_AFK then
						FG_AFK()
					end
					GUI:Unindent()
				end
		end
		end
		GUI:End()
	end	
end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function WX_loadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    WX_Settings = scan(WX_Settings,tbl)
end


--End Load Machinist ACR

function WxlfeeCore.OnUpdate(event, tickcount)
	CheckActiveACR()	
end

function WxlfeeCore.OnLoad()
	checkFile()
	checkVersion()	
	WX_loadsettings(tbl)
end

RegisterEventHandler("Module.Initalize", WxlfeeCore.OnLoad)
RegisterEventHandler("Gameloop.Draw", CheckMenu, "WxlfeeCore-CheckMenu")
RegisterEventHandler("Gameloop.Draw", WxlfeeCoreMain.Draw, "WxlfeeCore.Draw")
RegisterEventHandler("Gameloop.Update", WxlfeeCore.OnUpdate, "WxlfeeCore")