local tbl = 
{
	DRK_AOE = true,
	DRK_AOEslider = 3,
	DRK_AutoVoke = false,
	DRK_BurnMP = false,
	DRK_CDs = true,
	DRK_Defensives = true,
	DRK_Interrupt = false,
	DRK_Jumps = true,
	DRK_QT_OFF_B = 0.2,
	DRK_QT_OFF_G = 0.2,
	DRK_QT_OFF_R = 0.6,
	DRK_QT_ON_B = 0.14,
	DRK_QT_ON_G = 0.55,
	DRK_QT_ON_R = 0.3,
	DRK_Reprisal = true,
	DRK_Stance = true,
	DRK_Unmend = true,
	DRK_dmindSlider = 75,
	DRK_dmissionSlider = 75,
	DRK_ldeadSlider = 10,
	DRK_oblaSlider = 85,
	DRK_rampartSlider = 80,
	DRK_repNumSlider = 3,
	DRK_swallSlider = 60,
	DRK_tbnSlider = 90,
}



return tbl