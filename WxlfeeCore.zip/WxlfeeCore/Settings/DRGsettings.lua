local tbl = 
{
	DRG_AOE = true,
	DRG_CD = true,
	DRG_DEF = true,
	DRG_HoldJump = false,
	DRG_Jump = true,
	DRG_LOTD = true,
	DRG_POS_GUI = false,
	DRG_QT_GUI = true,
	DRG_TN = false,
	DRG_bloodbathSlider = 90,
	DRG_feintSlider = 80,
	DRG_secondwindSlider = 50,
	QT_OFF_B = 0.2,
	QT_OFF_G = 0.2,
	QT_OFF_R = 0.6,
	QT_ON_B = 0.14,
	QT_ON_G = 0.55,
	QT_ON_R = 0.3,
}



return tbl