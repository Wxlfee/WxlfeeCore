local tbl = 
{
	BRD_AOE = true,
	BRD_Apex = true,
	BRD_CDs = true,
	BRD_Defensives = true,
	BRD_Dot = true,
	BRD_HB_GUI = false,
	BRD_PeloDelay = false,
	BRD_Peloton = false,
	BRD_QT_GUI = true,
	BRD_RadFin = true,
	BRD_Songs = true,
	BRD_minueSlider = 50,
	BRD_secondwindSlider = 80,
	BRD_troubSlider = 70,
	QT_OFF_B = 0.2,
	QT_OFF_G = 0.2,
	QT_OFF_R = 0.6,
	QT_ON_B = 0.14,
	QT_ON_G = 0.55,
	QT_ON_R = 0.3,
}



return tbl