local tbl = 
{
	NIN_AOE = true,
	NIN_BBSlider = 60,
	NIN_CD = true,
	NIN_DEF = true,
	NIN_FSlider = 90,
	NIN_HIDE = false,
	NIN_MUD = true,
	NIN_POS_GUI = false,
	NIN_QT_GUI = true,
	NIN_SSSlider = 65,
	NIN_SWSlider = 80,
	QT_OFF_B = 0.2,
	QT_OFF_G = 0.2,
	QT_OFF_R = 0.6,
	QT_ON_B = 0.14,
	QT_ON_G = 0.55,
	QT_ON_R = 0.3,
}



return tbl