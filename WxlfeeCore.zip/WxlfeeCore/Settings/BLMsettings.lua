local tbl = 
{
	BLM_AM = false,
	BLM_AOE = true,
	BLM_AddleSlider = 80,
	BLM_CD = true,
	BLM_DEF = true,
	BLM_DOT = true,
	BLM_ManawardSlider = 50,
	BLM_OoC_Trans = false,
	BLM_QT_GUI = true,
	BLM_QT_OFF_B = 0.2,
	BLM_QT_OFF_G = 0.2,
	BLM_QT_OFF_R = 0.6,
	BLM_QT_ON_B = 0.14,
	BLM_QT_ON_G = 0.55,
	BLM_QT_ON_R = 0.3,
	BLM_Scathe = false,
}



return tbl