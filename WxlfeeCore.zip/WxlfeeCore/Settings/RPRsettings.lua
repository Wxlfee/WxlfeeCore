local tbl = 
{
	QT_OFF_B = 0.2,
	QT_OFF_G = 0.2,
	QT_OFF_R = 0.6,
	QT_ON_B = 0.14,
	QT_ON_G = 0.55,
	QT_ON_R = 0.3,
	RPR_AOE = true,
	RPR_CD = true,
	RPR_DEF = true,
	RPR_Enshroud = true,
	RPR_Harpe = false,
	RPR_POS_GUI = false,
	RPR_QT_GUI = true,
	RPR_Soul = false,
	RPR_TN = false,
	RPR_arcSlider = 70,
	RPR_bbSlider = 80,
	RPR_feintSlider = 75,
}



return tbl