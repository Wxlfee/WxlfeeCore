local tbl = 
{
	MCH_AOE = true,
	MCH_CDs = true,
	MCH_Defensives = true,
	MCH_PeloDelay = false,
	MCH_QT_GUI = true,
	MCH_adaptqueen = false,
	MCH_aqueen = true,
	MCH_bgaugeSlider = 70,
	MCH_dismantleSlider = 90,
	MCH_hypercharge = true,
	MCH_peloton = false,
	MCH_secondwindSlider = 60,
	MCH_tactSlider = 75,
	QT_OFF_B = 0.2,
	QT_OFF_G = 0.2,
	QT_OFF_R = 0.6,
	QT_ON_B = 0.14,
	QT_ON_G = 0.55,
	QT_ON_R = 0.3,
}



return tbl