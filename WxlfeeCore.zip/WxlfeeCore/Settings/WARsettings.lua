local tbl = 
{
	WAR_AOE = true,
	WAR_AOEslider = 3,
	WAR_AutoVoke = false,
	WAR_CDs = true,
	WAR_Defensives = true,
	WAR_FastBuff = false,
	WAR_Interrupt = false,
	WAR_Jumps = true,
	WAR_QT_OFF_B = 0.2,
	WAR_QT_OFF_G = 0.2,
	WAR_QT_OFF_R = 0.6,
	WAR_QT_ON_B = 0.14,
	WAR_QT_ON_G = 0.55,
	WAR_QT_ON_R = 0.3,
	WAR_Stance = true,
	WAR_TOM = true,
	WAR_bloodSlider = 85,
	WAR_equilSlider = 60,
	WAR_holmSlider = 10,
	WAR_iRelease = true,
	WAR_rampartSlider = 80,
	WAR_repSlider = 3,
	WAR_reprisal = true,
	WAR_shakeSlider = 90,
	WAR_thrillSlider = 50,
	WAR_venSlider = 60,
}



return tbl