local tbl = 
{
	GNB_AOE = true,
	GNB_AOEslider = 3,
	GNB_AURslider = 75,
	GNB_AutoVoke = false,
	GNB_CAMOslider = 70,
	GNB_CDs = true,
	GNB_DEF = true,
	GNB_HEARTLIGHTslider = 75,
	GNB_HEARTslider = 90,
	GNB_Interrupt = false,
	GNB_Jump = true,
	GNB_LS = true,
	GNB_NEBslider = 60,
	GNB_QT_GUI = true,
	GNB_QT_OFF_B = 0.2,
	GNB_QT_OFF_G = 0.2,
	GNB_QT_OFF_R = 0.6,
	GNB_QT_ON_B = 0.14,
	GNB_QT_ON_G = 0.55,
	GNB_QT_ON_R = 0.3,
	GNB_RAMPslider = 80,
	GNB_REPslider = 3,
	GNB_SUPslider = 10,
	GNB_Stance = true,
	GNB_reprisal = true,
}



return tbl