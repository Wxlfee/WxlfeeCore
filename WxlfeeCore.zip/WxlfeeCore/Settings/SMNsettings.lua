local tbl = 
{
	QT_OFF_B = 0.2,
	QT_OFF_G = 0.2,
	QT_OFF_R = 0.6,
	QT_ON_B = 0.14,
	QT_ON_G = 0.55,
	QT_ON_R = 0.3,
	SMN_AOE = true,
	SMN_Addle_Slider = 80,
	SMN_Aegis_Slider = 90,
	SMN_CD = true,
	SMN_DEF = false,
	SMN_Jumps = true,
	SMN_Lucid_Slider = 75,
	SMN_Pets = true,
	SMN_QT_GUI = true,
	SMN_SwfitRaise = false,
	SMN_SwiftAttack = false,
	Summons = 
	{
		"Ifrit",
		"Titan",
		"Garuda",
	},
}



return tbl