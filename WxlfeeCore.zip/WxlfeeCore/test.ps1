if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
Start-Process PowerShell -Verb RunAs "-NoProfile -ExecutionPolicy Bypass -Command `"cd '$pwd'; & '$PSCommandPath';`"";
exit;
}
$scriptDirectory = $PSScriptRoot
$githubUser = "Wxlfee"
$githubRepo = "Casually-ACRs"
$githubBranch = "main"
$url2 = "https://raw.githubusercontent.com/${githubUser}/${githubRepo}/${githubBranch}/WxlfeeCore.zip"
$zipFile =  "${scriptDirectory}\WxlfeeCoreDL.zip"
$NewDest =  "${scriptDirectory}\UnZipped"
$NewDest2 =  "${scriptDirectory}\UnZipped\WxlfeeCore"


try {
	Write-Host "Attempting to download file"
	Invoke-Webrequest -Uri $url2 -OutFile $zipFile
}
catch {
    Write-Host "Error: $_"
}

try {
	Write-Host "Attempting to expand archive"
    Expand-Archive -Force -Path $zipFile -DestinationPath $NewDest
}
catch {
    Write-Host "Error: $_"
}

try {
	Write-Host "ROBO"
	robocopy /e /mov "$NewDest2"  $scriptDirectory
}
catch {
	Write-Host "Error: $_"
}

try {
	Write-Host "Remove Temp Files"
	Remove-Item -Recurse $NewDest -Force
	Remove-Item -Recurse $zipFile -Force
}
catch {
	Write-Host "Error: $_"
}