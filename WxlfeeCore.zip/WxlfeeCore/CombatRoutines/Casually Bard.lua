local brdACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .. [[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath .. [[BRDsettings.lua]]
local v = table.valid

local armslengthIcon = LuaPath.."\\WxlfeeCore\\Icons\\arm's_length.png"
local secondwindIcon = LuaPath.."\\WxlfeeCore\\Icons\\second_wind.png"
local wardenpaeanIcon = LuaPath.."\\WxlfeeCore\\Icons\\the_warden's_paean.png"
local troubadourIcon = LuaPath.."\\WxlfeeCore\\Icons\\troubadour.png"
local selectedIcon = LuaPath.."\\WxlfeeCore\\Icons\\HotbarSelected.png"

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("BRDsettings.lua","w")
		localfile:write(BRD_Settings)
		file:close()
	end
end

BRD_Settings = {
	
	BRD_QT_GUI = false,
	BRD_HB_GUI = false,
	
	BRD_PeloDelay = false,
	
	BRD_CDs = true,
	BRD_AOE = true,
	BRD_Songs = true,
	BRD_Peloton = false,
	BRD_Defensives = true,
	BRD_RadFin = true,
	BRD_Apex = true,
	BRD_Dot = true,
	BRD_troubSlider = 70,
	BRD_minueSlider = 50,
	BRD_secondwindSlider = 80,

}

--Abilities and Buffs to check CDs and all that good stuff innit.
radiantfinaleCD = ActionList:Get(1,25785)
ragingstrikesCD = ActionList:Get(1,101)
barrageCD = ActionList:Get(1,107)
battlevoiceCD = ActionList:Get(1,118)
mageballadCD = ActionList:Get(1,114)
armypaeonCD = ActionList:Get(1,116)
wandererminuetCD = ActionList:Get(1,3559)
bloodletterStacks = ActionList:Get(1,110)
armslengthCD = ActionList:Get(1,7548)
secondwindCD = ActionList:Get(1,7541)
wardenpaeanCD = ActionList:Get(1,3561)
troubadourCD = ActionList:Get(1,7405)
sidewinderCD = ActionList:Get(1,3562)


local function WXSave()
	FileSave(ModuleSettings,BRD_Settings)
end

brdACR.classes = {
    [FFXIV.JOBS.BARD] = true,
	[FFXIV.JOBS.ARCHER] = true,
} 

brdACR.GUI = {
    open = true,
    visible = true,
    name = "Casually Bard",
}

brdACR.GUIQT = {
	open = false,
	visible = true,
	name = "QuickToggles",
}

brdACR.GUIHB = {
	open = false,
	visible = true,
	name = "WX_HotBar",
}

CD = ActionList:Get(1,97)
armsLength_HB = false
secondwind_HB = false
wardenpaean_HB = false
troubadour_HB = false
HB_Active = false

brdACR.brdBuff = 
	{
		stormbite = 1201,
		causticbite = 1200,
		mageballad = 2217,
		armypaeon = 2218,
		wandererminuet = 2216,
		windbite = 129,
		venomousbite = 124,
		peloton = 1199,
		medicated = 49,
		straightshotbuff = 979,
		radiantfinale = 2722,
		ragingstrikes = 125,
		
	}
brdACR.brdSkill = 
	{
		quicknock = {106,true},
		shadowbite = {16494,true},
		ironjaws = {3560,true},
		refulgentarrow = {7409,true},
		burstshot = {16495,true},
		causticbite = {7406,true},
		stormbite = {7407,true},
		empyrealarrow = {3558,true},
		sidewinder = {3562,true},
		bloodletter = {110,true},
		rainofdeath = {117,true},
		mageballad = {114,true},
		armypaeon = {116,true},
		wandererminuet = {3559,true},
		apexarrow = {16496,true},
		pitchperfect = {7404,true},
		straightshot = {98,true},
		heavyshot = {97,true},
		windbite = {113,true},
		venomousbite = {100,true},
		blastarrow = {25784,true},
		radiantfinale = {25785,false},
		barrage = {107,false},
		ragingstrikes = {101,false},
		peloton = {7557,false},
		wandererpaean = {3561,false},
		Troubadour = {7405,false},
		natureminuet = {7408,false},
		battlevoice = {118,false},
		ladonsbite = {25783,true},
		secondwind = {7541,false},
		armslength = {7548,false},
		
	}
	

function BRDLoadColor()
	local function setColorValue(setting, trueValue, falseValue)
		if setting == true then
			return trueValue
		else
			return falseValue
		end
	end

-- PeloQTColor
BRD_Pelor = setColorValue(BRD_Settings.BRD_Peloton, 0.3, 0.6)
BRD_Pelog = setColorValue(BRD_Settings.BRD_Peloton, 0.55, 0.2)
BRD_Pelob = setColorValue(BRD_Settings.BRD_Peloton, 0.14, 0.2)
BRD_Peloa = 1

--RadFinQTColor
BRD_RadFinr = setColorValue(BRD_Settings.BRD_RadFin, 0.3, 0.6)
BRD_RadFing = setColorValue(BRD_Settings.BRD_RadFin, 0.55, 0.2)
BRD_RadFinb = setColorValue(BRD_Settings.BRD_RadFin, 0.14, 0.2)
BRD_RadFina = 1

-- ApexQTColor
BRD_Apexr = setColorValue(BRD_Settings.BRD_Apex, 0.3, 0.6)
BRD_Apexg = setColorValue(BRD_Settings.BRD_Apex, 0.55, 0.2)
BRD_Apexb = setColorValue(BRD_Settings.BRD_Apex, 0.14, 0.2)
BRD_Apexa = 1

-- SongQTColor
BRD_Songsr = setColorValue(BRD_Settings.BRD_Songs, 0.3, 0.6)
BRD_Songsg = setColorValue(BRD_Settings.BRD_Songs, 0.55, 0.2)
BRD_Songsb = setColorValue(BRD_Settings.BRD_Songs, 0.14, 0.2)
BRD_Songsa = 1

-- DOTQTColor
BRD_Dotr = setColorValue(BRD_Settings.BRD_Dot, 0.3, 0.6)
BRD_Dotg = setColorValue(BRD_Settings.BRD_Dot, 0.55, 0.2)
BRD_Dotb = setColorValue(BRD_Settings.BRD_Dot, 0.14, 0.2)
BRD_Dota = 1

--DefQTColor
BRD_DEFr = setColorValue(BRD_Settings.BRD_Defensives, 0.3, 0.6)
BRD_DEFg = setColorValue(BRD_Settings.BRD_Defensives, 0.55, 0.2)
BRD_DEFb = setColorValue(BRD_Settings.BRD_Defensives, 0.14, 0.2)
BRD_DEFa = 1

--AOEQTColor
BRD_AOEr = setColorValue(BRD_Settings.BRD_AOE, 0.3, 0.6)
BRD_AOEg = setColorValue(BRD_Settings.BRD_AOE, 0.55, 0.2)
BRD_AOEb = setColorValue(BRD_Settings.BRD_AOE, 0.14, 0.2)
BRD_AOEa = 1

--CDQTColor
BRD_CDsr = setColorValue(BRD_Settings.BRD_CDs, 0.3, 0.6)
BRD_CDsg = setColorValue(BRD_Settings.BRD_CDs, 0.55, 0.2)
BRD_CDsb = setColorValue(BRD_Settings.BRD_CDs, 0.14, 0.2)
BRD_CDsa = 1



end
-- Open Quick Toggles Func
function BRDOpenQT()
  Settings.ACR.BRDOpenQT = not Settings.ACR.BRDOpenQT
  brdACR.SaveSettings()
end


--Buttons
function BRDPeloQTfunc()
	BRD_Settings.BRD_Peloton = not BRD_Settings.BRD_Peloton
	BRD_Pelor, BRD_Pelog, BRD_Pelob =
		BRD_Settings.BRD_Peloton and 0.3 or 0.6,
		BRD_Settings.BRD_Peloton and 0.55 or 0.2,
		BRD_Settings.BRD_Peloton and 0.14 or 0.2,
	BRD_Peloa == 1
	brdACR.SaveSettings()
end

function radQTfunc()
	BRD_Settings.BRD_RadFin = not BRD_Settings.BRD_RadFin
	BRD_RadFinr, BRD_RadFing, BRD_RadFinb =
		BRD_Settings.BRD_RadFin and 0.3 or 0.6,
		BRD_Settings.BRD_RadFin and 0.55 or 0.2,
		BRD_Settings.BRD_RadFin and 0.14 or 0.2,
	BRD_RadFina == 1
	brdACR.SaveSettings()
end

function apexQTfunc()
	BRD_Settings.BRD_Apex = not BRD_Settings.BRD_Apex
	BRD_Apexr, BRD_Apexg, BRD_Apexb =
		BRD_Settings.BRD_Apex and 0.3 or 0.6,
		BRD_Settings.BRD_Apex and 0.55 or 0.2,
		BRD_Settings.BRD_Apex and 0.14 or 0.2,
	BRD_Apexa == 1
	brdACR.SaveSettings()
end

function songQTfunc()
	BRD_Settings.BRD_Songs = not BRD_Settings.BRD_Songs
	BRD_Songsr, BRD_Songsg, BRD_Songsb =
		BRD_Settings.BRD_Songs and 0.3 or 0.6,
		BRD_Settings.BRD_Songs and 0.55 or 0.2,
		BRD_Settings.BRD_Songs and 0.14 or 0.2,
	BRD_Songsa == 1
	brdACR.SaveSettings()
end

function BRDDOTQTfunc()
	BRD_Settings.BRD_Dot = not BRD_Settings.BRD_Dot
	BRD_Dotr, BRD_Dotg, BRD_Dotb =
		BRD_Settings.BRD_Dot and 0.3 or 0.6,
		BRD_Settings.BRD_Dot and 0.55 or 0.2,
		BRD_Settings.BRD_Dot and 0.14 or 0.2,
	BRD_Dota == 1
	brdACR.SaveSettings()
end

function BRDDEFQTfunc()
	BRD_Settings.BRD_Defensives = not BRD_Settings.BRD_Defensives
	BRD_DEFr, BRD_DEFg, BRD_DEFb =
		BRD_Settings.BRD_Defensives and 0.3 or 0.6,
		BRD_Settings.BRD_Defensives and 0.55 or 0.2,
		BRD_Settings.BRD_Defensives and 0.14 or 0.2,
	BRD_DEFa == 1
	brdACR.SaveSettings()
end

function BRDAOEQTfunc()
	BRD_Settings.BRD_AOE = not BRD_Settings.BRD_AOE
	BRD_AOEr, BRD_AOEg, BRD_AOEb =
		BRD_Settings.BRD_AOE and 0.3 or 0.6,
		BRD_Settings.BRD_AOE and 0.55 or 0.2,
		BRD_Settings.BRD_AOE and 0.14 or 0.2,
	BRD_AOEa == 1
	brdACR.SaveSettings()
end

function BRDCDQTfunc()
	BRD_Settings.BRD_CDs = not BRD_Settings.BRD_CDs
	BRD_CDsr, BRD_CDsg, BRD_CDsb =
		BRD_Settings.BRD_CDs and 0.3 or 0.6,
		BRD_Settings.BRD_CDs and 0.55 or 0.2,
		BRD_Settings.BRD_CDs and 0.14 or 0.2,
	BRD_CDsa == 1
	brdACR.SaveSettings()
end




function brdACR:skillID(string)
	if brdACR.brdSkill[string] ~= nil then
		return brdACR.brdSkill[string][1]
	end
end

function brdACR:LastAttackID(string)
	if brdACR:skillID(string) ~= nil then
		if Player.lastcomboid == brdACR:skillID(string) then
			return true
		end
	end
	return false
end


function brdACR:BuffActive(string)
	if brdACR.brdBuff[string] ~= nil then
		if HasBuff(Player.id,brdACR.brdBuff[string]) then
			return true
		end
	end
	return false
end

function brdACR:BuffActiveTargets(string)
	if brdACR.brdBuff[string] ~= nil then
		if HasBuff(MGetTarget().id,brdACR.brdBuff[string]) then
			return true
		end
	end
	return false
end

function brdACR:PersonalDOT()
local target = MGetTarget()
venomousbiteActive = false
venomousbiteDuration = venomousbiteDuration or 0
windbiteActive = false
windbiteDuration = windbiteDuration or 0
causticbiteActive = false
causticbiteDuration = causticbiteDuration or 0
stormbiteActive = false
stormbiteDuration = stormbiteDuration or 0

if target == nil then return false end
	if table.valid(target.buffs) then
		for _, buff in pairs(target.buffs) do
			if ((buff.id == 124) and buff.ownerid == Player.id) then
				venomousbiteActive = true
				venomousbiteDuration = buff.duration
			end
			if ((buff.id == 129) and buff.ownerid == Player.id) then
				windbiteActive = true
				windbiteDuration = buff.duration
			end
			if ((buff.id == 1200) and buff.ownerid == Player.id) then
				causticbiteActive = true
				causticbiteDuration = buff.duration
			end
			if ((buff.id == 1201) and buff.ownerid == Player.id) then
				stormbiteActive = true
				stormbiteDuration = buff.duration
			end
		end
	end
end

function brdACR:GetRagingStrikesDuration()
local player = Player
ragingstrikesBUFFCD = ragingstrikesBUFFCD or 0
ragingstrikesBUFFActive = false

	if player == nil then return false end

	if table.valid(player.buffs) then
		for i, rbuff in pairs(player.buffs) do
			if (rbuff.id == 125) then
				ragingstrikesBUFFCD = rbuff.duration
				ragingstrikesBUFFActive = true
			end
		end
	end
end

function brdACR:BuffActiveTargetsDuration(string,duration)
	if brdACR.brdBuff[string] ~= nil then
		if HasBuff(MGetTarget().id,brdACR.brdBuff[string],nil,duration) then
			return true
		end
	end
	return false
end

function BRD_check_HB()
HB_Active = false
	if armsLength_HB and not armslengthCD.isoncd then
		HB_Active = true
	elseif secondwind_HB and not secondwindCD.isoncd then
		HB_Active = true
	elseif wardenpaean_HB and not wardenpaeanCD.isoncd then
		HB_Active = true
	elseif troubadour_HB and not troubadourCD.isoncd then
		HB_Active = true
	else
		HB_Active = false
	end
end

function BRD_oGCDisReady()
	oGCDReady = false
	HB_oGCDReady = false
	CDMax = CD.cdmax
	WeaveTime = (CDMax / 5) * 2.85
	if HB_Active == false then
		if CD.cd < WeaveTime then
			oGCDReady = true
		elseif (CD.cd > WeaveTime) or (CD.cd == 0) then
			oGCDReady = false
		end
	elseif HB_Active == true then
		if CD.cd < WeaveTime then
			oGCDReady = false
			HB_oGCDReady = true
		end
	else
		oGCDReady = false
		HB_oGCDReady = false
	end
end




MultiTabs =  [[Main, Defensives, Test2, Discord]]
TabIndex = 1

function brdACR.TargetFrom(targetid)
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5,distanceto="..tostring(targetid))
	return (table.size(targets))
end

function brdACR.pelotonActive()

pelotonCounter = pelotonCounter or 1

	if Player:IsMoving() and BRD_Settings.BRD_Peloton then
		pelotonCounter = pelotonCounter + 1
	end
	if HasBuff(Player.id,1199) then
		pelotonCounter = 0
	end
	if Player.incombat then
		pelotonCounter = 0
	end
	
	
	if BRD_Settings.BRD_PeloDelay and pelotonCounter >= 10 then
		if (BRD_Settings.BRD_Peloton == true) then
			if Player:IsMoving() and not Player.incombat and not HasBuff(Player.id,1199) then
				ActionList:Get(1,7557):Cast(Player.id)
				pelotonCounter = 0
				
			end
		elseif (BRD_Settings.BRD_Peloton == false) then
			--Do Nothing
			
		end		
	elseif not BRD_Settings.BRD_PeloDelay then
		if BRD_Settings.BRD_Peloton then
			if Player:IsMoving() and not Player.incombat and not HasBuff(Player.id,1199) then
				ActionList:Get(1,7557):Cast(Player.id)
				pelotonCounter = 0
			end
		end
	end
end
 
function brdACR.setVar()
	for i,e in pairs(brdACR.brdSkill) do
		brdACR[i] = ActionList:Get(1,e[1])
		if brdACR[i] then
			if e[2] then
				brdACR[i]["isready"] = brdACR[i]:IsReady(MGetTarget().id)
			else
				brdACR[i]["isready"] = brdACR[i]:IsReady(Player)
			end
		end
	end
end

function brdACR.setVarHB()
	for i,e in pairs(brdACR.brdSkill) do
		brdACR[i] = ActionList:Get(1,e[1])
		if brdACR[i] then
			brdACR[i]["isready"] = brdACR[i]:IsReady(Player)
		end
	end
end

function brdACR.useSkill(skl,string)
	local text = (string)
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = brdACR[abil].isready
		if ACTready then
			brdACR[abil]:Cast(text.id)
			return true
		end
	end
	return false
end

function BRDLevelCheck()
currentLevel = currentLevel
	if Player.level > 51 then
		currentLevel = 3
	end
	if Player.level <= 51 and Player.level >= 40 then
		currentLevel = 2
	end
	if Player.level <= 39 then
		currentLevel = 1
	end
	return currentLevel
end


function checkBloodletterStacks()
BLStacks = BLStacks or 3
useBL = false
saveforburst = false
	if Player.level >= 84 then
		if (bloodletterStacks.cd <= 15) and not (bloodletterStacks.cd == 0) then
			BLStacks = 0
		elseif (bloodletterStacks.cd == 0) then
			BLStacks = 3
		elseif (bloodletterStacks.cd >= 30 and bloodletterStacks.cd <= 45) then
			BLStacks = 2
		elseif (bloodletterStacks.cd >= 15 and bloodletterStacks.cd <= 30) then
			BLStacks = 1
		end
	elseif Player.level <= 83 then
		if (bloodletterStacks.cd <= 15) and not (bloodletterStacks.cd == 0) then
			BLStacks = 0
		elseif (bloodletterStacks.cd == 0) then
			BLStacks = 2
		elseif (bloodletterStacks.cd >= 15 and bloodletterStacks.cd <= 30) then
			BLStacks = 1
		end
	end
	
	if brdACR:BuffActive("ragingstrikes") and (wandererminuetCD.isoncd) and (battlevoiceCD.isoncd) and (radiantfinaleCD.isoncd) then
		useBL = true
		saveforburst = false
	end
	if (not ragingstrikesCD.isoncd) or (ragingstrikesCD.isoncd and ragingstrikesCD.cd >= 110) then
		saveforburst = true
		useBL = false
	end
	if Player.level >= 84 then
		if (bloodletterStacks.cd >= 37 or bloodletterStacks.cd == 0) and not saveforburst then
			useBL = true
		end
	elseif Player.level <= 83 then
		if bloodletterStacks.cd >= 22 or bloodletterStacks.cd == 0 and not saveforburst then
			useBL = true
		end
	end

	return false
end


function BRDCheckSongs()
songOrder = songOrder or 1
songActive = false

	wx_brd_counter = wx_brd_counter or 0
	wx_brd_counter = wx_brd_counter + 1
	if wx_brd_counter > 100 then
		wx_brd_counter = 100
	end

	if Player.gauge ~= nil and Player.gauge[3] ~= 0 and (brdACR:BuffActive("wandererminuet") or brdACR:BuffActive("mageballad") or brdACR:BuffActive("armypaeon")) then
		songActive = true
	else
		songActive = false
	end
	if wx_brd_counter == 100 then
		if Player.level >= 52 and not songActive then
			if not mageballadCD.isoncd and not armypaeonCD.isoncd and not wandererminuetCD.isoncd then
				songOrder = 1
			end
		end
		if Player.level >= 40 and Player.level <= 51 and not songActive then
			if not mageballadCD.isoncd and not armypaeonCD.isoncd then
				songOrder = 1
			end
		end
		if Player.level >= 30 and Player.level <= 39 and not songActive then
			if not mageballadCD.isoncd then
				songOrder = 1
			end
		end
	end
	if (can_use_wan_min == true) then
		if Player.castinginfo.lastcastid == 116 then
			songOrder = 1
		elseif Player.castinginfo.lastcastid == 114 then
			songOrder = 3
		elseif Player.castinginfo.lastcastid == 3559 then
			songOrder = 2
		end
	end
	if (can_use_army_paeon == true) and (can_use_wan_min == false) then
		if Player.castinginfo.lastcastid == 116 then
			songOrder = 1
		elseif Player.castinginfo.lastcastid == 114 then
			songOrder = 2
		end
	end
	if (can_use_army_paeon == false) and (can_use_wan_min == false) then
		if Player.castinginfo.lastcastid == 114 then
			songOrder = 1
		end
	end
	return
end

function CheckSkillsUnlock()
local playerLevel = Player.level
local wandererminuet_id = ActionList:Get(1,3559)
local armypaeon_id = ActionList:Get(1,116)
can_use_army_paeon = false
can_use_wan_min = false

if playerLevel >= wandererminuet_id.level and QuestCompleted(1714) then
	can_use_wan_min = true
else
	can_use_wan_min = false
end

if playerLevel >= armypaeon_id.level and QuestCompleted(1087) then
	can_use_army_paeon = true
else
	can_use_army_paeon = false
end

if playerLevel == 90 then
	if radiantfinaleCD.isoncd then
		RadFinUsed = true
	elseif not radiantfinaleCD.isoncd then
		RadFinUsed = false
	end
elseif playerLevel <= 89 then
	RadFinUsed = true
end

end


function BRDPlaySongs()
	if (can_use_wan_min == true) then
		if not songActive or (Player.gauge ~= nil) then
			if (songOrder == 3 and wx_brd_counter == 100) and (Player.gauge ~= nil and Player.gauge[3] <= 12000) and brdACR.useSkill({"armypaeon"}) then
				wx_brd_counter = 0
				return true
			elseif (songOrder == 2 and wx_brd_counter == 100) and (Player.gauge ~= nil and Player.gauge[3] <= 3000) and brdACR.useSkill({"mageballad"}) then
				wx_brd_counter = 0
				return true
			elseif (songOrder == (1 or nil) and wx_brd_counter == 100) and ((Player.gauge ~= nil and Player.gauge[3] <= 3000) or brdACR:BuffActive("ragingstrikes")) and brdACR.useSkill({"wandererminuet"}) then
				wx_brd_counter = 0
				return true
			end
		end
	end
	
	if (can_use_army_paeon == true) and (can_use_wan_min == false) then
		if not songActive then
			if (songOrder == 2 and wx_brd_counter == 100) and brdACR.useSkill({"armypaeon"}) then
				wx_brd_counter = 0
				return true
			end
			if (songOrder == 1 and wx_brd_counter == 100) and brdACR.useSkill({"mageballad"}) then
				wx_brd_counter = 0
				return true
			end
		end
	end
	
	if (can_use_army_paeon == false) and (can_use_wan_min == false) then
		if not songActive then
			if (songOrder == 1 and wx_brd_counter == 100) and brdACR.useSkill({"mageballad"}) then
				wx_brd_counter = 0
				return true
			end
		end
	end
	
end


function TwoMinCheck()
TwoMinReady = false
brdACR.Is_Pooling = false
local playerLevel = Player.level


	if (not ragingstrikesCD.isoncd) or brdACR:BuffActive("ragingstrikes") then
		TwoMinReady = true
	end
	
	if ragingstrikesCD.isoncd and ragingstrikesCD.cd >= 70 then
		brdACR.Is_Pooling = true
	end
	
end

function brdACR.Cast()
    local currentTarget = MGetTarget()
	brdACR.pelotonActive()
	-- Hotbar Stuff
	brdACR.setVarHB()
	if HB_Active and armsLength_HB and HB_oGCDReady and brdACR.useSkill({"armslength"}, "Player") then
		armsLength_HB = false
		return true
	end
	
	if HB_Active and secondwind_HB and HB_oGCDReady and brdACR.useSkill({"secondwind"}, "Player") then
		secondwind_HB = false
		return true
	end
	
	if HB_Active and wardenpaean_HB and HB_oGCDReady and brdACR.useSkill({"wandererpaean"}, "Player") then
		wardenpaean_HB = false
		return true
	end
	
	if HB_Active and troubadour_HB and HB_oGCDReady and brdACR.useSkill({"Troubadour"}, "Player") then
		troubadour_HB = false
		return true
	end
	if (currentTarget == nil) then
		return false
	end
	if (currentTarget.attackable and (gStartCombat or currentTarget.incombat)) then
		brdACR.setVar()
		
		--songs gauge[3] Song Duration time left
		if (BRD_Settings.BRD_Songs) and oGCDReady then
			BRDPlaySongs()
		end
		
		--Coda stacks gauge[1] i think?
		if brdACR:BuffActive("ragingstrikes") and (wandererminuetCD.isoncd and wandererminuetCD.cd <= 110) and oGCDReady and brdACR.useSkill({"radiantfinale"}) then
			return true
		end
		if oGCDReady and brdACR.useSkill({"empyrealarrow"}) then
			return true
		end
		
		if BRD_Settings.BRD_CDs then
			--battlevoice (only used when Raging Strikes is active, why? Idk.. felt right at the time. I don't play Bard sooooo deepfry about it)
			if TwoMinReady and oGCDReady and brdACR:BuffActive("ragingstrikes") and brdACR.useSkill({"battlevoice"}, "Player") then
				return true
			end
		end
		--ogcd
		if  oGCDReady and brdACR.useSkill({"sidewinder"}) then
			return true
		end

		-- Attack Buffs
		if BRD_Settings.BRD_CDs then
			if TwoMinReady and oGCDReady and brdACR.useSkill({"ragingstrikes"}, "Player") then
				return true
			end
			
			if TwoMinReady and oGCDReady and (not brdACR:BuffActive("straightshotbuff")) and brdACR.useSkill({"barrage"}, "Player") then
				return true
			end			

		end

		--repertoire stacks gauge[2]
			--Use at 3 stacks
		if oGCDReady and (Player.gauge ~= nil) and (Player.gauge[2] == 3) and brdACR.useSkill({"pitchperfect"}) then
			return true
		end		
			--Burn remainging stack
		if oGCDReady and (Player.gauge ~= nil) and ((Player.gauge[2] > 0) and (Player.gauge[3] < 5000) ) and brdACR.useSkill({"pitchperfect"}) then
			return true
		end		

		-- big ol blaster arrow
		if  brdACR.useSkill({"blastarrow"}) then			
			return true
		end
		--gauge[4] apex+blast
		if (BRD_Settings.BRD_Apex) and (not brdACR.Is_Pooling) and (RadFinUsed) and (Player.gauge ~= nil) and (Player.gauge[4] >= 80) and brdACR.useSkill({"apexarrow"}) then
			return true
		end		

		if oGCDReady and useBL and (BRD_Settings.BRD_AOE) and (brdACR.TargetFrom(currentTarget.id) > 2) and Player.level >= 45 then
			if brdACR.useSkill({"rainofdeath"}) then
				return true
			end			
		else
			if oGCDReady and useBL and brdACR.useSkill({"bloodletter"}) then
				return true
			end					
		end
		
		if (BRD_Settings.BRD_Dot) then
			-- Refresh dot
			if causticbiteActive and stormbiteActive and ((ragingstrikesBUFFCD <= 2.5) and ragingstrikesBUFFActive) and brdACR.useSkill({"ironjaws"}) then
				return true
			end
			if windbiteActive and venomousbiteActive and ((ragingstrikesBUFFCD <= 2.5) and ragingstrikesBUFFActive) and brdACR.useSkill({"ironjaws"}) then
				return true
			end
			
			if causticbiteActive and stormbiteActive and ((causticbiteDuration <= 4) or (stormbiteDuration <= 4)) and brdACR.useSkill({"ironjaws"}) then
				return true
			end
			if windbiteActive and venomousbiteActive and ((windbiteDuration <= 4) or (venomousbiteDuration <= 4)) and brdACR.useSkill({"ironjaws"}) then
				return true
			end
			--dot
			if not causticbiteActive and brdACR.useSkill({"causticbite"}) then
				return true
			end
			if not stormbiteActive and brdACR.useSkill({"stormbite"}) then
				return true
			end
			if not venomousbiteActive and brdACR.useSkill({"venomousbite"}) then
				return true
			end
			if not windbiteActive and brdACR.useSkill({"windbite"}) then
				return true
			end
		end
		if (BRD_Settings.BRD_AOE) and (brdACR.TargetFrom(currentTarget.id) > 2) and currentTarget.distance < 12 and Player.level >= 18 then
			--AOE proc (still RNG bs)
			if brdACR.useSkill({"shadowbite"}) then
				return true
			end
			 --iron(ic) jaw proc (gamba class)
			if brdACR.useSkill({"straightshot","refulgentarrow"}) then
				return true
			end			
			--AOE
			if brdACR.useSkill({"quicknock","ladonsbite"}) then
				return true
			end			
		else
			--Use this if we get the proc :swag: (RNG BS class fr fr)
			if brdACR.useSkill({"straightshot","refulgentarrow"}) then
				return true
			end
			--main spam single
			if brdACR.useSkill({"heavyshot","burstshot"}) then
				return true
			end
		end
		
		-- Utility
		if (BRD_Settings.BRD_Defensives) then
			if (Player.hp.percent <= BRD_Settings.BRD_troubSlider) and brdACR.useSkill({"Troubadour"}, "Player") then
				return true
			end
			if (Player.hp.percent <= BRD_Settings.BRD_minueSlider) and brdACR.useSkill({"natureminuet"}, "Player") then
				return true
			end
			if (Player.hp.percent <= BRD_Settings.BRD_secondwindSlider) and brdACR.useSkill({"secondwind"}, "Player") then
				return true
			end
		end

	return false
	end
end



function brdACR.Draw()
    if (brdACR.GUI.open) then	
	brdACR.GUI.visible, brdACR.GUI.open = GUI:Begin(brdACR.GUI.name, brdACR.GUI.open, GUI.WindowFlags_NoResize)
	if ( brdACR.GUI.visible ) then         
		GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Utility",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3
		end		
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")
		end
		
		--Tabs
		
		--Main Tab 
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:BulletText("Wxlfee's Bard ACR")
				GUI:Text("1.3.1 Changelogs:")
				GUI:Text("TwoMinCheck function altered.")
				GUI:Text("Rotation optimised for TwoMin changes.")
				GUI:Text("_________________________________________________")
			end
		--Utility Tab
			if (TabIndex == 2) then				
				local trou
				GUI:Text("Troubadour")
				BRD_Settings.BRD_troubSlider, trou = GUI:SliderInt("HP%",BRD_Settings.BRD_troubSlider,0,100)
				GUI:Text("_________________________________________________")
				if (trou) then
					d(BRD_Settings.BRD_troubSlider)
					BRD_Settings.BRD_troubSlider = BRD_Settings.BRD_troubSlider
					brdACR.SaveSettings()
				end
				--
				local minue
				GUI:Text("Nature's Minuet")
				BRD_Settings.BRD_minueSlider, minue = GUI:SliderInt("HP% ",BRD_Settings.BRD_minueSlider,0,100)
				GUI:Text("_________________________________________________")
				if (minue) then
					d(BRD_Settings.BRD_minueSlider)
					BRD_Settings.BRD_minueSlider = BRD_Settings.BRD_minueSlider
					brdACR.SaveSettings()
				end
				local swind
				GUI:Text("Second Wind")
				BRD_Settings.BRD_secondwindSlider, swind = GUI:SliderInt("HP%##",BRD_Settings.BRD_secondwindSlider,0,100)
				if (swind) then
					d(BRD_Settings.BRD_secondwindSlider)
					BRD_Settings.BRD_secondwindSlider = BRD_Settings.BRD_secondwindSlider
					brdACR.SaveSettings()
				end
			end
		--Toggles
			if (TabIndex == 3) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",168,30)
				if GUI:IsItemClicked() then
					BRD_Settings.BRD_QT_GUI = not BRD_Settings.BRD_QT_GUI
					brdACR.SaveSettings()
				end
				GUI:SameLine()
				GUI:Button("Open Hotbar",168,30)
				if GUI:IsItemClicked() then
					BRD_Settings.BRD_HB_GUI = not BRD_Settings.BRD_HB_GUI
				end
				GUI:Text("_________________________________________________")
				BRD_Settings.BRD_PeloDelay, delayPelo = GUI:Checkbox("Delay Peloton: ", BRD_Settings.BRD_PeloDelay)
				if GUI:IsItemClicked() then					
					brdACR.SaveSettings()
				end
				GUI:Text("_________________________________________________")
			end
			--Discord
			if (TabIndex == 4) then
				GUI:SetWindowSize(0,0,0)				
				GUI:Text("_________________________________________________")				
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")
				end
				-- Just debugging stuff here, you don't need to worry about it :v
				GUI:Text("_________________________________________________")
				--GUI:Text("ragingstrikes buff cd: "..ragingstrikesBUFFCD)
				-- GUI:Text(songActive)
				-- GUI:Text("Song Order: ")
				-- GUI:SameLine()
				-- GUI:Text(songOrder)
				-- GUI:Text("Bloodletter CD: ")
				-- GUI:SameLine()
				-- GUI:Text(BLStacks)
				-- GUI:Text("_________________________________________________")
				-- GUI:Text("Is oGCDReady ready? ")
				-- GUI:SameLine()
				-- if oGCDReady then
					-- GUI:Text("True")
				-- elseif not oGCDReady then
					-- GUI:Text("False")
				-- end
				-- GUI:Text("_________________________________________________")
				-- GUI:Text("Is HB_Active active? ")
				-- GUI:SameLine()
				-- if HB_Active then
					-- GUI:Text("Yes")
				-- elseif not HB_Active then
					-- GUI:Text("No")
				-- end
				-- GUI:Text("_________________________________________________")
			end
			
        end
        GUI:End()
		-- Quick Toggles Menu
		if (BRD_Settings.BRD_QT_GUI) then
		local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
			brdACR.GUIQT.visible, brdACR.GUIQT.open = GUI:Begin(brdACR.GUIQT.name, brdACR.GUIQT.open, flags2)
				if (brdACR.GUIQT.visible) then
					GUI:SetWindowSize(0,0,0)
					GUI:PushStyleColor(GUI.Col_Button, BRD_CDsr,BRD_CDsg,BRD_CDsb,BRD_CDsa)
					BRDCDButton = GUI:Button("CD",90,30)
					GUI:PopStyleColor()
					if GUI:IsItemClicked() then
						BRDCDQTfunc()
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, BRD_AOEr,BRD_AOEg,BRD_AOEb,BRD_AOEa)
					BRDAOEButton = GUI:Button("AOE",90,30)
					GUI:PopStyleColor()
					if GUI:IsItemClicked() then
						BRDAOEQTfunc()
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, BRD_DEFr,BRD_DEFg,BRD_DEFb,BRD_DEFa)
					BRDdefensivesButton = GUI:Button("Defensives",90,30)
					GUI:PopStyleColor()
					if GUI:IsItemClicked() then
						BRDDEFQTfunc()
					end
					GUI:PushStyleColor(GUI.Col_Button, BRD_Pelor,BRD_Pelog,BRD_Pelob,BRD_Peloa)					
					peloButton = GUI:Button("Peloton",90,30)	
					GUI:PopStyleColor()
					if GUI:IsItemClicked() then
						BRDPeloQTfunc()
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, BRD_RadFinr,BRD_RadFing,BRD_RadFinb,BRD_RadFina)
					RadiantButton = GUI:Button("R. Finale",90,30)
					GUI:PopStyleColor()
					if GUI:IsItemClicked() then
						radQTfunc()
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, BRD_Apexr,BRD_Apexg,BRD_Apexb,BRD_Apexa)
					ApexButton = GUI:Button("Apex Arrow",90,30)
					GUI:PopStyleColor()
					if GUI:IsItemClicked() then
						apexQTfunc()
					end
					GUI:PushStyleColor(GUI.Col_Button, BRD_Songsr,BRD_Songsg,BRD_Songsb,BRD_Songsa)
					SongsButton = GUI:Button("Songs",90,30)
					GUI:PopStyleColor()
					if GUI:IsItemClicked() then
						songQTfunc()
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, BRD_Dotr,BRD_Dotg,BRD_Dotb,BRD_Dota)
					BRDDOTButton = GUI:Button("DOT",90,30)
					GUI:PopStyleColor()
					if GUI:IsItemClicked() then
						BRDDOTQTfunc()
					end
				end
			GUI:End()
		end
			-- Hotbar Menu
			if (BRD_Settings.BRD_HB_GUI) then
			local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
				brdACR.GUIHB.visible, brdACR.GUIHB.open = GUI:Begin(brdACR.GUIHB.name, brdACR.GUIHB.open, flags2)
					if (brdACR.GUIHB.visible) then
						GUI:SetWindowSize(0,0,0)
						GUI:PushStyleColor(GUI.Col_Button,1,1,1,0)
						GUI:PushStyleColor(GUI.Col_ButtonHovered,1,1,1,0)
						GUI:PushStyleColor(GUI.Col_ButtonActive,1,1,1,0)
						-- Arm's Length
						GUI:SetCursorPos(8,8)
						HB_ArmLength_1 = GUI:ImageButton(1,armslengthIcon,50,50)
						if GUI:IsItemClicked() then
							armsLength_HB = not armsLength_HB
						end
						if armsLength_HB then						
							GUI:SetItemAllowOverlap()
							GUI:SetCursorPos(12,12)
							SelectedIcon_AL_HB = GUI:Image(selectedIcon,50,50)
						end
						GUI:NewLine()
						-- Second Wind
						GUI:SetCursorPos(65,8)
						HB_Secondwind_2 = GUI:ImageButton(1,secondwindIcon,50,50)
						if GUI:IsItemClicked() then
							secondwind_HB = not secondwind_HB
						end
						if secondwind_HB then
							GUI:SetItemAllowOverlap()
							GUI:SetCursorPos(69,12)
							SelectedIcon_SW_HB = GUI:Image(selectedIcon,50,50)
						end
						GUI:NewLine()
						-- Warden's Paean
						GUI:SetCursorPos(8,65)
						HB_WardenPaean_3 = GUI:ImageButton(1,wardenpaeanIcon,50,50)
						if GUI:IsItemClicked() then
							wardenpaean_HB = not wardenpaean_HB
						end
						if wardenpaean_HB then
							GUI:SetItemAllowOverlap()
							GUI:SetCursorPos(12,69)
							SelectedIcon_WP_HB = GUI:Image(selectedIcon,50,50)
						end
						GUI:NewLine()
						-- Troubadour
						GUI:SetCursorPos(65,65)
						HB_Troubadour_4 = GUI:ImageButton(1,troubadourIcon,50,50)
						if GUI:IsItemClicked() then
							troubadour_HB = not troubadour_HB
						end
						if troubadour_HB then
							GUI:SetItemAllowOverlap()
							GUI:SetCursorPos(69,69)
							SelectedIcon_Tr_HB = GUI:Image(selectedIcon,50,50)
						end
						GUI:PopStyleColor(3)
					end
				GUI:End()
			end
    end	
end
 
function brdACR.OnOpen()
    brdACR.GUI.open = true
end

function brdACR.QTOnOpen()
	brdACR.GUIQT.open = true
end


function brdACR.SaveSettings()
	d("[WxlfeeCore] Settings have been saved.")
	WXSave()

end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function BRDloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    BRD_Settings = scan(BRD_Settings,tbl)
end

function brdACR.LoadSettings()
	BRDloadsettings(tbl)	
end
 
function brdACR.OnLoad()
	checkFile()
    TabIndex = 1
	brdACR.LoadSettings()
	BRDLoadColor()
	
end
 
function brdACR.OnClick(mouse,shiftState,controlState,altState,entity)
 
end
 
function brdACR.OnUpdate(event, tickcount)	
	BRDLevelCheck()
	BRD_check_HB()
	BRD_oGCDisReady()
	TwoMinCheck()
	BRDCheckSongs()
	CheckSkillsUnlock()
	brdACR:PersonalDOT()
	checkBloodletterStacks()
	brdACR:GetRagingStrikesDuration()
end
 
return brdACR
