local blmACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .. [[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath .. [[BLMsettings.lua]]
local v = table.valid

local AM_icon = LuaPath..[[WxlfeeCore\\Icons\\aetherial_manipulation.png]]

local JobtoRoleMap = {
    [0] = 1, --"Adventurer",
    [1] = 1, --"Gladiator",
    [2] = 2, --"Pugilist",
    [3] = 1, --"Marauder",
    [4] = 2, --"Lancer",
    [5] = 3, --"Archer",
    [6] = 4, --"Conjurer",
    [7] = 3, --"Thaumaturge",
    [8] = 9, --"Carpenter",
    [9] = 9, --"Blacksmith",
    [10] = 9, --"Armorer",
    [11] = 9, --"Goldsmith",
    [12] = 9, --"Leatherworker",
    [13] = 9, --"Weaver",
    [14] = 9, --"Alchemist",
    [15] = 9, --"Culinarian",
    [16] = 10, --"Miner",
    [17] = 10, --"Botanist",
    [18] = 10, --"Fisher",
    [19] = 1, --"Paladin",
    [20] = 2, --"Monk",
    [21] = 1, --"Warrior",
    [22] = 2, --"Dragoon",
    [23] = 3, --"Bard",
    [24] = 4, --"White Mage",
    [25] = 3, --"Black Mage",
    [26] = 3, --"Arcanist",
    [27] = 3, --"Summoner",
    [28] = 4, --"Scholar",
    [29] = 2, --"Rogue",
    [30] = 2, --"Ninja",
    [31] = 3, --"Machinist",
    [32] = 1, --"Dark Knight",
    [33] = 4, --"Astrologian",
    [34] = 2, --"Samurai",
    [35] = 3, --"Red Mage",
    [36] = 7, --"Blue Mage",
    [37] = 1, --"Gunbreaker",
    [38] = 3, --"Dancer",
    [39] = 2, --"Reaper",
    [40] = 4, --"Sage",
    [9999] = 99, --"None",
}

local function checkFile()
local localfile = ModuleSettings
if localfile == nil then
	localfile = io.open("BLMsettings.lua","w")
	localfile:write(BLM_Settings)
	file:close()
end
end

local BLM_Settings = {
	BLM_QT_GUI = false,
	
	BLM_CD = true,
	BLM_AOE = true,
	BLM_DEF = true,
	BLM_OoC_Trans = false,
	BLM_DOT = true,
	BLM_AM = false,
	BLM_Scathe = false,
	
	BLM_QT_ON_R = 0.3,
	BLM_QT_ON_G = 0.55,
	BLM_QT_ON_B = 0.14,
	
	BLM_QT_OFF_R = 0.6,
	BLM_QT_OFF_G = 0.2,
	BLM_QT_OFF_B = 0.2,
	
	BLM_AddleSlider = 80,
	BLM_ManawardSlider = 50,
}

local function WXSave()
	FileSave(ModuleSettings,BLM_Settings)
end

blmACR.classes = {
	[FFXIV.JOBS.THAUMATURGE] = true,
	[FFXIV.JOBS.BLACKMAGE] = true,
}

blmACR.GUI = {
	open = true,
	visible = true,
	name = "Casually Black Mage",
}

blmACR.GUIQT = {
	open = false,
	visible = true,
	name = "WX_QuickToggles",
}

blmACR.GUIAM = {
	open = false,
	visible = true,
	name = "WX_BLM_AetherialManipulation"
}

-- Gaugetest[9] Polyglussy timer - Let it cap at 2 then use one Polyglussy if timer sub 5s to prevent overcap.
-- Gauge[5] Polyglussy charges
-- Gauge[3] Possibly connected to Paradox?
-- Gaugetest[6] Connected to Umbra Soul stacks

CD = ActionList:Get(1,141)

blmACR.blmBuff = 
	{
	firestarter = 165,
	thundercloud = 164,
	swiftcast = 167,
	triplecast = 1211,
	leylines = 737,
	sharpcast = 867,
	}

blmACR.blmSkill =
	{
	fire = {141,true},
	blizzard = {142,true},
	transpose = {149,false},
	thunder = {144,true},
	blizzard2 = {25793,true},
	fire2 = {147,true},
	scathe = {156,true},
	thunder2 = {7447,true},
	fire3 = {152,true},
	blizzard3 = {154,true},
	thunder3 = {153,true},
	flare = {162,true}, -- Dump remaining mana
	highfire2 = {25794,true}, -- Upgraded AOE
	highblizzard2 = {25795,true}, -- Upgraded AOE
	freeze = {159,true}, -- Grants 3 Umbral Hearts - Requires Ice Mode
	xenoglossy = {16507,true}, -- Poly Single
	foul = {7422,true}, -- Poly AOE
	despair = {16505,true},
	thunder4 = {7420,true},
	fire4 = {3577,true},
	blizzard4 = {3576,true},
	umbralsoul = {16506,false},
	paradox = {25797,true},
	leylines = {3573,false},
	betweenthelines = {7419,false},
	
	
	
	addle = {7560,true},
	luciddreaming = {7562,false},
	manaward = {157,false},
	manafont = {158,false},
	swiftcast = {7561,false},
	triplecast = {7421,false},
	sharpcast = {3574,false},
	amplifier = {25796,false},
	}


function BLMOpenQT()
	BLM_Settings.BLM_QT_GUI = not BLM_Settings.BLM_QT_GUI
	blmACR.SaveSettings()
end

function BLMLoadQTColor()
local function setColorValue(setting, trueValue, falseValue)
	if setting == true then
		return trueValue
	else
		return falseValue
	end
end

-- CD Color
BLMCDr = setColorValue(BLM_Settings.BLM_CD, BLM_Settings.BLM_QT_ON_R, BLM_Settings.BLM_QT_OFF_R)
BLMCDg = setColorValue(BLM_Settings.BLM_CD, BLM_Settings.BLM_QT_ON_G, BLM_Settings.BLM_QT_OFF_G)
BLMCDb = setColorValue(BLM_Settings.BLM_CD, BLM_Settings.BLM_QT_ON_B, BLM_Settings.BLM_QT_OFF_B)
BLMCDa = 1

-- AOE Color
BLMAOEr = setColorValue(BLM_Settings.BLM_AOE, BLM_Settings.BLM_QT_ON_R, BLM_Settings.BLM_QT_OFF_R)
BLMAOEg = setColorValue(BLM_Settings.BLM_AOE, BLM_Settings.BLM_QT_ON_G, BLM_Settings.BLM_QT_OFF_G)
BLMAOEb = setColorValue(BLM_Settings.BLM_AOE, BLM_Settings.BLM_QT_ON_B, BLM_Settings.BLM_QT_OFF_B)
BLMAOEa = 1

-- DEF Color
BLMDEFr = setColorValue(BLM_Settings.BLM_DEF, BLM_Settings.BLM_QT_ON_R, BLM_Settings.BLM_QT_OFF_R)
BLMDEFg = setColorValue(BLM_Settings.BLM_DEF, BLM_Settings.BLM_QT_ON_G, BLM_Settings.BLM_QT_OFF_G)
BLMDEFb = setColorValue(BLM_Settings.BLM_DEF, BLM_Settings.BLM_QT_ON_B, BLM_Settings.BLM_QT_OFF_B)
BLMDEFa = 1

-- OoC Trans Color
BLMTRANSr = setColorValue(BLM_Settings.BLM_OoC_Trans, BLM_Settings.BLM_QT_ON_R, BLM_Settings.BLM_QT_OFF_R)
BLMTRANSg = setColorValue(BLM_Settings.BLM_OoC_Trans,BLM_Settings.BLM_QT_ON_G, BLM_Settings.BLM_QT_OFF_G)
BLMTRANSb = setColorValue(BLM_Settings.BLM_OoC_Trans, BLM_Settings.BLM_QT_ON_B, BLM_Settings.BLM_QT_OFF_B)
BLMTRANSa = 1

-- DOT Color
BLMDOTr = setColorValue(BLM_Settings.BLM_DOT, BLM_Settings.BLM_QT_ON_R, BLM_Settings.BLM_QT_OFF_R)
BLMDOTg = setColorValue(BLM_Settings.BLM_DOT, BLM_Settings.BLM_QT_ON_G, BLM_Settings.BLM_QT_OFF_G)
BLMDOTb = setColorValue(BLM_Settings.BLM_DOT, BLM_Settings.BLM_QT_ON_B, BLM_Settings.BLM_QT_OFF_B)
BLMDOTa = 1

end

function BLMCDQTfunc()
	BLM_Settings.BLM_CD = not BLM_Settings.BLM_CD
	blmACR.SaveSettings()
end

function BLMAOEQTfunc()
	BLM_Settings.BLM_AOE = not BLM_Settings.BLM_AOE
	blmACR.SaveSettings()
end

function BLMDEFQTfunc()
	BLM_Settings.BLM_DEF = not BLM_Settings.BLM_DEF
	blmACR.SaveSettings()
end

function BLMOoCTransQTfunc()
	BLM_Settings.BLM_OoC_Trans = not BLM_Settings.BLM_OoC_Trans
	blmACR.SaveSettings()
end

function BLMDOTQTfunc()
	BLM_Settings.BLM_DOT = not BLM_Settings.BLM_DOT
	blmACR.SaveSettings()
end

function blmACR:skillID(string)
	if blmACR.blmSkill[string] ~= nil then
		return blmACR.blmSkill[string][1]
	end
end

function blmACR:LastAttackID(string)
	if blmACR:skillID(string) ~= nil then
		if Player.lastcomboid == blmACR:skillID(string) then
			return true
		end
	end
	return false
end

function blmACR:BuffActive(string)
	if blmACR.blmBuff[string] ~= nil then
		if HasBuff(Player.id,blmACR.blmBuff[string]) then
			return true
		end
	end
	return false
end

TabIndex = 1

function blmACR.TargetFrom(entity)
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5,distanceto="..tostring(entity))
	return (table.size(targets))
end

function blmACR.setVar()
	for i,e in pairs(blmACR.blmSkill) do
		blmACR[i] = ActionList:Get(1,e[1])
		if blmACR[i] then
			if e[2] then
				blmACR[i]["isready"] = blmACR[i]:IsReady(MGetTarget().id) else blmACR[i]["isready"] = blmACR[i]:IsReady(Player)
			end
		end
	end
end

function IsPlayerCasting()
	return Player.castinginfo.castinginfo ~= 0
end

function blmACR.setVarNoTarget()
	for i,e in pairs(blmACR.blmSkill) do
		blmACR[i] = ActionList:Get(1,e[1])
		if blmACR[i] then
			blmACR[i]["isready"] = blmACR[i]:IsReady(Player)
		end
	end
end

function blmACR.useSkill(skl,string)
	local text = (string)
	local ReadyCast = (CD.recasttime/5)*4.25
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = blmACR[abil].isready
		if ACTready then
			blmACR[abil]:Cast(text.id)
			--d("Casting:"..blmACR[abil].name)
			return true
		end
	end
	return false
end

function blmACR_oGCDReady()
	oGCDisReady = false
	WeaveTime = (CD.cdmax/5)*2.25
	CDMax = CD.cdmax
		if CD.cd < WeaveTime then
			oGCDisReady = true
		elseif (CD.cd > WeaveTime) or (CD.cd == 0) then
			oGCDisReady = false
		end
end

function BLM_CD_Check()
local playerLevel = Player.level


if Player.gauge[2] > 0 then
	BLM_Fire_Mode = true
	BLM_Ice_Mode = false
elseif Player.gauge[2] < 0 then
	BLM_Fire_Mode = false
	BLM_Ice_Mode = true
end

end

function BLM_MoveCheck()
BLM_Is_Moving = false

if Player:IsMoving() then
	BLM_Is_Moving = true
end
if blmACR:BuffActive("triplecast") then
	BLM_Is_Moving = false
end
if blmACR:BuffActive("swiftcast") then
	BLM_Is_Moving = false
end
return BLM_Is_Moving
end

function BLM_Check_DOT()
local target = MGetTarget()
thunderActive = false
thunderDuration = thunderDuration or 0
BLM_Use_Dot = false

	if target == nil then return false end

	if table.valid(target.buffs) then
		for _, buff in pairs(target.buffs) do
			-- Thunder 1
			if ((buff.id == 161) and buff.ownerid == Player.id) then
				thunderActive = true				
				thunderDuration = buff.duration
			elseif ((buff.id == 162) and buff.ownerid == Player.id) then
				thunderActive = true
				thunderDuration = buff.duration
			elseif ((buff.id == 163) and buff.ownerid == Player.id) then
				thunderActive = true
				thunderDuration = buff.duration
			end
		end
	end
	
	if not thunderActive then
		BLM_Use_Dot = true
	end
	if thunderActive and thunderDuration <= 5 then
		BLM_Use_Dot = true
	end
	if Player.castinginfo.lastcastid == 144 then
		BLM_Use_Dot = false
	elseif Player.castinginfo.lastcastid == 153 then
		BLM_Use_Dot = false
	elseif Player.castinginfo.lastcastid == 7447 then
		BLM_Use_Dot = false
	end
	
	BLM_Cast_Timer = BLM_Cast_Timer or 0
	BLM_Cast_Timer = BLM_Cast_Timer + 1
	
	if BLM_Cast_Timer >= 25 then
		BLM_Can_Cast = true
	else
		BLM_Can_Cast = false
	end
	
	if Player.castinginfo.lastcastid == 149 and Player.castinginfo.timesincecast == 0 then
		BLM_Cast_Timer = 0
	end
	
end

function BLM_Check_Quest_Unlock()

if QuestCompleted(350) and Player.level >= 15 then
	BLM_Can_Use_Scathe = true
else
	BLM_Can_Use_Scathe = false
end

if QuestCompleted(1680) then
	BLM_Can_Use_Sharpcast = true
else
	BLM_Can_Use_Sharpcast = false
end

end





function DrawPartyBox()
local PTB = GetControlByName("_PartyList")

local function HealerCount(excludeself)
	local cplist = EntityList.crossworldparty
	local nplist = EntityList.myparty
	local dslist = EntityList("chartype=9,distance2d=24")
	local partysize = 0
	local ret = {}
	if (TableSize(nplist)>0) then
		for _,e in pairs(nplist) do
			if (JobtoRoleMap[e.job] == 4) then
				if (e.id ~= Player.id or e.id == Player.id and not excludeself) then
					partysize = partysize +1
					ret[#ret+1] = {
						id = e.id,
						job = e.job,
						name = e.name,
						}
				end
			end
		end
	elseif(TableSize(cplist) > 0) then
		for _,e in pairs(cplist) do
			if (JobtoRoleMap[e.job] == 4) then
				if (e.id ~= Player.id or e.id == Player.id and not excludeself) then
					partysize = partysize +1
					ret[#ret+1] = {
						id = e.id,
						job = e.job,
						name = e.name,
						}
				end
			end
		end
	elseif(TableSize(dslist) > 0) then
		for _,e in pairs(dslist) do
			if (JobtoRoleMap[e.job] == 4) then
				if (e.id ~= Player.id or e.id == Player.id and not excludeself) then
					partysize = partysize +1
					ret[#ret+1] = {
						id = e.id,
						job = e.job,
						name = e.name,
						}
				end
			end
		end
	end
	return partysize, ret
end	

local function TankCount(excludeself)
local cplist = EntityList.crossworldparty
local nplist = EntityList.myparty
local dslist = EntityList("chartype=9,distance2d=24")
local partysize = 0
local ret = {}
	if (TableSize(nplist)>0) then
		for _,e in pairs(nplist) do
			if (JobtoRoleMap[e.job] == 1) then
				if (e.id ~= Player.id or e.id == Player.id and not excludeself) then
					partysize = partysize +1
					ret[#ret+1] = {
						id = e.id,
						job = e.job,
						name = e.name,
						}
				end				
			end
		end
	elseif(TableSize(cplist) > 0) then
		for _,e in pairs(cplist) do
			if (JobtoRoleMap[e.job] == 1) then
				if (e.id ~= Player.id or e.id == Player.id and not excludeself) then
					partysize = partysize +1
					ret[#ret+1] = {
						id = e.id,
						job = e.job,
						name = e.name,
						}
				end					
			end
		end
	elseif(TableSize(dslist) > 0) then
		for _,e in pairs(dslist) do
			if (JobtoRoleMap[e.job] == 1) then
				if (e.id ~= Player.id or e.id == Player.id and not excludeself) then
					partysize = partysize +1
					ret[#ret+1] = {
						id = e.id,
						job = e.job,
						name = e.name,
						}
				end
			end
		end
	end
	return partysize, ret
end

local function PartySize()
local cplist = EntityList.crossworldparty
local nplist = EntityList.myparty
local dslist = EntityList("chartype=9,distance2d=24")
local partysize = 0
	if (TableSize(nplist)>0) then
		for _,e in pairs(nplist) do
			partysize = partysize +1
		end
	elseif(TableSize(cplist) > 0) then
		for _,e in pairs(cplist) do
			partysize = partysize +1
		end
	elseif(TableSize(dslist) > 0) then
		for _,e in pairs(dslist) do
			partysize = partysize +1
		end
	end
	if (TableSize(dslist)>0) then
		return partysize +1
	end
	return partysize
end	

local function DPSCount(excludeself)
local cplist = EntityList.crossworldparty
local nplist = EntityList.myparty
local dslist = EntityList("chartype=9,distance2d=24")
local partysize = 0
local ret = {}
	if (TableSize(nplist)>0) then
		for _,e in pairs(nplist) do
			if (JobtoRoleMap[e.job] ~= 1 and (JobtoRoleMap[e.job] ~= 4)) then
				if (e.id ~= Player.id or e.id == Player.id and not excludeself) then
					partysize = partysize +1
					ret[#ret+1] = {
						id = e.id,
						job = e.job,
						name = e.name,
						}
				end
			end
		end
	elseif(TableSize(cplist) > 0) then
		for _,e in pairs(cplist) do
			if (JobtoRoleMap[e.job] ~= 1 and (JobtoRoleMap[e.job] ~= 4)) then
				if (e.id ~= Player.id or e.id == Player.id and not excludeself) then
					partysize = partysize +1
					ret[#ret+1] = {
						id = e.id,
						job = e.job,
						name = e.name,
						}
				end				
			end
		end
	elseif(TableSize(dslist) > 0) then
		for _,e in pairs(dslist) do
			if (JobtoRoleMap[e.job] ~= 1 and (JobtoRoleMap[e.job] ~= 4)) then
				if (e.id ~= Player.id or e.id == Player.id and not excludeself) then
					partysize = partysize +1
					ret[#ret+1] = {
						id = e.id,
						job = e.job,
						name = e.name,
						}
				end				
			end
		end
	end
	return partysize, ret
end
		
		
if (PTB) then
local x,y = PTB:GetXY()
local scale = PTB:GetScale()
local mouseposX,mouseposY = GUI:GetMousePos( )
	if (
		mouseposX>x and mouseposX<((x*scale)+300) 
		and mouseposY>y and mouseposY<((y*scale)+370)
		) then	
				
		local wx_partysize = PartySize()
		local healercount, healers = HealerCount(true)
		local tankcount, tanks = TankCount(true)
		local dpscount, dpss = DPSCount(true)

		local colors = {
			[1] = GUI:ColorConvertFloat4ToU32(0.1,0.1,0.5,1),
			[2] = GUI:ColorConvertFloat4ToU32(0.5,0.1,0.1,1),
			[3] = GUI:ColorConvertFloat4ToU32(0.1,0.5,0.1,1),
			[4] = GUI:ColorConvertFloat4ToU32(0.1,0.5,0.1,1),
			}
		local function customSort(tbl1, tbl2)
			if tbl1.job < tbl2.job then
				return true
			elseif tbl1.job == tbl2.job then
				return tbl1.id > tbl2.id
			end
			return false
		end		
		
local function checkRoles(tankcount, healercount, i)
local name = "test"

	if (i == 1) then
		if (Player.role == 1) then
			return {name = Player.name, role = 1}
		elseif (Player.role == 4) then
			return {name = Player.name, role = 4}
		else
			return {name = Player.name, role = 2}
		end
	end
	local reducei = i -1
	if (reducei <= tankcount) then
		table.sort(tanks, customSort)
		return {name = tanks[reducei].name, role = 1, id = tanks[reducei].id}
	elseif (reducei <= healercount + tankcount) then
		table.sort(healers, customSort)
		local newi = reducei - tankcount
		return {name = healers[newi].name, role = 4, id = healers[newi].id}
	elseif (reducei > healercount and reducei > tankcount) then
		local newi = reducei - healercount - tankcount
		d(newi)
		table.sort(dpss, customSort)
		return {name = dpss[newi].name, role = 2, id = dpss[newi].id}
	elseif (reducei > healercount and reducei > tankcount) then		
		local newi = reducei - healercount - tankcount
		local dpscount, dpss = DPSCount(true)
		table.sort(dpss, customSort)
		d(newi)
		return {name = dpss[newi].name, role = 2, id = dpss[newi].id}		
	end
end
	for i=1, wx_partysize do
		local psscale = 1
		if (i>1) then
			psscale = (i-1) * (40*scale)
		end
		if (x and y and scale) then
			local x2 = x + (45*scale)
			local y1 = y+(40*scale)+psscale
			local y2 = y+(80*scale)+psscale
			if (mouseposY>y1 and mouseposY< y2) then
				local ddddata = checkRoles(tankcount, healercount, i)
				--d(DPSCount())				
				if GUI:FreeImageButton(1,AM_icon,x2+160, y+(40*scale)+psscale,35,35) then
					if ddddata.name == Player.name then
						if not HasBuff(Player.id,737) then
							ActionList:Get(1,3573):Cast() -- Cast Leylines
						else							
							SendTextCommand('/ac "Between The Lines" ')-- Cast Between The Lines
						end
					else
						ActionList:Get(1,155):Cast(ddddata.id)
						d("Using Aetherial Manipulation - Target: "..ddddata.name)
					end					
				end
				if (GUI:FreeButton( ddddata.name, x2, y+(40*scale)+psscale, 160, 40)) then
					if ddddata.name == Player.name then
						if not HasBuff(Player.id,737) then
							ActionList:Get(1,3573):Cast() -- Cast Leylines
						else
							SendTextCommand('/ac "Between The Lines" ') -- Cast Between The Lines
						end
					else
						ActionList:Get(1,155):Cast(ddddata.id)
						d("Using Aetherial Manipulation - Target: "..ddddata.name)
					end	
				end
				GUI:AddLine( x2, y+(40*scale)+psscale, x2+(200*scale), y+(40*scale)+psscale, colors[ddddata.role], 1)
				GUI:AddLine( x2, y+(40*scale)+psscale, x2, y+(80*scale)+psscale, colors[ddddata.role], 1)
				GUI:AddLine( x2+(200*scale), y+(40*scale)+psscale, x2+(200*scale), y+(80*scale)+psscale, colors[ddddata.role], 1)
				GUI:AddLine( x2, y+(80*scale)+psscale, x2+(200*scale), y+(80*scale)+psscale, colors[ddddata.role], 1)

			end
			end
		end
	end
end
end








	


function blmACR.Cast()
	local currentTarget = MGetTarget()	
	blmACR.setVarNoTarget()
	
	if BLM_Settings.BLM_OoC_Trans and (currentTarget == nil or not Player.incombat) then
		if Player.gauge[4] <= 5000 and Player.gauge[4] ~= 0 then		
			if blmACR.useSkill({"transpose"},"Player") then
				return true
			end
		end
		if BLM_Ice_Mode and Player.gauge[4] > 5000 then
			if blmACR.useSkill({"umbralsoul"},"Player") then
				return true
			end
		end
	end
	
	if (currentTarget == nil) or (not currentTarget.attackable) then
		ActionList:StopCasting()
		return false
	end
	local targetRadius = currentTarget.hitradius + 2
	if currentTarget.dead then ActionList:StopCasting() end
	if (currentTarget.attackable and (gStartCombat or currentTarget.incombat)) then		
		blmACR.setVar()	
		
		if BLM_Settings.BLM_DEF then
			if (Player.hp.percent <= BLM_Settings.BLM_AddleSlider) and blmACR.useSkill({"addle"}) then
				return true
			end
			if (Player.hp.percent <= BLM_Settings.BLM_ManawardSlider) and blmACR.useSkill({"manaward"},"Player") then
				return true
			end		
		end
		
		if BLM_Settings.BLM_CD then
			if BLM_Can_Use_Sharpcast and (not blmACR:BuffActive("sharpcast")) and blmACR.useSkill({"sharpcast"}) then
				return true
			end
		end
		
		if Player.gauge[5] == 2 and Player.gaugetest[9] <= 10000 and Player.gauge[4] >= 4000 then
			if (BLM_Settings.BLM_AOE or Player.level <= 79) and Player.level >= 70 and blmACR.TargetFrom(currentTarget.id) >= 2 then
				if blmACR.useSkill({"foul"}) then
					return true
				end
			else
				if Player.level >= 80 and blmACR.useSkill({"xenoglossy"}) then
					return true
				end
			end
		end
		
		if BLM_Is_Moving and Player.gauge[5] >= 1 then
			if BLM_Settings.BLM_AOE and Player.level >= 70 and blmACR.TargetFrom(currentTarget.id) >= 2 then
				if blmACR.useSkill({"foul"}) then
					return true
				end
			else
				if Player.level >= 80 and blmACR.useSkill({"xenoglossy"}) then
					return true
				end
			end
		end
		
		if (not BLM_Is_Moving) and BLM_Settings.BLM_DOT and Player.gauge[4] > 5000 then
			if BLM_Use_Dot and BLM_Settings.BLM_AOE and blmACR.TargetFrom(currentTarget.id) > 2 and blmACR.useSkill({"thunder2"}) then
				return true
			else
				if BLM_Use_Dot and blmACR.useSkill({"thunder","thunder3"}) then
					return true
				end
				if BLM_Fire_Mode and BLM_Use_Dot and blmACR:BuffActive("thundercloud") then
					if blmACR.useSkill({"thunder","thunder3"}) then
						return true
					end
				elseif BLM_Ice_Mode and BLM_Use_Dot then
					if blmACR.useSkill({"thunder","thunder3"}) then
						return true
					end
				end
			end
		end
		
		if BLM_Can_Cast and BLM_Fire_Mode then
			if blmACR:BuffActive("firestarter") and blmACR.useSkill({"fire3"}) then
				return true
			end
		end

		if TensorDrift_SlidecastDisableHold ~= nil and TensorDrift_SlidecastDisableHold == true then
			if BLM_Is_Moving then
				if blmACR.useSkill({"swiftcast"}) then
					return
				end
			end
		end

		if TensorDrift_SlidecastDisableHold ~= nil and TensorDrift_SlidecastDisableHold == true then
			if BLM_Is_Moving and not blmACR:BuffActive("swiftcast") then
				if not blmACR:BuffActive("triplecast") then
					if blmACR.useSkill({"triplecast"}) then
						return true
					end
				end
			end
		end
		
		if BLM_Settings.BLM_Scathe and BLM_Is_Moving and BLM_Can_Use_Scathe then
			if (not blmACR:BuffActive("swiftcast") and not blmACR:BuffActive("triplecast")) and blmACR.useSkill({"scathe"}) then
				return true
			end
		end
		
		if Player.gauge[5] <= 1 and Player.gaugetest[9] >= 5000 then
			if BLM_Fire_Mode and blmACR.useSkill({"amplifier"},"Player") then
				return true
			end
		end
		
		if BLM_Settings.BLM_CD and (Player.mp.percent < 8) and blmACR.useSkill({"manafont"}) then
			return true
		end
		

		
		if BLM_Can_Cast and not BLM_Is_Moving then
			if Player.level >= 35 then		

				if Player.mp.percent < 16 and not blmACR:BuffActive("firestarter") then
					if Player.mp.percent ~= 0 and Player.mp.percent >= 8 and Player.level >= 50 then
						if BLM_Fire_Mode and blmACR.useSkill({"despair","flare"}) then
							return true
						end
					elseif (Player.castinginfo.lastcastid ~= 158) and Player.mp.current <= 800 then
						if BLM_Fire_Mode and blmACR.useSkill({"blizzard3"}) then
							return true
						end
					end
				elseif Player.level >= 58 and Player.gaugetest[6] == 3 and (Player.mp.percent > 90 and Player.gauge[2] < 0) then
					if blmACR.useSkill({"paradox","fire3"}) then
						return true
					end
				elseif Player.level < 58 and (Player.mp.percent > 90 and Player.gauge[2] < 0) then
					if blmACR.useSkill({"fire3"}) then
						return true
					end
				end
			elseif Player.level < 35 then
				if ((Player.mp.percent < 16) or Player.gauge[2] < 0 and Player.mp.percent > 90) and blmACR.useSkill({"transpose"}) then
					BLM_Cast_Timer = 0
					return true
				end
			end
			if (BLM_Fire_Mode or Player.gauge[2] == 0) and Player.level >= 2 then
				if BLM_Settings.BLM_AOE and Player.mp.percent >= 30 and blmACR.TargetFrom(currentTarget.id) >= 2 then
					if blmACR.useSkill({"fire2","highfire2"}) then
						return true
					end
				elseif BLM_Settings.BLM_AOE and Player.mp.percent <= 30 and (Player.level >= 50) and blmACR.TargetFrom(currentTarget.id) >= 2 then
					if BLM_Fire_Mode and blmACR.useSkill({"flare"}) then
						return true
					end
				else				
					if blmACR:BuffActive("firestarter") and blmACR.useSkill({"fire3"}) then
						return true
					elseif Player.level >= 60 then
						if Player.gauge[4] > 5000 and blmACR.useSkill({"fire4"}) then
							return true
						elseif Player.gauge[4] <= 5000 and blmACR.useSkill({"paradox","fire"}) then
							return true
						end
					elseif blmACR.useSkill({"fire"}) then
						return true
					end
				end
			end
			if BLM_Ice_Mode then
				if blmACR.useSkill({"paradox"}) then
					return true
				end
				if BLM_Settings.BLM_AOE and Player.mp.percent >= 6 and (blmACR.TargetFrom(currentTarget.id) >= 2) and Player.level >= 12 then
					if blmACR.useSkill({"blizzard2","highblizzard2"}) then
						return true
					end
				elseif Player.level >= 58 then
					if Player.gauge[4] > 4000 and blmACR.useSkill({"blizzard4"}) then
						return true
					elseif Player.gauge[4] <= 4000 and blmACR.useSkill({"blizzard"}) then
						return true
					elseif blmACR.useSkill({"blizzard"}) then
						return true
					end
				else
					if blmACR.useSkill({"blizzard"}) then
						return true
					end
				end
			end
		end
		
	return false
	end
end

function blmACR.Draw()
	if (blmACR.GUI.open) then
	blmACR.GUI.visible, blmACR.GUI.open = GUI:Begin(blmACR.GUI.name, blmACR.GUI.open, GUI.WindowFlags_NoResize)
	if (blmACR.GUI.visible) then
		GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Defensives",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3
		end
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")
		end
		
		-- Tabs
		
		-- Main Tab
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:BulletText("Wxlfee's Black Mage ACR")
				GUI:Text("1.0.2 Changelogs:")
				GUI:Text("Fixed level <35 stalling.")
				GUI:Text("Added swiftcast movement for TensorDrift.")
				GUI:Text("_________________________________________________")
			end
		--Defensives Tab
			if (TabIndex == 2) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("Addle")
				BLM_Settings.BLM_AddleSlider, BLMAddleSlider = GUI:SliderInt("HP%", BLM_Settings.BLM_AddleSlider,0,100)
				GUI:Text("_________________________________________________")
				if (BLM_AddleSlider) then
					BLM_Settings.BLM_AddleSlider = BLMSettings.BLM_AddleSlider
					blmACR.SaveSettings()
				end
				GUI:Text("Manaward")
				BLM_Settings.BLM_ManawardSlider, BLM_ManawardSlider = GUI:SliderInt("HP%##", BLM_Settings.BLM_ManawardSlider,0,100)
				GUI:Text("_________________________________________________")
				if (BLM_ManawardSlider) then
					BLM_Settings.BLM_ManawardSlider = BLM_Settings.BLM_ManawardSlider
					blmACR.SaveSettings()
				end				
			end
		-- Toggles Tab
			if (TabIndex == 3) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",344,25)
				if GUI:IsItemClicked() then
					BLM_Settings.BLM_QT_GUI = not BLM_Settings.BLM_QT_GUI
					blmACR.SaveSettings()
				end
				BLM_Settings.BLM_Scathe, ScatheToggle = GUI:Checkbox("Scathe Movement:", BLM_Settings.BLM_Scathe)
				if ScatheToggle then
					blmACR.SaveSettings()
				end
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Use Scathe when moving.")
				end
				BLM_Settings.BLM_AM, AMToggle = GUI:Checkbox("Aetherial Manipulation UI:", BLM_Settings.BLM_AM)
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Enables Party List overlay. \nClick the button to use Aetherial Manipulation towards that player.")
				end
				if AMToggle then
					blmACR.SaveSettings()
				end
				GUI:Button("Sort Party list",80,20)
				if GUI:IsItemClicked() then
					SendTextCommand("/partysort")
				end
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Readjust party list if Aetherial Manipulation order is misaligned. \nPotentially can bug out with DPS.")
				end
				GUI:Text("_________________________________________________")
				BLM_QT_ON_r, BLM_QT_ON_g, BLM_QT_ON_b, BLM_ON = GUI:ColorEdit3("Toggle On",BLM_Settings.BLM_QT_ON_R,BLM_Settings.BLM_QT_ON_G,BLM_Settings.BLM_QT_ON_B, GUI.ColorEditMode_NoInputs)
				if BLM_ON then
					BLM_Settings.BLM_QT_ON_R = BLM_QT_ON_r
					BLM_Settings.BLM_QT_ON_G = BLM_QT_ON_g
					BLM_Settings.BLM_QT_ON_B = BLM_QT_ON_b
					blmACR.SaveSettings()
				end
				GUI:SameLine()
				BLM_QT_OFF_r, BLM_QT_OFF_g, BLM_QT_OFF_b, BLM_OFF = GUI:ColorEdit3("Toggle Off",BLM_Settings.BLM_QT_OFF_R,BLM_Settings.BLM_QT_OFF_G,BLM_Settings.BLM_QT_OFF_B, GUI.ColorEditMode_NoInputs)
				if BLM_OFF then
					BLM_Settings.BLM_QT_OFF_R = BLM_QT_OFF_r
					BLM_Settings.BLM_QT_OFF_G = BLM_QT_OFF_g
					BLM_Settings.BLM_QT_OFF_B = BLM_QT_OFF_b
					blmACR.SaveSettings()
				end
				GUI:SameLine()
				GUI:Button("Save Colors",85,20)
				if GUI:IsItemClicked() then
					blmACR.SaveSettings()
				end
			end
		-- Discord Tab
			if (TabIndex == 4) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")
				end
				GUI:Text("_________________________________________________")
			end
		end
		GUI:End()
	end
		if (BLM_Settings.BLM_QT_GUI) then
			local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
				blmACR.GUIQT.visible, blmACR.GUIQT.open = GUI:Begin(blmACR.GUIQT.name, blmACR.GUIQT.open, flags2)
				if (blmACR.GUIQT.visible) then
					GUI:SetWindowSize(0,0,0)
					GUI:PushStyleColor(GUI.Col_Button, BLMCDr, BLMCDg, BLMCDb, BLMCDa)
					BLMCDButton = GUI:Button("CD",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						BLMCDQTfunc()
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, BLMAOEr, BLMAOEg, BLMAOEb, BLMAOEa)
					BLMAOEButton = GUI:Button("AOE",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						BLMAOEQTfunc()
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, BLMDEFr, BLMDEFg, BLMDEFb, BLMDEFa)
					BLMDEFButton = GUI:Button("Defensives",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						BLMDEFQTfunc()
					end
					GUI:PushStyleColor(GUI.Col_Button, BLMTRANSr, BLMTRANSg, BLMTRANSb, BLMTRANSa)
					BLMTRANSButton = GUI:Button("OoC Trans",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						BLMOoCTransQTfunc()
					end
					if GUI:IsItemHovered() then
						GUI:SetTooltip("Use Transpose Out of Combat.")
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, BLMDOTr, BLMDOTg, BLMDOTb, BLMDOTa)
					BLMDOTButton = GUI:Button("DOT",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						BLMDOTQTfunc()
					end
				end
			GUI:End()
		end
			if (BLM_Settings.BLM_AM) then
				local PTB = GetControlByName("_PartyList")
				if (PTB) then
					local x,y = PTB:GetXY()					
					local scale = PTB:GetScale()
					am_x2 = 275
					am_y2 = 370
					GUI:SetNextWindowPos(x,y,GUI.SetCond_Always)
					--GUI:SetNextWindowSize(x2,y2,GUI.SetCond_Always)
				end				
				local winBG = ml_gui.style.current.colors[GUI.Col_WindowBg]
				GUI:PushStyleColor(GUI.Col_WindowBg, winBG[1], winBG[2], winBG[3], 0)				
				local flags3 = (GUI.WindowFlags_NoBringToFrontOnFocus + GUI.WindowFlags_NoTitleBar + GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoCollapse)
				blmACR.GUIAM.visible, blmACR.GUIAM.open = GUI:Begin(blmACR.GUIAM.name, blmACR.GUIAM.open, flags3)
					GUI:SetWindowSize(am_x2,am_y2,GUI.SetCond_Always)
					if (blmACR.GUIAM.visible) then						
						DrawPartyBox()						
					
					end
				GUI:PopStyleColor(1)
				GUI:End()
			end
			

end

function blmACR.OnOpen()
	blmACR.GUI.open = true
end

function blmACR.QTOnOpen()
	blmACR.GUIQT.open = true
end

function blmACR.SaveSettings()
	d("[WxlfeeCore] Settings have been saved.")
	WXSave()
end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function BLMloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    BLM_Settings = scan(BLM_Settings,tbl)
end

local isLoaded = false
function blmACR.LoadSettings()
	BLMloadsettings(tbl)
	isLoaded = true
end

function blmACR.OnLoad()
	checkFile()
	TabIndex = 1
	blmACR.LoadSettings()
end

function blmACR.OnClick(mouse,shiftState,controlState,altState,entity)

end

function blmACR.OnUpdate(event, tickcount)
	blmACR_oGCDReady()
	if isLoaded then BLMLoadQTColor() end
	BLM_MoveCheck()
	BLM_Check_DOT()
	BLM_CD_Check()
	BLM_Check_Quest_Unlock()
end

return blmACR