local mchACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .. [[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath .. [[MCHsettings.lua]]
local v = table.valid

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("MCHsettings.lua","w")
		localfile:write(MCH_Settings)
		file:close()
	end
end

local MCH_Settings = {

	MCH_QT_GUI = false,
	
	MCH_PeloDelay = false,

	MCH_tactSlider = 75,
	MCH_bgaugeSlider = 70,
	MCH_dismantleSlider = 90,
	MCH_secondwindSlider = 60,
	MCH_peloton = false,
	MCH_CDs = true,
	MCH_hypercharge = true,
	MCH_aqueen = true,
	MCH_adaptqueen = false,
	MCH_AOE = true,
	MCH_Defensives = true,
}

local function WXSave()
	FileSave(ModuleSettings,MCH_Settings)
end

mchACR.GUI = {
    open = true,
    visible = true,
    name = "Casually Machinist",
}

mchACR.GUIQT = {
    open = false,
    visible = true,
    name = "QuickToggles",
}
 
mchACR.classes = {
    [FFXIV.JOBS.MACHINIST] = true,
} 


--Important Attacks (So we can check their cooldown times)
reassembleCD = ActionList:Get(1,2876)
chainsawCD = ActionList:Get(1,25788)
drillCD = ActionList:Get(1,16498)
airanchorCD = ActionList:Get(1,16500)
hotshotCD = ActionList:Get(1,2872)
heatblastCD = ActionList:Get(1,7410)
gaussroundCD = ActionList:Get(1,2874)
wildfireCD = ActionList:Get(1,2878)
barrelstabilizerCD = ActionList:Get(1,7414)
CD = ActionList:Get(1,2866)
hyperchargeCD = ActionList:Get(1,17209)
ricochetCD = ActionList:Get(1,2890)




peloText = "Peleton"

t = 0

mchACR.mchBuff = 
	{
		reassembled = 851,
		peloton = 1199,
		overheated = 2688,
		wildfire = 1946,
		
		--party Buffs
		
		
	}
mchACR.mchSkill = 
	{
		splitshot = {2866,true},
		slugshot = {2868,true},
		cleanshot = {2873,true},
		hotshot = {2872,true},
		heatedsplitshot = {7411,true},
		heatedslugshot = {7412,true},
		heatedcleanshot = {7413,true},
		spreadshot = {2870,true},
		drill = {16498,true},
		reassemble = {2876,false},
		barrelstabilizer = {7414,false},
		airanchor = {16500,true},
		ricochet = {2890,true},
		gaussround = {2874,true},
		hypercharge = {17209,false},
		heatblast = {7410,true},
		autocrossbow = {16497,true},
		wildfire = {2878,true},
		bioblaster = {16499,true},
		flamethrower = {7418,true},
		rookautoturret = {2864,false},
		rookoverdrive = {7415,false},
		automatonqueen = {16501,false},
		queenoverdrive = {16502,false},
		scattergun = {25786,true},
		chainsaw = {25788,true},
		tactician = {16889,false},
		peloton = {7557,false},
		dismantle = {2887,true},
		secondwind = {7541,false},

	}
	
function mchACR:skillID(string)
	if mchACR.mchSkill[string] ~= nil then
		return mchACR.mchSkill[string][1]
	end
end

function mchACR:LastAttackID(string)
	if mchACR:skillID(string) ~= nil then
		if Player.lastcomboid == mchACR:skillID(string) then
			return true
		end
	end
	return false
end

function mchACR:BuffActive(string)
	if mchACR.mchBuff[string] ~= nil then
		if HasBuff(Player.id,mchACR.mchBuff[string]) then
			return true
		end
	end
	return false
end



MultiTabs =  [[Main, Defensives, Test2, Discord]]
TabIndex = 1
mchACR.ogcdtimer = 0
mchACR.safejump = 0
PelotonIsOn = PelotonIsOn
PlayerLevel = Player.level

function MCHLoadQTColor()
	local function setColorValue(setting, trueValue, falseValue)
		if setting == true then
			return trueValue
		else
			return falseValue
		end
	end

-- Peloton QT Colors
pelor = setColorValue(MCH_Settings.MCH_peloton, 0.3, 0.6)
pelog = setColorValue(MCH_Settings.MCH_peloton, 0.55, 0.2)
pelob = setColorValue(MCH_Settings.MCH_peloton, 0.14, 0.2)
peloa = 1

-- Wildfire QT Colors
wildr = setColorValue(Settings.ACR.wildfireON, 0.3, 0.6)
wildg = setColorValue(Settings.ACR.wildfireON, 0.55, 0.2)
wildb = setColorValue(Settings.ACR.wildfireON, 0.14, 0.2)
wilda = 1

-- Hypercharge QT Colours
hyper = setColorValue(MCH_Settings.MCH_hypercharge, 0.3, 0.6)
hypeg = setColorValue(MCH_Settings.MCH_hypercharge, 0.55, 0.2)
hypeb = setColorValue(MCH_Settings.MCH_hypercharge, 0.14, 0.2)
hypea = 1

-- Automaton Queen QT Colours --
aqueenr = setColorValue(MCH_Settings.MCH_aqueen, 0.3, 0.6)
aqueeng = setColorValue(MCH_Settings.MCH_aqueen, 0.55, 0.2)
aqueenb = setColorValue(MCH_Settings.MCH_aqueen, 0.14, 0.2)
aqueena = 1

-- Defensives QT Colours --
MCHDEFr = setColorValue(MCH_Settings.MCH_Defensives, 0.3, 0.6)
MCHDEFg = setColorValue(MCH_Settings.MCH_Defensives, 0.55, 0.2)
MCHDEFb = setColorValue(MCH_Settings.MCH_Defensives, 0.14, 0.2)
MCHDEFa = 1

-- CD QT Colours
MCH_CDsr = setColorValue(MCH_Settings.MCH_CDs, 0.3, 0.6)
MCH_CDsg = setColorValue(MCH_Settings.MCH_CDs, 0.55, 0.2)
MCH_CDsb = setColorValue(MCH_Settings.MCH_CDs, 0.14, 0.2)
MCH_CDsa = 1

-- AOE QT Colours --
MCH_AOEr = setColorValue(MCH_Settings.MCH_AOE, 0.3, 0.6)
MCH_AOEg = setColorValue(MCH_Settings.MCH_AOE, 0.55, 0.2)
MCH_AOEb = setColorValue(MCH_Settings.MCH_AOE, 0.14, 0.2)
MCH_AOEa = 1

end

-- Quick Toggle Functions
function MCHOpenQT()
	MCH_Settings.MCH_QT_GUI = not MCH_Settings.MCH_QT_GUI
	mchACR.SaveSettings()
end

function pelotonQTfunc()
	MCH_Settings.MCH_peloton = not MCH_Settings.MCH_peloton
	pelor, pelog, pelob =
		MCH_Settings.MCH_peloton and 0.3 or 0.60,
		MCH_Settings.MCH_peloton and 0.55 or 0.2,
		MCH_Settings.MCH_peloton and 0.14 or 0.2,
	peloa == 1
	mchACR.SaveSettings()
end

function wildfireQTfunc()
	Settings.ACR.wildfireON = not Settings.ACR.wildfireON
	wildr, wildg, wildb =
		Settings.ACR.wildfireON and 0.3 or 0.60,
		Settings.ACR.wildfireON and 0.55 or 0.2,
		Settings.ACR.wildfireON and 0.14 or 0.2,
	wilda == 1
	mchACR.SaveSettings()
end

function hyperchargeQTfunc()
	MCH_Settings.MCH_hypercharge = not MCH_Settings.MCH_hypercharge
	hyper, hypeg, hypeb =
		MCH_Settings.MCH_hypercharge and 0.3 or 0.60,
		MCH_Settings.MCH_hypercharge and 0.55 or 0.2,
		MCH_Settings.MCH_hypercharge and 0.14 or 0.2,
	hypea == 1
	mchACR.SaveSettings()
end

function aQueenQTfunc()
	MCH_Settings.MCH_aqueen = not MCH_Settings.MCH_aqueen
	aqueenr, aqueeng, aqueenb =
		MCH_Settings.MCH_aqueen and 0.3 or 0.60,
		MCH_Settings.MCH_aqueen and 0.55 or 0.2,
		MCH_Settings.MCH_aqueen and 0.14 or 0.2,
	aqueena == 1
	mchACR.SaveSettings()
end

function SmartQueenQTfunc()
	MCH_Settings.MCH_adaptqueen = not MCH_Settings.MCH_adaptqueen
	smartqueenr, smartqueeng, smartqueenb =
		MCH_Settings.MCH_adaptqueen and 0.3 or 0.60,
		MCH_Settings.MCH_adaptqueen and 0.55 or 0.2,
		MCH_Settings.MCH_adaptqueen and 0.14 or 0.2,
	smartqueena == 1
	mchACR.SaveSettings()
end

function DEFQTfunc()
	MCH_Settings.MCH_Defensives = not MCH_Settings.MCH_Defensives
	MCHDEFr, MCHDEFg, MCHDEFb =
		MCH_Settings.MCH_Defensives and 0.3 or 0.60,
		MCH_Settings.MCH_Defensives and 0.55 or 0.2,
		MCH_Settings.MCH_Defensives and 0.14 or 0.2,
	MCHDEFa == 1
	mchACR.SaveSettings()
end

function CDQTfunc()
	MCH_Settings.MCH_CDs = not MCH_Settings.MCH_CDs
	MCH_CDsr, MCH_CDsg, MCH_CDsb =
		MCH_Settings.MCH_CDs and 0.3 or 0.6,
		MCH_Settings.MCH_CDs and 0.55 or 0.2,
		MCH_Settings.MCH_CDs and 0.14 or 0.2,
	MCH_CDsa == 1
	mchACR.SaveSettings()
end

function AOEQTfunc()
	MCH_Settings.MCH_AOE = not MCH_Settings.MCH_AOE
	MCH_AOEr, MCH_AOEg, MCH_AOEb =
		MCH_Settings.MCH_AOE and 0.3 or 0.6,
		MCH_Settings.MCH_AOE and 0.55 or 0.2,
		MCH_Settings.MCH_AOE and 0.14 or 0.2,
	MCH_AOEa == 1
	mchACR.SaveSettings()
end


function mchACR.counttarget(targetid)
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5,distanceto="..tostring(targetid))
	return (table.size(targets))
end



-- Peloton function
function mchACR.pelotonActive()

pelotonCounter = pelotonCounter or 1

	if Player:IsMoving() and MCH_Settings.MCH_peloton then
		pelotonCounter = pelotonCounter + 1
		d(pelotonCounter)
	end
	if HasBuff(Player.id,1199) then
		pelotonCounter = 0
	end
	if Player.incombat then
		pelotonCounter = 0
	end
	
	
	if MCH_Settings.MCH_PeloDelay and pelotonCounter >= 10 then
		if MCH_Settings.MCH_peloton then
			if Player:IsMoving() and not Player.incombat and not HasBuff(Player.id,1199) then
				ActionList:Get(1,7557):Cast(Player.id)
				pelotonCounter = 0				
			end
		end		
	elseif not MCH_Settings.MCH_PeloDelay then
		if MCH_Settings.MCH_peloton then
			if Player:IsMoving() and not Player.incombat and not HasBuff(Player.id,1199) then
				ActionList:Get(1,7557):Cast(Player.id)
				pelotonCounter = 0
			end
		end
	end
end

function LevelCheck()
Player_Level = Player.level
Selection = Selection

	if (Player_Level == 90) then
		BigCDCheck()
		Selection = "Check1"
	end
	
	if (Player_Level >=76) and (Player_Level <= 89) then
		BigCDCheck2()
		Selection = "Check2"
	end
	
	if (Player_Level >= 58) and (Player_Level <= 75) then
		BigCDCheck3()
		Selection = "Check3"
	end
	
	if (Player_Level <= 57) then
		BigCDCheck4()
		Selection = "Check4"
	end
	return Selection
end

-- Big CD checker (CDs nutsz~) (Level 90 rotation)
function BigCDCheck()
	-- If big cd over 8 sec
	HCReady = false
	if (chainsawCD.cd < 50) then
		HCReady = true
	elseif (airanchorCD.cd < 30) then
		HCReady = true
	elseif (drillCD.cd < 11) then
		HCReady = true
	end
	-- If big cd under 8 sec
	if (chainsawCD.cd >= 50) then
		HCReady = false
	elseif (airanchorCD.cd >= 30) then
		HCReady = false
	elseif (drillCD.cd >= 11) then
		HCReady = false
	end
	-- If big cd off cooldown
	if (chainsawCD.cd == 0) then
		HCReady = false
	end
	if (airanchorCD.cd == 0) then
		HCReady = false
	end
	if (drillCD.cd == 0) then
		HCReady = false
	end
	return HCReady
end

function BigCDCheck2()
	HCReady = false
	if (airanchorCD.cd < 30) then
		HCReady = true
	elseif (drillCD.cd < 11) then
		HCReady = true
	end
	-- If big cd under 8 sec
	if (airanchorCD.cd >= 30) then
		HCReady = false
	elseif (drillCD.cd >= 11) then
		HCReady = false
	end
	-- If big cd off cooldown
	if (airanchorCD.cd == 0) then
		HCReady = false
	end
	if (drillCD.cd == 0) then
		HCReady = false
	end
	return HCReady
end

function BigCDCheck3()
	HCReady = false
	if (hotshotCD.cd < 30) then
		HCReady = true
	elseif (drillCD.cd < 11) then
		HCReady = true
	end
	-- If big cd under 8 sec
	if (hotshotCD.cd >= 30) then
		HCReady = false
	elseif (drillCD.cd >= 11) then
		HCReady = false
	end
	-- If big cd off cooldown
	if (hotshotCD.cd == 0) then
		HCReady = false
	end
	if (drillCD.cd == 0) then
		HCReady = false
	end
	return HCReady
end

function BigCDCheck4()
	HCReady = false
	if (hotshotCD.cd < 30) then
		HCReady = true
	end
	-- If big cd under 8 sec
	if (hotshotCD.cd >= 30) then
		HCReady = false
	end
	-- If big cd off cooldown
	if (hotshotCD.cd == 0) then
		HCReady = false
	end	
	return HCReady
end


function MCH_oGCDisReady()
	oGCDReady = false
	CDmax = CD.cdmax
	WeaveTime = (CD.cdmax/5)*2.50
	
		if CD.cd < WeaveTime then
			oGCDReady = true
		end
		if (CD.cd > WeaveTime) or (CD.cd == 0) then
			oGCDReady = false
		end
	return oGCDReady
end


function preCastReass()
DrillReady = false
ChainReady = false
AirReady = false

drillValue = drillCD.cdmax - drillCD.cd
chainValue = chainsawCD.cdmax - chainsawCD.cd
airValue = airanchorCD.cdmax - airanchorCD.cd

if drillValue < CD.cd then
	DrillReady = true
end
if chainValue < CD.cd then
	ChainReady = true
end
if airValue < CD.cd then
	AirReady = true
end
end


 
function mchACR.setVar()
	for i,e in pairs(mchACR.mchSkill) do
		mchACR[i] = ActionList:Get(1,e[1])
		if mchACR[i] then
			if e[2] then
				mchACR[i]["isready"] = mchACR[i]:IsReady(MGetTarget().id)
			else
				mchACR[i]["isready"] = mchACR[i]:IsReady(Player)
			end
		end
	end
end

function mchACR.useSkill(skl,string)
	local text = (string)
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = mchACR[abil].isready
		if ACTready then
			mchACR[abil]:Cast(text.id)
			return true
		end
	end
	return false
end
 
function mchACR.Cast()
	mchACR.pelotonActive()
    local currentTarget = MGetTarget()
	if (currentTarget == nil) then
		return false
	end
	if (currentTarget.attackable) and (gStartCombat or currentTarget.incombat) then
		mchACR.setVar()
		
		-- Use Big CD
		if (not mchACR:BuffActive("overheated")) then
			if mchACR.useSkill({"airanchor","drill","chainsaw","hotshot"}) then
				return true
			end
		end
		
		-- Use reass if Big CD off CD
		if oGCDReady and (not mchACR:BuffActive("overheated")) then
			if Player.level == 90 then
				if DrillReady and mchACR.useSkill({"reassemble"}) then
					d("Should be casting reass")
					return true
				end
				if ChainReady and mchACR.useSkill({"reassemble"}) then
					d("Should be casting reass")
					return true
				end
				if AirReady and mchACR.useSkill({"reassemble"}) then
					d("Should be casting reass")
					return true
				end
			end
			if Player.level <= 89 and Player.level >= 76 then
				if (not drillCD.isoncd) and mchACR.useSkill({"reassemble"}) then
					return true
				end
				if not airanchorCD.isoncd and mchACR.useSkill({"reassemble"}) then
					return true
				end
			end
			if Player.level <= 75 and Player.level >= 58 then
				if (not drillCD.isoncd) and mchACR.useSkill({"reassemble"}) then
					return true
				end
			end
			if Player.level <= 57 then
				if mchACR:LastAttackID("slugshot") and mchACR.useSkill({"reassemble"}) then
					return true
				end
			end
		end
		
		if MCH_Settings.MCH_CDs and MCH_Settings.MCH_hypercharge and oGCDReady and (Player.gauge[1] >= 50) and (Player.gauge[2] >= 50) and mchACR.useSkill({"wildfire"}) then
			return true
		end
		
		if MCH_Settings.MCH_CDs then
			if (wildfireCD.cd <= 95 and wildfireCD.isoncd) and (Player.level >= 45) and MCH_Settings.MCH_hypercharge and oGCDReady and (HCReady or mchACR:BuffActive("wildfire")) and (Player.gauge[1] >= 50) and mchACR.useSkill({"hypercharge"}) then
				return true
			end
			if (wildfireCD.cd <= 105 and wildfireCD.isoncd) and (Player.level >= 45) and MCH_Settings.MCH_aqueen and (Player.gauge[2] >= (MCH_Settings.MCH_bgaugeSlider)) and oGCDReady and mchACR.useSkill({"rookautoturret","automatonqueen"}) then
				return true
			elseif mchACR:BuffActive("wildfire") and MCH_Settings.MCH_aqueen and (Player.level >= 45) and (CD.cd < 0.6) and (Player.gauge[2] >= 50) and oGCDReady and mchACR.useSkill({"rookautoturret","automatonqueen"}) then
				return true
			end
		elseif not MCH_Settings.MCH_CDs then
			if MCH_Settings.MCH_hypercharge and oGCDReady and (HCReady or mchACR:BuffActive("wildfire")) and (Player.gauge[1] >= 50) and mchACR.useSkill({"hypercharge"}) then
				return true
			end
			if MCH_Settings.MCH_aqueen and (Player.gauge[2] >= (MCH_Settings.MCH_bgaugeSlider)) and oGCDReady and mchACR.useSkill({"rookautoturret","automatonqueen"}) then
				return true
			end
		end
		
		-- Queen/Rook Usage
		

		
		--Overheated Mode
		if (MCH_Settings.MCH_AOE == true) and mchACR.counttarget(currentTarget.id) > 2 and currentTarget.distance < 12 then
			if Player.gauge ~= nil and (Player.gauge[3] > 0)  and  mchACR.useSkill({"autocrossbow"}) then
				return true
			end		
		else
			if Player.gauge ~= nil and (Player.gauge[3] > 0)  and  mchACR.useSkill({"heatblast"}) then
				return true
			end
		end
		
		--BarrelStabilizer Shit
		if MCH_Settings.MCH_CDs and oGCDReady and (Player.gauge[1] <= 50 and not mchACR.BuffActive("overheated")) and mchACR.useSkill({"barrelstabilizer"}) then
			return true
		end	
		
		-- oGCD shitters
		
		if (CD.cdmax == 1.5) then			
			if (gaussroundCD.cd >= ricochetCD.cd) and (CD.cd <= 0.6) and mchACR.useSkill({"ricochet"}) then
				return true
			elseif (ricochetCD.cd >= gaussroundCD.cd) and (CD.cd <= 0.6) and mchACR.useSkill({"gaussround"}) then
				return true
			elseif (CD.cd <= 0.6) and mchACR.useSkill({"gaussround","ricochet"}) then
				return true
			end
		else
			if (gaussroundCD.cd >= ricochetCD.cd) and oGCDReady and mchACR.useSkill({"ricochet"}) then
				return true
			elseif (ricochetCD.cd >= gaussroundCD.cd) and oGCDReady and mchACR.useSkill({"gaussround"}) then
				return true
			elseif oGCDReady and  mchACR.useSkill({"gaussround","ricochet"}) then
				return true
			end
		end
			
		
		
		--123/AOE
		if (MCH_Settings.MCH_AOE == true) and mchACR.counttarget(currentTarget.id) >= 2 and currentTarget.distance < 12 then
			if mchACR.useSkill({"spreadshot","scattergun"}) then
				return true
			end		
		else
			if mchACR:LastAttackID("slugshot") and mchACR.useSkill({"cleanshot","heatedcleanshot"}) then
				return true				
			end	
			if mchACR:LastAttackID("splitshot") and mchACR.useSkill({"slugshot","heatedslugshot"}) then
				return true
			end			
			if mchACR.useSkill({"splitshot","heatedsplitshot"}) then
				return true
			end
		end
		
		-- Defensives (LMFAO MCH DEFENSIVES, WHAT ARE YOU, AN IDIOT?)
		if (MCH_Settings.MCH_Defensives == true) and (Player.hp.percent <= MCH_Settings.MCH_tactSlider) and mchACR.useSkill({"tactician"}) then
			return
		end
		
		if (MCH_Settings.MCH_Defensives == true) and (Player.hp.percent <= MCH_Settings.MCH_tactSlider) and Player.gauge ~= nil and Player.gauge[3] == 0 and mchACR.useSkill({"dismantle"}) then
			return
		end
		
		if (MCH_Settings.MCH_Defensives == true) and (Player.hp.percent <= MCH_Settings.MCH_secondwindSlider) and Player.gauge ~= nil and Player.gauge[3] == 0 and mchACR.useSkill({"secondwind"}) then
			return
		end
		


	return false
	end
end



function mchACR.Draw()
    if (mchACR.GUI.open) then	
	mchACR.GUI.visible, mchACR.GUI.open = GUI:Begin(mchACR.GUI.name, mchACR.GUI.open, GUI.WindowFlags_NoResize)
	if ( mchACR.GUI.visible ) then
		GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Utility",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3
		end
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")			
		end
		
		--Tabs
		
		--Main Tab 
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Text("Wxlfee's Machinist ACR")
				GUI:Text("1.5.1 Changelog:")
				GUI:Text("Altered WeaveTime to avoid triple weaving.")
				GUI:Text("Changed Battery Stabilizer requirements.")
				GUI:Text("_________________________________________________")
			end
		--Defensives Tab
			if (TabIndex == 2) then
				GUI:SetWindowSize(367,184,0)
				GUI:BeginGroup()
				GUI:Text("_________________________________________________")
				local swall
				GUI:Text("Battery Gauge")
				MCH_Settings.MCH_bgaugeSlider, swall = GUI:SliderInt("% ",MCH_Settings.MCH_bgaugeSlider,50,100)
				GUI:Text("_________________________________________________")
				if (swall) then
					sliderValue = math.floor(MCH_Settings.MCH_bgaugeSlider / 10 + 0.5) * 10
					MCH_Settings.MCH_bgaugeSlider = sliderValue
					d(MCH_Settings.MCH_bgaugeSlider)
					MCH_Settings.MCH_bgaugeSlider = MCH_Settings.MCH_bgaugeSlider
					mchACR.SaveSettings()
				end
				--Tactician Slider
				local ramp
				GUI:Text("Tactician")
				MCH_Settings.MCH_tactSlider, ramp = GUI:SliderInt("HP%",MCH_Settings.MCH_tactSlider,0,100)
				GUI:Text("_________________________________________________")
				if (ramp) then
					d(MCH_Settings.MCH_tactSlider)
					MCH_Settings.MCH_tactSlider = MCH_Settings.MCH_tactSlider
					mchACR.SaveSettings()
				end
				local Dismantle
				GUI:Text("Dismantle")
				MCH_Settings.MCH_dismantleSlider, Dismantle = GUI:SliderInt("HP%##",MCH_Settings.MCH_dismantleSlider,0,100)
				GUI:Text("_________________________________________________")
				if (Dismantle) then
					d(MCH_Settings.MCH_dismantleSlider)
					MCH_Settings.MCH_dismantleSlider = MCH_Settings.MCH_dismantleSlider
					mchACR.SaveSettings()
				end
				GUI:Text("Second Wind")
				MCH_Settings.MCH_secondwindSlider, secwin = GUI:SliderInt("HP%## ",MCH_Settings.MCH_secondwindSlider,0,100)
				GUI:Text("_________________________________________________")
				if (secwin) then
					MCH_Settings.MCH_secondwindSlider = MCH_Settings.MCH_secondwindSlider
					mchACR.SaveSettings()
				end	
				GUI:EndGroup()				
			end
		--Toggles
			if (TabIndex == 3) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",344,25)
				if GUI:IsItemClicked() then
					MCHOpenQT()
				end					
				GUI:Text("_________________________________________________")
				MCH_Settings.MCH_PeloDelay, delayPelo = GUI:Checkbox("Delay Peloton: ", MCH_Settings.MCH_PeloDelay)
				if GUI:IsItemClicked() then					
					mchACR.SaveSettings()
				end
				GUI:Text("_________________________________________________")
			end
		--Discord
			if (TabIndex == 4) then
				GUI:SetWindowSize(0,0,0)				
				GUI:Text("_________________________________________________")				
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")					
				end
				GUI:Text("_________________________________________________")
			end
		end
		GUI:End()
			-- Quick Toggles Menu
		if (MCH_Settings.MCH_QT_GUI) then
		local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
			mchACR.GUIQT.visible, mchACR.GUIQT.open = GUI:Begin(mchACR.GUIQT.name, mchACR.GUIQT.open, flags2)
				if (mchACR.GUIQT.visible) then
					GUI:SetWindowSize(0,0,0)
					GUI:PushStyleColor(GUI.Col_Button,MCH_CDsr,MCH_CDsg,MCH_CDsb,MCH_CDsa)					
					peloButton = GUI:Button("CD",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						CDQTfunc()
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button,MCH_AOEr,MCH_AOEg,MCH_AOEb,MCH_AOEa)
					AOEButton = GUI:Button("AOE",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						AOEQTfunc()
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button,pelor,pelog,pelob,peloa)					
					peloButton = GUI:Button("Peloton",90,30)	
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						pelotonQTfunc()
					end
					GUI:PushStyleColor(GUI.Col_Button,hyper,hypeg,hypeb,hypea)
					hyperchargeButton = GUI:Button("Hypercharge",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						hyperchargeQTfunc()
					end
					GUI:SameLine()
					-- Next Line --
					GUI:PushStyleColor(GUI.Col_Button,aqueenr,aqueeng,aqueenb,aqueena)
					automatonButton = GUI:Button("Queen",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						aQueenQTfunc()
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button,MCHDEFr,MCHDEFg,MCHDEFb,MCHDEFa)
					defensivesButton = GUI:Button("Defensives",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						DEFQTfunc()
					end
				end
			GUI:End()
		end
    end	
end

function mchACR.SaveSettings()
	d("[WxlfeeCore] Settings have been saved.")
	WXSave()

end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function MCHloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    MCH_Settings = scan(MCH_Settings,tbl)
end




function mchACR.LoadSettings()
	MCHloadsettings(tbl)
end
 
function mchACR.OnOpen()
    mchACR.GUI.open = true
end
 
function mchACR.OnLoad()
	checkFile()
    TabIndex = 1
	mchACR.LoadSettings()
	MCHLoadQTColor()	
end

function mchACR.QTOnOpen()
	mchACR.GUIQT.open = true
end
 
function mchACR.OnClick(mouse,shiftState,controlState,altState,entity)
 
end
 
function mchACR.OnUpdate(event, tickcount)
	LevelCheck()
	MCH_oGCDisReady()
	preCastReass()
end
 
return mchACR