local gnbACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .. [[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath .. [[GNBsettings.lua]]
local v = table.valid

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("GNBsettings.lua","w")
		localfile:write(GNB_Settings)
		file:close()
	end
end

local GNB_Settings = {
	GNB_QT_GUI = false,
	
	GNB_CDs = true,
	GNB_AOE = true,
	GNB_Stance = true,
	GNB_DEF = true,
	GNB_Jump = true,
	GNB_reprisal = true,
	GNB_LS = true,
	GNB_AutoVoke = false,
	
	GNB_REPslider = 3,
	GNB_AOEslider = 3,

	GNB_RAMPslider = 80,

	GNB_CAMOslider = 70,

	GNB_NEBslider = 60,

	GNB_AURslider = 75,

	GNB_SUPslider = 10,

	GNB_HEARTslider = 90,

	GNB_HEARTLIGHTslider = 75,
}

local function WXSave()
	FileSave(ModuleSettings,GNB_Settings)
end

gnbACR.classes = {
	[FFXIV.JOBS.GUNBREAKER] = true,
}

gnbACR.GUI = {
	open = true,
	visible = true,
	name = "Casually Gunbreaker",
}

gnbACR.GUIQT = {
	open = false,
	visible = true,
	name = "WXQuickToggles",
}

CD = ActionList:Get(1,16137)
nomercyCD = ActionList:Get(1,16138)
blastingzoneCD = ActionList:Get(1,16165)
gnashingfangCD = ActionList:Get(1,16146)
doubledownCD = ActionList:Get(1,25760)
sonicbreakCD = ActionList:Get(1,16153)
bowshockCD = ActionList:Get(1,16159)
provokeCD = ActionList:Get(1,7533)

gnbACR.gnbBuff =
	{
	royalguard = 1833,
	rampart = 1191,
	camouflage = 1832,
	nebula = 1834,
	aurora = 1835,
	superbolide = 1836,
	hos = 1840,
	hol = 1839,
	hoc = 2683,
	nomercy = 1831,
	}
	
gnbACR.gnbSkill =
	{
		keenedge = {16137,true}, -- 123
		brutalshell = {16139,true}, -- 123
		solidbarrel = {16145,true}, -- 123
		demonslice = {16141,false}, -- 45
		demonslaughter = {16149,false}, -- 45
		burststrike = {16162,true}, -- GCD
		dangerzone = {16144,true}, -- oGCD <80
		blastingzone = {16165,true}, -- oGCD => 80
		sonicbreak = {16153,true}, -- GCD 60s CD 30s DOT
		roughdivide = {16154,true}, -- Gap Closer
		gnashingfang = {16146,true}, --123 Cart combo
		savageclaw = {16147,true}, --123 Cart combo
		wickedtalon = {16150,true}, --123 Cart combo
		lightningshot = {16143,true}, -- Ranged Attack
		doubledown = {25760,false}, -- 60s Big boi attack
		bowshock = {16159,false}, -- oGCD AOE DOT 60s CD
		bloodfest = {16164,true}, -- Grants 2 Carts
		fatedcircle = {16163,false},
		-- continuation = {,true}, -- Not sure if this is used but meh
		hypervelocity = {25759,true},
		jugularrip = {16156,true},
		abdomentear = {16157,true},
		eyegouge = {16158,true},
		
		
		nomercy = {16138,false}, -- DPS buff
		
		rampart = {7531,false},
		reprisal = {7535,false},
		camouflage = {16140,false},
		nebula = {16148,false},
		aurora = {16151,false},
		superbolide = {16152,false},
		hos = {16161,false},
		hoc = {25758,false},
		hol = {16160,false},
		provoke = {7533,true},
		
		
	}

function GNBOpenQT()
	GNB_Settings.GNB_QT_GUI = not GNB_Settings.GNB_QT_GUI
	gnbACR.SaveSettings()
end

-- Quick Toggle Load Color

function GNBLoadQTColor()
local function setColorValue(setting, trueValue, falseValue)
	if setting == true then
		return trueValue
	else
		return falseValue
	end
end

-- CD Color
GNBCDr = setColorValue(GNB_Settings.GNB_CDs, 0.3, 0.6)
GNBCDg = setColorValue(GNB_Settings.GNB_CDs, 0.55, 0.2)
GNBCDb = setColorValue(GNB_Settings.GNB_CDs, 0.14, 0.2)
GNBCDa = 1

-- AOE Color
GNBAOEr = setColorValue(GNB_Settings.GNB_AOE, 0.3, 0.6)
GNBAOEg = setColorValue(GNB_Settings.GNB_AOE, 0.55, 0.2)
GNBAOEb = setColorValue(GNB_Settings.GNB_AOE, 0.14, 0.2)
GNBAOEa = 1

--Stance Color
GNBSTANCEr = setColorValue(GNB_Settings.GNB_Stance, 0.3, 0.6)
GNBSTANCEg = setColorValue(GNB_Settings.GNB_Stance, 0.55, 0.2)
GNBSTANCEb = setColorValue(GNB_Settings.GNB_Stance, 0.14, 0.2)
GNBSTANCEa = 1

--Jump Color
GNBJUMPr = setColorValue(GNB_Settings.GNB_Jump, 0.3, 0.6)
GNBJUMPg = setColorValue(GNB_Settings.GNB_Jump, 0.55, 0.2)
GNBJUMPb = setColorValue(GNB_Settings.GNB_Jump, 0.14, 0.2)
GNBJUMPa = 1

--Defensives
GNBDEFr = setColorValue(GNB_Settings.GNB_DEF, 0.3, 0.6)
GNBDEFg = setColorValue(GNB_Settings.GNB_DEF, 0.55, 0.2)
GNBDEFb = setColorValue(GNB_Settings.GNB_DEF, 0.14, 0.2)
GNBDEFa = 1

GNBLSr = setColorValue(GNB_Settings.GNB_LS, 0.3, 0.6)
GNBLSg = setColorValue(GNB_Settings.GNB_LS, 0.55, 0.2)
GNBLSb = setColorValue(GNB_Settings.GNB_LS, 0.14, 0.2)
GNBLSa = 1

GNBAVr = setColorValue(GNB_Settings.GNB_AutoVoke, 0.3,0.6)
GNBAVg = setColorValue(GNB_Settings.GNB_AutoVoke, 0.55,0.2)
GNBAVb = setColorValue(GNB_Settings.GNB_AutoVoke, 0.14,0.2)
GNBAVa = 1

end

-- Quick Toggle functions

function GNBOpenQT()
	GNB_Settings.GNB_QT_GUI = not GNB_Settings.GNB_QT_GUI
	gnbACR.SaveSettings()
end

function GNBCDQTfunc()
	GNB_Settings.GNB_CDs = not GNB_Settings.GNB_CDs
	GNBCDr, GNBCDg, GNBCDb =
		GNB_Settings.GNB_CDs and 0.3 or 0.6,
		GNB_Settings.GNB_CDs and 0.55 or 0.2,
		GNB_Settings.GNB_CDs and 0.14 or 0.2,
	GNBCDa == 1
	gnbACR.SaveSettings()
end

function GNBAOEQTfunc()
	GNB_Settings.GNB_AOE = not GNB_Settings.GNB_AOE
	GNBAOEr, GNBAOEg, GNBAOEb =
		GNB_Settings.GNB_AOE and 0.3 or 0.6,
		GNB_Settings.GNB_AOE and 0.55 or 0.2,
		GNB_Settings.GNB_AOE and 0.14 or 0.2,
	GNBAOEa == 1
	gnbACR.SaveSettings()
end

function GNBCDSTANCEfunc()
	GNB_Settings.GNB_Stance = not GNB_Settings.GNB_Stance
	GNBSTANCEr, GNBSTANCEg, GNBSTANCEb =
		GNB_Settings.GNB_Stance and 0.3 or 0.6,
		GNB_Settings.GNB_Stance and 0.55 or 0.2,
		GNB_Settings.GNB_Stance and 0.14 or 0.2,
	GNBSTANCEa == 1
	gnbACR.SaveSettings()
end

function GNBJUMPQTfunc()
	GNB_Settings.GNB_Jump = not GNB_Settings.GNB_Jump
	GNBJUMPr, GNBJUMPg, GNBJUMPb =
		GNB_Settings.GNB_Jump and 0.3 or 0.6,
		GNB_Settings.GNB_Jump and 0.55 or 0.2,
		GNB_Settings.GNB_Jump and 0.14 or 0.2,
	GNBJUMPa == 1
	gnbACR.SaveSettings()
end

function GNBDEFQTfunc()
	GNB_Settings.GNB_DEF = not GNB_Settings.GNB_DEF
	GNBDEFr, GNBDEFg, GNBDEFb =
		GNB_Settings.GNB_DEF and 0.3 or 0.6,
		GNB_Settings.GNB_DEF and 0.55 or 0.2,
		GNB_Settings.GNB_DEF and 0.14 or 0.2,
	GNBDEFa == 1
	gnbACR.SaveSettings()
end

function GNBLSQTfunc()
	GNB_Settings.GNB_LS = not GNB_Settings.GNB_LS
	GNBLSr, GNBLSg, GNBLSb =
		GNB_Settings.GNB_LS and 0.3 or 0.6,
		GNB_Settings.GNB_LS and 0.55 or 0.2,
		GNB_Settings.GNB_LS and 0.14 or 0.2,
	GNBLSa == 1
	gnbACR.SaveSettings()
end

function GNBVOKEQTfunc()
	GNB_Settings.GNB_AutoVoke = not GNB_Settings.GNB_AutoVoke
	gnbACR.SaveSettings()
end

function gnbACR.stanceEnabled()
	if (GNB_Settings.GNB_Stance) then
		if not gnbACR:BuffActive("royalguard") then
			ActionList:Get(1,16142):Cast(Player.id)
		end
	end
	if (not GNB_Settings.GNB_Stance) then
		if gnbACR:BuffActive("royalguard") then
			ActionList:Get(1,16142):Cast(Player.id)
		end
	end
end

function gnbACR:skillID(string)
	if gnbACR.gnbSkill[string] ~= nil then
		return gnbACR.gnbSkill[string][1]
	end
end

function gnbACR:LastAttackID(string)
	if gnbACR:skillID(string) ~= nil then
		if Player.lastcomboid == gnbACR:skillID(string) then
			return true
		end
	end
	return false
end

function gnbACR:BuffActive(string)
	if gnbACR.gnbBuff[string] ~= nil then
		if HasBuff(Player.id,gnbACR.gnbBuff[string]) then
			return true
		end
	end
	return false
end

-- Misc BS
TabIndex = 1

function gnbACR.TargetFrom(entity)
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5,distanceto="..tostring(entity))
	return (table.size(targets))
end

function gnbACR.setVar()
	for i,e in pairs(gnbACR.gnbSkill) do
		gnbACR[i] = ActionList:Get(1,e[1])
		if gnbACR[i] then
			if e[2] then
				gnbACR[i]["isready"] = gnbACR[i]:IsReady(MGetTarget().id) else gnbACR[i]["isready"] = gnbACR[i]:IsReady(Player)
			end
		end
	end
end

function gnbACR.useSkill(skl,string)
	local text = (string)
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = gnbACR[abil].isready
		if ACTready then
			gnbACR[abil]:Cast(text.id)
			return true
		end
	end
	return false
end

function GNB_oGCDReady()
	oGCDisReady = false
	WeaveTime = (CD.cdmax/5)*2
	CDMax = CD.cdmax
		if CD.cd < WeaveTime then
			oGCDisReady = true
		elseif (CD.cd > WeaveTime) or (CD.cd == 0) then
			oGCDisReady = false
		end
end

function cartridgeChecker()
cartridgeCount = Player.gauge[1]
wx_useCart = false
	if Player.level >= 88 then
		if cartridgeCount >= 3 then
			wx_useCart = true
		end
	elseif Player.level <= 87 then
		if cartridgeCount >= 2 then
			wx_useCart = true
		end
	end
	if (nomercyCD.isoncd and nomercyCD.cd >= 55) then
		wx_useCart = false
	elseif gnashingfangCD.isoncd and gnashingfangCD.cd >= 20 then
		wx_useCart = false
	elseif gnbACR:BuffActive("nomercy") then
		wx_useCart = true
	end
	
end

function GNBCheckDefensives()
GNB_NoActiveBuff = true

	if gnbACR:BuffActive("rampart") then
		GNB_NoActiveBuff = false
	end

	if gnbACR:BuffActive("nebula") then
		GNB_NoActiveBuff = false
	end
	
return GNB_NoActiveBuff

end

function GNBAggroPercentage(targetid)
    aggroTargets = MEntityList("alive,attackable,aggro,targetable,maxdistance=20,distanceto=" .. tostring(targetid))
    
	if aggroTargets ~= nil then
		for i, enemyAggro in pairs(aggroTargets) do
			if Player.incombat and enemyAggro.alive and enemyAggro.AggroPercentage < 100 then
				global_enemy = enemyAggro
				return global_enemy
			end
		end
	else
		return false
	end
end


function GNB_OneMinCheck()
local playerLevel = Player.level
GNB_OneMinReady = false
GNB_Pooling = false

	if nomercyCD.isoncd and nomercyCD.cd >= 45 then
		GNB_Pooling = true
	elseif nomercyCD.cd == 0 then
		GNB_Pooling = true
	else
		GNB_Pooling = false
	end
	if gnbACR:BuffActive("nomercy") then
		GNB_OneMinReady = true
	else
		GNB_OneMinReady = false
	end
end

function gnbACR.Cast()
	local currentTarget = MGetTarget()
	gnbACR.stanceEnabled()
	if (currentTarget == nil) then
		return false
	end
	local targetRadius = currentTarget.hitradius + 2
	if (currentTarget.attackable and (gStartCombat or currentTarget.incombat)) then
		gnbACR.setVar()
		
		if global_enemy ~= nil then
			if global_enemy.AggroPercentage < 100 and global_enemy.distance2d >= 5 then
				if GNB_Settings.GNB_AutoVoke and oGCDisReady and (global_enemy.AggroPercentage < 50 or not Player.castinginfo.lastcastid == 16143) and (not provokeCD.isoncd) then
					ActionList:Get(1,7533):Cast(global_enemy.id)
					return
				elseif GNB_Settings.GNB_AutoVoke then
					if ActionList:Get(1,16143).IsReady then
						ActionList:Get(1,16143):Cast(global_enemy.id)
						return
					end
				end
			end
		end
		
		if GNB_Settings.GNB_CDs and oGCDisReady and cartridgeCount == 0 and gnbACR.useSkill({"bloodfest"}) then
			return true
		end
		
		if GNB_OneMinReady and (currentTarget.distance2d < targetRadius) and gnbACR.useSkill({"doubledown"}) then
			return true
		end
		
		if oGCDisReady and gnbACR.useSkill({"hypervelocity", "jugularrip", "abdomentear", "eyegouge"}) then
			return true
		end
		
		if GNB_OneMinReady and gnbACR.useSkill({"sonicbreak"}) then
			return true
		end
		
		if oGCDisReady and GNB_OneMinReady and gnbACR.useSkill({"bowshock"}) then
			return true
		end
		
		if oGCDisReady and (GNB_OneMinReady or (not GNB_Pooling)) and gnbACR.useSkill({"blastingzone","dangerzone"}) then
			return true
		end
		
		if GNB_Settings.GNB_CDs and (currentTarget.distance2d <= targetRadius) and oGCDisReady and gnbACR.useSkill({"nomercy"}) then
			return true
		end
		
		if gnbACR.useSkill({"savageclaw","wickedtalon"}) then
			return true
		end
		
		if GNB_Settings.GNB_Jump and oGCDisReady and GNB_OneMinReady and gnbACR.useSkill({"roughdivide"}) then
			return true
		end
		
		if (GNB_OneMinReady or (not GNB_Pooling)) and gnbACR.useSkill({"gnashingfang"}) then
			return true
		end
		
		if wx_useCart and GNB_Settings.GNB_AOE and gnbACR.TargetFrom(Player.id) >= GNB_Settings.GNB_AOEslider and Player.level >= 72 then
			if gnbACR.useSkill({"fatedcircle"}) then
				return true
			end
		else
			if ((wx_useCart and gnbACR:LastAttackID("brutalshell")) or gnbACR:BuffActive("nomercy")) and gnbACR.useSkill({"burststrike"}) then
				return true
			end
		end			
			
		if GNB_Settings.GNB_LS and (currentTarget.distance2d > targetRadius) and gnbACR.useSkill({"lightningshot"}) then
			return true
		end
		
		if GNB_Settings.GNB_AOE and gnbACR.TargetFrom(Player.id) >= GNB_Settings.GNB_AOEslider then
			if gnbACR:LastAttackID("demonslice") and gnbACR.useSkill({"demonslaughter"}) then
				return true
			end
			if gnbACR.useSkill({"demonslice"}) then
				return true
			end
		else
			if gnbACR:LastAttackID("brutalshell") and gnbACR.useSkill({"solidbarrel"}) then
				return true
			end
			if gnbACR:LastAttackID("keenedge") and gnbACR.useSkill({"brutalshell"}) then
				return true
			end
			if gnbACR.useSkill({"keenedge"}) then
				return true
			end
		end
		
		if GNB_Settings.GNB_DEF then
			if GNB_NoActiveBuff and Player.hp.percent <= GNB_Settings.GNB_RAMPslider and gnbACR.useSkill({"rampart"}) then
				return true
			end
			
			if GNB_NoActiveBuff and Player.hp.percent <= GNB_Settings.GNB_NEBslider and gnbACR.useSkill({"nebula"}) then
				return true
			end
			
			if Player.hp.percent <= GNB_Settings.GNB_AURslider and gnbACR.useSkill({"aurora"}) then
				return true
			end
			
			if Player.hp.percent <= GNB_Settings.GNB_CAMOslider and gnbACR.useSkill({"camouflage"}) then
				return true
			end
			
			if Player.hp.percent <= GNB_Settings.GNB_SUPslider and gnbACR.useSkill({"superbolide"}) then
				return true
			end
			
			if Player.hp.percent <= GNB_Settings.GNB_HEARTslider and gnbACR.useSkill({"hoc","hos"}) then
				return true
			end
			
			if Player.hp.percent <= GNB_Settings.GNB_HEARTLIGHTslider and gnbACR.useSkill({"hol"}) then
				return true
			end
		end
		
		if GNB_Settings.GNB_reprisal and gnbACR.TargetFrom(Player.id) > GNB_Settings.GNB_REPslider and gnbACR.useSkill({"reprisal"}) then
			return true
		end
	
	return false
	end
end

function gnbACR.Draw()
	if (gnbACR.GUI.open) then
	gnbACR.GUI.visible, gnbACR.GUI.open = GUI:Begin(gnbACR.GUI.name, gnbACR.GUI.open, GUI.WindowFlags_NoResize)
	if (gnbACR.GUI.visible) then
		GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Defensives",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3
		end
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")
		end
		
		-- Tabs
		
		--Main Tab
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:BulletText("Wxlfee's Gunbreaker ACR")
				GUI:Text("1.1.1 Changelogs:")
				GUI:Text("Added Auto Voke toggle.")
				GUI:Text("Added AOE slider.")
				GUI:Text("Can be found in 'Toggles' tab.")
				GUI:Text("_________________________________________________")
			end
		--Defensives Tab
			if (TabIndex == 2) then
				GUI:SetWindowSize(367,184,0)
				local ramp
				GUI:Text("Rampart")
				GNB_Settings.GNB_RAMPslider, ramp = GUI:SliderInt("HP%", GNB_Settings.GNB_RAMPslider,0,100)
				GUI:Text("_________________________________________________")
				if (ramp) then
					d(GNB_Settings.GNB_RAMPslider)
					GNB_Settings.GNB_RAMPslider = GNB_Settings.GNB_RAMPslider
					gnbACR.SaveSettings()
				end
				local camo
				GUI:Text("Camouflage")
				GNB_Settings.GNB_CAMOslider, camo = GUI:SliderInt("HP%    ", GNB_Settings.GNB_CAMOslider,0,100)
				GUI:Text("_________________________________________________")
				if (camo) then
					GNB_Settings.GNB_CAMOslider = GNB_Settings.GNB_CAMOslider
					gnbACR.SaveSettings()
				end
				local neb
				GUI:Text("Nebula")
				GNB_Settings.GNB_NEBslider, neb = GUI:SliderInt("HP%##", GNB_Settings.GNB_NEBslider,0,100)
				GUI:Text("_________________________________________________")
				if (neb) then
					GNB_Settings.GNB_NEBslider = GNB_Settings.GNB_NEBslider
					gnbACR.SaveSettings()
				end
				local aura
				GUI:Text("Aurora")
				GNB_Settings.GNB_AURslider, aura = GUI:SliderInt("HP%###", GNB_Settings.GNB_AURslider,0,100)
				GUI:Text("_________________________________________________")
				if (aura) then
					GNB_Settings.GNB_AURslider = GNB_Settings.GNB_AURslider
					gnbACR.SaveSettings()
				end
				local sup
				GUI:Text("Superbolide")
				GNB_Settings.GNB_SUPslider, sup = GUI:SliderInt("HP% ", GNB_Settings.GNB_SUPslider,0,100)
				GUI:Text("_________________________________________________")
				if (sup) then
					GNB_Settings.GNB_SUPslider = GNB_Settings.GNB_SUPslider
					gnbACR.SaveSettings()
				end
				local hosc
				GUI:Text("Heart of Corundum")
				GNB_Settings.GNB_HEARTslider, hosc = GUI:SliderInt("HP%  ", GNB_Settings.GNB_HEARTslider,0,100)
				GUI:Text("_________________________________________________")
				if (hosc) then
					GNB_Settings.GNB_HEARTslider = GNB_Settings.GNB_HEARTslider
					gnbACR.SaveSettings()
				end
				local hol
				GUI:Text("Heart of Light")
				GNB_Settings.GNB_HEARTLIGHTslider, hol = GUI:SliderInt("HP%   ", GNB_Settings.GNB_HEARTLIGHTslider,0,100)
				GUI:Text("_________________________________________________")
				if (hol) then
					GNB_Settings.GNB_HEARTLIGHTslider = GNB_Settings.GNB_HEARTLIGHTslider
					gnbACR.SaveSettings()
				end
			end
			if (TabIndex == 3) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",344,25)
				if GUI:IsItemClicked() then
					GNBOpenQT()
				end
				GNB_Settings.GNB_reprisal, rsal = GUI:Checkbox("Use Reprisal: ", GNB_Settings.GNB_reprisal)
					if (GNB_Settings.GNB_reprisal == true) then
						local rsal
						GUI:Text("Reprisal")
						GNB_Settings.GNB_REPslider, rsal = GUI:SliderInt(">= Targets",GNB_Settings.GNB_REPslider,1,4)						
						if (rsal) then
							GNB_Settings.GNB_REPslider = GNB_Settings.GNB_REPslider
							gnbACR.SaveSettings()
						end						
					end
					if (GNB_Settings.GNB_reprisal == false) then
					end
					GUI:Text("AOE Targets required.")
					GNB_Settings.GNB_AOEslider, aoeslider = GUI:SliderInt(">= Targets##",GNB_Settings.GNB_AOEslider,2,8)
						if (aoeslider) then
							GNB_Settings.GNB_AOEslider = GNB_Settings.GNB_AOEslider
							gnbACR.SaveSettings()
						end
			end
			if (TabIndex == 4) then
				GUI:SetWindowSize(0,0,0)				
				GUI:Text("_________________________________________________")				
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")
				end				
				-- GUI:Text("_________________________________________________")
				-- GUI:Text("Cartridges: ")
				-- GUI:SameLine()
				-- GUI:Text(cartridgeCount)
				-- GUI:Text("oGCD Weave Ready: ")
				-- GUI:SameLine()
				-- if oGCDisReady == true then
					-- GUI:Text("Yes")
				-- elseif oGCDisReady == false then
					-- GUI:Text("No")
				-- end
				-- if GNB_Pooling == true then
					-- GUI:Text("GNB_Pooling: True")
				-- else
					-- GUI:Text("GNB_Pooling: False")
				-- end
				-- if GNB_OneMinReady == true then
					-- GUI:Text("GNB_OneMinReady: True")
				-- else
					-- GUI:Text("GNB_OneMinReady: False")
				-- end
				-- if aggroTargets ~= nil then
					-- for _, wx_enemy in pairs(aggroTargets) do
						-- if wx_enemy ~= nil then
							-- GUI:Text(wx_enemy.name .. ": " .. wx_enemy.AggroPercentage)
						-- end
					-- end
				-- end
				GUI:Text("_________________________________________________")
			end
		
		end
		GUI:End()
		
		if (GNB_Settings.GNB_QT_GUI) then
		local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
			gnbACR.GUIQT.visible, gnbACR.GUIQT.open = GUI:Begin(gnbACR.GUIQT.name, gnbACR.GUIQT.open, flags2)
			if (gnbACR.GUIQT.visible) then
				GUI:SetWindowSize(0,0,0)
				GUI:PushStyleColor(GUI.Col_Button, GNBCDr, GNBCDg, GNBCDb, GNBCDa)
				GNBCDButton = GUI:Button("CD",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					GNBCDQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, GNBAOEr, GNBAOEg, GNBAOEb, GNBAOEa)
				GNBAOEButton = GUI:Button("AOE",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					GNBAOEQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, GNBDEFr, GNBDEFg, GNBDEFb, GNBDEFa)
				GNBDEFButton = GUI:Button("Defensives",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					GNBDEFQTfunc()
				end
				GUI:PushStyleColor(GUI.Col_Button, GNBSTANCEr, GNBSTANCEg, GNBSTANCEb, GNBSTANCEa)
				GNBSTCButton = GUI:Button("Stance",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					GNBCDSTANCEfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, GNBJUMPr, GNBJUMPg, GNBJUMPb, GNBJUMPa)
				GNBJMPButton = GUI:Button("Jumps",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					GNBJUMPQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, GNBLSr, GNBLSg, GNBLSb, GNBLSa)
				GNBLSButton = GUI:Button("LS",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					GNBLSQTfunc()
				end
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Enable/Disable Lightning Shot")
				end
				GUI:PushStyleColor(GUI.Col_Button, GNBAVr, GNBAVg, GNBAVb, GNBAVa)
				GNBAVButton = GUI:Button("Auto Voke",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					GNBVOKEQTfunc()
				end
			end
		GUI:End()
	end
end
end

function gnbACR.OnOpen()
	gnbACR.GUI.open = true
end

function gnbACR.QTOnOpen()
	gnbACR.GUIQT.open = true
end

function gnbACR.SaveSettings()
	d("[WxlfeeCore] Settings have been saved.")
	WXSave()
end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function GNBloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    GNB_Settings = scan(GNB_Settings,tbl)
end

function gnbACR.LoadSettings()
	GNBloadsettings(tbl)
end

function gnbACR.OnLoad()
	checkFile()
	TabIndex = 1
	gnbACR.LoadSettings()	
end

function gnbACR.OnClick(mouse,shiftState,controlState,altState,entity)

end

function gnbACR.OnUpdate(event, tickcount)
	cartridgeChecker()
	GNBLoadQTColor()
	GNB_OneMinCheck()
	GNB_oGCDReady()
	GNBCheckDefensives()
	GNBAggroPercentage(Player.id)
end

return gnbACR

