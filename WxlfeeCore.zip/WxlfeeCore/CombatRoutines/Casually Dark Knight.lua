local drkACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .. [[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath .. [[DRKsettings.lua]]
local v = table.valid

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("DRKsettings.lua","w")
		localfile:write(DRK_Settings)
		file:close()
	end
end

local DRK_Settings = {

	DRK_rampartSlider = 80,
	DRK_swallSlider = 60,
	DRK_tbnSlider = 90,
	DRK_oblaSlider = 85,
	DRK_dmissionSlider = 75,
	DRK_dmindSlider = 75,
	DRK_BurnMP = false,
	DRK_Jumps = true,
	DRK_Stance = true,
	DRK_ldeadSlider = 10,
	DRK_Reprisal = true,
	DRK_repNumSlider = 3,
	DRK_Defensives = true,
	DRK_CDs = true,
	DRK_AOE = true,
	DRK_Unmend = true,
	DRK_AutoVoke = false,
	DRK_Interrupt = false,
	DRK_AOEslider = 3,
	
	DRK_QT_ON_R = 0.3,
	DRK_QT_ON_G = 0.55,
	DRK_QT_ON_B = 0.14,
	
	DRK_QT_OFF_R = 0.6,
	DRK_QT_OFF_G = 0.2,
	DRK_QT_OFF_B = 0.2,
	
}

local function WXSave()
    FileSave(ModuleSettings,DRK_Settings)
end


drkACR.classes = {
    [FFXIV.JOBS.DARKKNIGHT] = true,
} 

drkACR.GUI = {
    open = true,
    visible = true,
    name = "Casually Dark Knight",	
}

drkACR.GUIQT = {
	open = false,
	visible = true,
	name = "WX_QuickToggles",
}

CD = ActionList:Get(1,3617)
livingshadowCD = ActionList:Get(1,16472)
provokeCD = ActionList:Get(1,7533)

drkACR.drkBuff = 
	{
		grit = 743,
		blackestnight = 1178,
		delirium = 1972,		
		rampart = 1191,
		shadowwall = 747,
		darkmissionary = 1894,
		darkmind = 746,
		oblation = 2682,
		bloodweapon = 742,
	}

drkACR.drkSkill = 
	{
		hardslash = {3617,true},
		syphonstrike = {3623,true},
		souleater = {3632,true},
		unmend = {3624,true},
		saltedearth = {3639,false},
		plunge = {3640,true},
		carveandspit = {3643,true},
		abyssaldrain = {3641,true},
		edgeofdarkness = {16467,true},
		floodofdarkness = {16466,true},		
		edgeofshadow = {16470,true},
		floodofshadow = {16469,true},
		unleash = {3621,false},
		stalwartsoul = {16468,false},
		livingshadow = {16472,false},
		bloodspiller = {7392,true},
		quietus = {7391,false},
		delirium = {7390,false},
		bloodweapon = {3625,false},
		grit = {3629,false},
		blackestnight = {7393,false},
		saltanddarkness = {25755,false},
		shadowbringers = {25757,true},
		rampart = {7531,false},
		shadowwall = {3636,false},
		darkmissionary = {16471,false},
		darkmind = {3634,false},
		oblation = {25754,false},
		LivingDead = {3638,false},
		reprisal = {7535,false},
		interject = {7538,true},
		
}

-- Quick Toggle Functions
function DRKOpenQT()
	Settings.ACR.DRKOpenQT = not Settings.ACR.DRKOpenQT
	drkACR.SaveSettings()
end

function DRKLoadQTColor()
local function setColorValue(setting, trueValue, falseValue)
	if setting == true then
		return trueValue
	else
		return falseValue
	end
end

-- Defensives Button Color
DRK_DEFr = setColorValue(DRK_Settings.DRK_Defensives, DRK_Settings.DRK_QT_ON_R, DRK_Settings.DRK_QT_OFF_R)
DRK_DEFg = setColorValue(DRK_Settings.DRK_Defensives, DRK_Settings.DRK_QT_ON_G, DRK_Settings.DRK_QT_OFF_G)
DRK_DEFb = setColorValue(DRK_Settings.DRK_Defensives, DRK_Settings.DRK_QT_ON_B, DRK_Settings.DRK_QT_OFF_B)
DRK_DEFa = 1

-- Burn MP Button Color
DRK_BRNr = setColorValue(DRK_Settings.DRK_BurnMP, DRK_Settings.DRK_QT_ON_R, DRK_Settings.DRK_QT_OFF_R)
DRK_BRNg = setColorValue(DRK_Settings.DRK_BurnMP, DRK_Settings.DRK_QT_ON_G, DRK_Settings.DRK_QT_OFF_G)
DRK_BRNb = setColorValue(DRK_Settings.DRK_BurnMP, DRK_Settings.DRK_QT_ON_B, DRK_Settings.DRK_QT_OFF_B)
DRK_BRNa = 1

-- Stance Button Color
DRK_STCr = setColorValue(DRK_Settings.DRK_Stance, DRK_Settings.DRK_QT_ON_R, DRK_Settings.DRK_QT_OFF_R)
DRK_STCg = setColorValue(DRK_Settings.DRK_Stance, DRK_Settings.DRK_QT_ON_G, DRK_Settings.DRK_QT_OFF_G)
DRK_STCb = setColorValue(DRK_Settings.DRK_Stance, DRK_Settings.DRK_QT_ON_B, DRK_Settings.DRK_QT_OFF_B)
DRK_STCa = 1

-- Jump Button Color
DRK_JMPr = setColorValue(DRK_Settings.DRK_Jumps, DRK_Settings.DRK_QT_ON_R, DRK_Settings.DRK_QT_OFF_R)
DRK_JMPg = setColorValue(DRK_Settings.DRK_Jumps, DRK_Settings.DRK_QT_ON_G, DRK_Settings.DRK_QT_OFF_G)
DRK_JMPb = setColorValue(DRK_Settings.DRK_Jumps, DRK_Settings.DRK_QT_ON_B, DRK_Settings.DRK_QT_OFF_B)
DRK_JMPa = 1

-- CD Button Color
DRK_CDsr = setColorValue(DRK_Settings.DRK_CDs, DRK_Settings.DRK_QT_ON_R, DRK_Settings.DRK_QT_OFF_R)
DRK_CDsg = setColorValue(DRK_Settings.DRK_CDs, DRK_Settings.DRK_QT_ON_G, DRK_Settings.DRK_QT_OFF_G)
DRK_CDsb = setColorValue(DRK_Settings.DRK_CDs, DRK_Settings.DRK_QT_ON_B, DRK_Settings.DRK_QT_OFF_B)
DRK_CDsa = 1

-- AOE Button Color
DRK_AOEr = setColorValue(DRK_Settings.DRK_AOE, DRK_Settings.DRK_QT_ON_R, DRK_Settings.DRK_QT_OFF_R)
DRK_AOEg = setColorValue(DRK_Settings.DRK_AOE, DRK_Settings.DRK_QT_ON_G, DRK_Settings.DRK_QT_OFF_G)
DRK_AOEb = setColorValue(DRK_Settings.DRK_AOE, DRK_Settings.DRK_QT_ON_B, DRK_Settings.DRK_QT_OFF_B)
DRK_AOEa = 1

-- Unmend Button Color
DRK_Unmendr = setColorValue(DRK_Settings.DRK_Unmend, DRK_Settings.DRK_QT_ON_R, DRK_Settings.DRK_QT_OFF_R)
DRK_Unmendg = setColorValue(DRK_Settings.DRK_Unmend, DRK_Settings.DRK_QT_ON_G, DRK_Settings.DRK_QT_OFF_G)
DRK_Unmendb = setColorValue(DRK_Settings.DRK_Unmend, DRK_Settings.DRK_QT_ON_B, DRK_Settings.DRK_QT_OFF_B)
DRK_Unmenda = 1

-- AutoVoke Button Color
DRK_AutoVoker = setColorValue(DRK_Settings.DRK_AutoVoke, DRK_Settings.DRK_QT_ON_R, DRK_Settings.DRK_QT_OFF_R)
DRK_AutoVokeg = setColorValue(DRK_Settings.DRK_AutoVoke, DRK_Settings.DRK_QT_ON_G, DRK_Settings.DRK_QT_OFF_G)
DRK_AutoVokeb = setColorValue(DRK_Settings.DRK_AutoVoke, DRK_Settings.DRK_QT_ON_B, DRK_Settings.DRK_QT_OFF_B)
DRK_AutoVokea = 1

-- Interrupt
DRK_Interruptr = setColorValue(DRK_Settings.DRK_Interrupt, DRK_Settings.DRK_QT_ON_R, DRK_Settings.DRK_QT_OFF_R)
DRK_Interruptg = setColorValue(DRK_Settings.DRK_Interrupt, DRK_Settings.DRK_QT_ON_G, DRK_Settings.DRK_QT_OFF_G)
DRK_Interruptb = setColorValue(DRK_Settings.DRK_Interrupt, DRK_Settings.DRK_QT_ON_B, DRK_Settings.DRK_QT_OFF_B)
DRK_Interrupta = 1

end

function DRKCDQTfunc()
	DRK_Settings.DRK_CDs = not DRK_Settings.DRK_CDs
	drkACR.SaveSettings()
end

function DRKAOEQTfunc()
	DRK_Settings.DRK_AOE = not DRK_Settings.DRK_AOE
	drkACR.SaveSettings()
end

function DRKDEFQTfunc()
	DRK_Settings.DRK_Defensives = not DRK_Settings.DRK_Defensives
	drkACR.SaveSettings()
end

function DRKBRNQTFunc()
	DRK_Settings.DRK_BurnMP = not DRK_Settings.DRK_BurnMP
	if DRK_Settings.DRK_BurnMP then
		Settings.ACR.SetMana = 3000
	elseif not DRK_Settings.DRK_BurnMP then
		Settings.ACR.SetMana = 6000
	end
	drkACR.SaveSettings()
end	

function DRKSTCQTFunc()
	DRK_Settings.DRK_Stance = not DRK_Settings.DRK_Stance
	drkACR.SaveSettings()
end	

function DRKJMPQTFunc()
	DRK_Settings.DRK_Jumps = not DRK_Settings.DRK_Jumps
	drkACR.SaveSettings()
end

function DRKUNMQTFunc()
	DRK_Settings.DRK_Unmend = not DRK_Settings.DRK_Unmend
	drkACR.SaveSettings()
end

function DRKAutoVokeQTfunc()
	DRK_Settings.DRK_AutoVoke = not DRK_Settings.DRK_AutoVoke
	drkACR.SaveSettings()
end

function DRKInterruptQTfunc()
	DRK_Settings.DRK_Interrupt = not DRK_Settings.DRK_Interrupt
	drkACR.SaveSettings()
end

function drkACR.stanceEnabled()
	--grit
	if (DRK_Settings.DRK_Stance == false) then		
		if drkACR:BuffActive("grit") then
			ActionList:Get(1,3629):Cast(Player.id)
		end
	end
	if (DRK_Settings.DRK_Stance == true) then			
		if not drkACR:BuffActive("grit") then
			ActionList:Get(1,3629):Cast(Player.id)
		end
	end
end

function drkACR:skillID(string)
	if drkACR.drkSkill[string] ~= nil then
		return drkACR.drkSkill[string][1]
	end
end

function drkACR:LastAttackID(string)
	if drkACR:skillID(string) ~= nil then
		if Player.lastcomboid == drkACR:skillID(string) then
			return true
		end
	end
	return false
end

function drkACR:BuffActive(string)
	if drkACR.drkBuff[string] ~= nil then
		if HasBuff(Player.id,drkACR.drkBuff[string]) then
			return true
		end
	end
	return false
end


--UI Stuff
MultiTabs =  [[Main, Defensives, Test2, Discord]]
TabIndex = 1
QT_Enabled = 0

	

--Numbers and Shit
Settings.ACR.SetMana = Settings.ACR.SetMana or 6000

-- gauge[4] = Living Shadow timer, use this shit for Shadowbringer charges




function drkACR.TargetFrom(entity)
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5,distanceto="..tostring(entity))
	return (table.size(targets))
end

function DRKAggroPercentage(targetid)
    aggroTargets = MEntityList("alive,attackable,aggro,targetable,maxdistance=20,distanceto=" .. tostring(targetid))
    
	if aggroTargets ~= nil then
		for i, enemyAggro in pairs(aggroTargets) do
			if Player.incombat and enemyAggro.alive and enemyAggro.AggroPercentage < 100 then
				global_enemy = enemyAggro
				return global_enemy
			end
		end
	else
		return false
	end
end
 
 
function drkACR.setVar()
	for i,e in pairs(drkACR.drkSkill) do
		drkACR[i] = ActionList:Get(1,e[1])
		if drkACR[i] then
			if e[2] then
				drkACR[i]["isready"] = drkACR[i]:IsReady(MGetTarget().id) else drkACR[i]["isready"] = drkACR[i]:IsReady(Player)
			end
		end
	end
end


function drkACR.useSkill(skl,string)
	local text = (string)
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = drkACR[abil].isready
		if ACTready then
			drkACR[abil]:Cast(text.id)
			return true
		end
	end
	return false
end

function DRK_oGCDisReady()
	oGCDReady = false
	WeaveTime = (CD.cdmax/5)*2.25
	CDmax = CD.cdmax
		if CD.cd < WeaveTime then
			oGCDReady = true
		end
		if (CD.cd > WeaveTime) or (CD.cd == 0) then
			oGCDReady = false
		end
	return oGCDReady
end

function DRK_Burst()
DRK_burstReady = false

	if Player.gauge[4] ~= 0 then
		DRK_burstReady = true
	end
	return DRK_burstReady
end
 
function drkACR.Cast()
	drkACR.stanceEnabled()
    local currentTarget = MGetTarget()
	if (currentTarget == nil) then
		return false
	end
	local targetRadius = currentTarget.hitradius + 2	
	if (currentTarget.attackable and (gStartCombat or currentTarget.incombat)) then		
		drkACR.setVar()

		if DRK_Settings.DRK_Interrupt and oGCDisReady and currentTarget.castinginfo.castinginterruptible and drkACR.useSkill({"interject"}) then
			return true
		end

		if global_enemy ~= nil then
			if global_enemy.AggroPercentage < 100 then
				if DRK_Settings.DRK_AutoVoke and oGCDisReady and (global_enemy.AggroPercentage < 50 or not Player.castinginfo.lastcastid == 3624) and (not provokeCD.isoncd) then
					ActionList:Get(1,7533):Cast(global_enemy.id)
					return
				elseif DRK_Settings.DRK_AutoVoke then
					if ActionList:Get(1,3624).IsReady then
						ActionList:Get(1,3624):Cast(global_enemy.id)
						return
					end
				end
			end
		end
		
		--delirium + Only if Bloodweapon is active.
		if oGCDReady and drkACR:BuffActive("bloodweapon") and drkACR.useSkill({"delirium"}) then
			return true
		end
		--bloodweapon
		if oGCDReady and currentTarget.distance2d < 5 and drkACR.useSkill({"bloodweapon"}) then
			return true
		end
		
		--unmend
		if DRK_Settings.DRK_Unmend and currentTarget.distance2d > targetRadius and drkACR.useSkill({"unmend"}) then
			return true
		end
		
		--gauge[1] blood gauge
		if DRK_Settings.DRK_CDs and oGCDReady and Player.gauge ~= nil and Player.gauge[1] >= 50 and drkACR.useSkill({"livingshadow"}) then
			return true
		end	
		
		-- OP attack LOL // Quietus-Bloodspiller
		if DRK_Settings.DRK_AOE and drkACR.TargetFrom(Player.id) > 2 then
			if Player.gauge ~= nil and (Player.gauge[1] >= 50) and drkACR.useSkill({"quietus"}) then
				return true
			end
			if Player.gauge ~= nil and drkACR:BuffActive("delirium") and drkACR.useSkill({"quietus"}) then
				return true
			end			
		else
			if Player.gauge ~= nil and (Player.gauge[1] >= 50) and drkACR.useSkill({"bloodspiller"}) then
				return true
			end
			if Player.gauge ~= nil and drkACR:BuffActive("delirium") and drkACR.useSkill({"bloodspiller"}) then
				return true
			end				
		end	
		-- 123/45
		if DRK_Settings.DRK_AOE and drkACR.TargetFrom(Player.id) > 2 and currentTarget.distance2d < 4 then
			if drkACR:LastAttackID("unleash") and drkACR.useSkill({"stalwartsoul"}) then
				return true
			end		
			if drkACR.useSkill({"unleash"}) then
				return true
			end
		else
			if drkACR:LastAttackID("syphonstrike") and  drkACR.useSkill({"souleater"}) then
				return true
			end	
			if drkACR:LastAttackID("hardslash") and drkACR.useSkill({"syphonstrike"}) then
				return true
			end	
			if drkACR.useSkill({"hardslash"}) then
				return true
			end
		end		
		
		if DRK_Settings.DRK_CDs and DRK_burstReady and oGCDReady and drkACR.useSkill({"shadowbringers"}) then
			return true
		end		
		
		if drkACR.TargetFrom(Player.id) > 2 then
			if oGCDReady and Player.gauge ~= nil and ((Player.gauge[3] == 1) or (Player.mp.current >= Settings.ACR.SetMana)) and drkACR.useSkill({"floodofdarkness","floodofshadow"}) then
				return true
			end		
		else
			if oGCDReady and Player.gauge ~= nil and ((Player.gauge[3] == 1) or (Player.mp.current >= Settings.ACR.SetMana)) and drkACR.useSkill({"edgeofdarkness","edgeofshadow"}) then
				return true
			end
		end						
		--Enable/Disable Jumps
		if (DRK_Settings.DRK_Jumps == true) then
			if not Player:IsMoving() and currentTarget.distance2d < 5 then
				if oGCDReady and drkACR.useSkill({"plunge"}) then
					return true
				end			
			end
		end
		if (DRK_Settings.DRK_Jumps == false) then
		end
		--ogcd 
			--carveandspit
		if DRK_Settings.DRK_AOE and oGCDReady and drkACR.TargetFrom(currentTarget.id) > 2 then
			if drkACR.useSkill({"abyssaldrain"}) then
				drkACR.ogcdtimer = Now()
				return true
			end			
		else
			if oGCDReady and drkACR.useSkill({"carveandspit"}) then
				drkACR.ogcdtimer = Now()
				return true
			end		
		end
		--saltedearth shiz
		if DRK_Settings.DRK_CDs and oGCDReady and drkACR.useSkill({"saltanddarkness"}) then
			return true
		end
		if DRK_Settings.DRK_CDs and oGCDReady and (DRK_burstReady or livingshadowCD.cd <= 30) and currentTarget.distance2d < 2 and drkACR.useSkill({"saltedearth"}) then
			return true
		end		
		
		
		-- Defensives Innit Bruv
		if (DRK_Settings.DRK_Defensives == true) and oGCDReady then
			if drkACR.TargetFrom(currentTarget.id) >= DRK_Settings.DRK_repNumSlider and currentTarget.distance2d < 2 and drkACR.useSkill({"reprisal"}) then
				return true		
			end
			--Living Dead
			if (Player.hp.percent <= DRK_Settings.DRK_ldeadSlider) and drkACR.useSkill({"LivingDead"},"Player") then
				return
			end
			
			-- Dark Missionary (Checks HP/HP Slider)		
			if (Player.hp.percent <= DRK_Settings.DRK_dmissionSlider) and drkACR.useSkill({"darkmissionary"},"Player") then
				return
			end
			
			-- Oblation (Checks HP/HP Slider)
			if drkACR:BuffActive("oblation") then
				return
			elseif not drkACR:BuffActive("oblation") then
				if (Player.hp.percent <= DRK_Settings.DRK_oblaSlider) and drkACR.useSkill({"oblation"},"Player") then
					return
				end
			end
			
			-- The Blackest Night (Checks HP/HP Slider)		
			if (Player.hp.percent <= DRK_Settings.DRK_tbnSlider) and drkACR.useSkill({"blackestnight"},"Player") then
				return
			end
			
			-- Dark Mind (Checks HP/HP Slider)		
			if (Player.hp.percent <= DRK_Settings.DRK_dmindSlider) and drkACR.useSkill({"darkmind"},"Player") then
				return
			end
			
			
			--test me
			
			-- Shadow Wall (Checks Rampart)
			if drkACR:BuffActive("rampart") then
				return
			elseif not drkACR:BuffActive("rampart") then
				if (Player.hp.percent <= DRK_Settings.DRK_swallSlider) and drkACR.useSkill({"shadowwall"},"Player") then
					return
				end		
			end
			
			-- Rampart (Checks Shadow Wall)
			if drkACR:BuffActive("shadowwall") then
				return
			elseif not drkACR:BuffActive("shadowwall") then
				if Player.hp.percent <= DRK_Settings.DRK_rampartSlider and drkACR.useSkill({"rampart"},"Player") then
					return
				end		
			end
		end
	return false
	end
	
end



function drkACR.Draw()
    if (drkACR.GUI.open) then
		drkACR.GUI.visible, drkACR.GUI.open = GUI:Begin(drkACR.GUI.name, drkACR.GUI.open, GUI.WindowFlags_NoResize)
		if ( drkACR.GUI.visible ) then
		GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Defensives",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3
			QT_Enabled = 1
		end
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")
		end
		--Tabs
		
		--Main Tab 
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:BulletText("Wxlfee's Dark Knight ACR")
				GUI:Text("1.2.8 Changelog:")
				GUI:Text("Added Auto Voke and Interrupt")
				GUI:Text("Custom QT Colours.")
				GUI:Text("_________________________________________________")
			end
		--Defensives Tab
			if (TabIndex == 2) then
				GUI:SetWindowSize(367,184,0)
				GUI:BeginGroup()
				GUI:Text("_________________________________________________")
				--rampart Slider
				local ramp
				GUI:Text("Rampart")
				DRK_Settings.DRK_rampartSlider, ramp = GUI:SliderInt("HP%",DRK_Settings.DRK_rampartSlider,0,100)
				GUI:Text("_________________________________________________")
				if (ramp) then
					DRK_Settings.DRK_rampartSlider = DRK_Settings.DRK_rampartSlider
					WXSave()
				end
				--shadow wall slider
				local swall
				GUI:Text("Shadow Wall")
				DRK_Settings.DRK_swallSlider, swall = GUI:SliderInt("HP% ",DRK_Settings.DRK_swallSlider,0,100)
				GUI:Text("_________________________________________________")
				if (swall) then
					DRK_Settings.DRK_swallSlider = DRK_Settings.DRK_swallSlider
					drkACR.SaveSettings()
				end
				-- dark mind Slider
				local dmind
				GUI:Text("Dark Mind")
				DRK_Settings.DRK_dmindSlider, dmind = GUI:SliderInt("HP%  ",DRK_Settings.DRK_dmindSlider,0,100)
				GUI:Text("_________________________________________________")
				if (dmind) then
					DRK_Settings.DRK_dmindSlider = DRK_Settings.DRK_dmindSlider
					drkACR.SaveSettings()
				end
				-- blackest night slider
				local tbn
				GUI:Text("The Blackest Night")
				DRK_Settings.DRK_tbnSlider, tbn = GUI:SliderInt("HP%   ",DRK_Settings.DRK_tbnSlider,0,100)
				GUI:Text("_________________________________________________")
				if (tbn) then
					DRK_Settings.DRK_tbnSlider = DRK_Settings.DRK_tbnSlider
					drkACR.SaveSettings()
				end
				-- oblation slider
				local obla
				GUI:Text("Oblation")
				DRK_Settings.DRK_oblaSlider, obla = GUI:SliderInt("HP%    ",DRK_Settings.DRK_oblaSlider,0,100)
				GUI:Text("_________________________________________________")
				if (obla) then
					DRK_Settings.DRK_oblaSlider = DRK_Settings.DRK_oblaSlider
					drkACR.SaveSettings()
				end
				--dark missionary slider
				local dmission
				GUI:Text("Dark Missionary")
				DRK_Settings.DRK_dmissionSlider, dmission = GUI:SliderInt("HP%     ",DRK_Settings.DRK_dmissionSlider,0,100)
				GUI:Text("_________________________________________________")
				if (dmission) then
					DRK_Settings.DRK_dmissionSlider = DRK_Settings.DRK_dmissionSlider
					drkACR.SaveSettings()
				end
				local ldead
				GUI:Text("Living Dead")
				DRK_Settings.DRK_ldeadSlider, ldead = GUI:SliderInt("HP%      ",DRK_Settings.DRK_ldeadSlider,0,100)
				GUI:Text("_________________________________________________")
				if (ldead) then
					DRK_Settings.DRK_ldeadSlider = DRK_Settings.DRK_ldeadSlider
					drkACR.SaveSettings()
				end
				GUI:EndGroup()				
			end
		--Toggles
			if (TabIndex == 3) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",344,25)
				if GUI:IsItemClicked() then
					DRKOpenQT()
				end
				DRK_Settings.DRK_Reprisal, rsal = GUI:Checkbox("Use Reprisal: ", DRK_Settings.DRK_Reprisal)
				if (DRK_Settings.DRK_Reprisal == true) then
					local rsal
					GUI:Text("Reprisal")
					DRK_Settings.DRK_repNumSlider, rsal = GUI:SliderInt("Targets",DRK_Settings.DRK_repNumSlider,1,4)						
					if (rsal) then
						--d(DRK_Settings.DRK_repNumSlider)
						DRK_Settings.DRK_repNumSlider = DRK_Settings.DRK_repNumSlider
					end
				end
				if (DRK_Settings.DRK_Reprisal == false) then
				end
					GUI:Text("AOE Targets required.")
					DRK_Settings.DRK_AOEslider, aoeslider = GUI:SliderInt(">= Targets##",DRK_Settings.DRK_AOEslider,2,8)
						if (aoeslider) then
							DRK_Settings.DRK_AOEslider = DRK_Settings.DRK_AOEslider
							drkACR.SaveSettings()
						end
				GUI:Text("_________________________________________________")
				DRK_QT_ON_R, DRK_QT_ON_G, DRK_QT_ON_B, DRK_ON = GUI:ColorEdit3("Toggle On",DRK_Settings.DRK_QT_ON_R,DRK_Settings.DRK_QT_ON_G,DRK_Settings.DRK_QT_ON_B, GUI.ColorEditMode_NoInputs)
				if DRK_ON then
					DRK_Settings.DRK_QT_ON_R = DRK_QT_ON_R
					DRK_Settings.DRK_QT_ON_G = DRK_QT_ON_G
					DRK_Settings.DRK_QT_ON_B = DRK_QT_ON_B
					drkACR.SaveSettings()
				end
				GUI:SameLine()				
				DRK_QT_OFF_R, DRK_QT_OFF_G, DRK_QT_OFF_B, DRK_OFF = GUI:ColorEdit3("Toggle Off",DRK_Settings.DRK_QT_OFF_R,DRK_Settings.DRK_QT_OFF_G,DRK_Settings.DRK_QT_OFF_B, GUI.ColorEditMode_NoInputs)
				if DRK_OFF then
					DRK_Settings.DRK_QT_OFF_R = DRK_QT_OFF_R
					DRK_Settings.DRK_QT_OFF_G = DRK_QT_OFF_G
					DRK_Settings.DRK_QT_OFF_B = DRK_QT_OFF_B
					drkACR.SaveSettings()
				end
				GUI:SameLine()
				GUI:Button("S",20,20)
				if GUI:IsItemClicked() then
					drkACR.SaveSettings()
				end
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Save Colours.")
				end
				GUI:SameLine()
				GUI:Button("R",20,20)
				if GUI:IsItemClicked() then
					DRK_Settings.DRK_QT_ON_R = 0.3
					DRK_Settings.DRK_QT_ON_G = 0.55
					DRK_Settings.DRK_QT_ON_B = 0.14					
					DRK_Settings.DRK_QT_OFF_R = 0.6
					DRK_Settings.DRK_QT_OFF_G = 0.2
					DRK_Settings.DRK_QT_OFF_B = 0.2
					drkACR.SaveSettings()
				end
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Reset Colours.")
				end
				GUI:Text("_________________________________________________")
			end
			
			--Discord
			if (TabIndex == 4) then
				GUI:SetWindowSize(0,0,0)				
				GUI:Text("_________________________________________________")				
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")
				end					
				GUI:Text("_________________________________________________")
			end
			
		end
		GUI:End()
	end
		-- Quick Toggles Menu
	if (Settings.ACR.DRKOpenQT) then
		local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
			drkACR.GUIQT.visible, drkACR.GUIQT.open = GUI:Begin(drkACR.GUIQT.name, drkACR.GUIQT.open, flags2)
			if (drkACR.GUIQT.visible) then
				GUI:SetWindowSize(0,0,0)
				GUI:PushStyleColor(GUI.Col_Button, DRK_CDsr,DRK_CDsg,DRK_CDsb,DRK_CDsa)	
				drkCDsButton = GUI:Button("CD",90,30)				
				if GUI:IsItemClicked() then
					DRKCDQTfunc()
				end
				GUI:PopStyleColor(1)
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, DRK_AOEr,DRK_AOEg,DRK_AOEb,DRK_AOEa)	
				drkAOEButton = GUI:Button("AOE",90,30)
				if GUI:IsItemClicked() then
					DRKAOEQTfunc()
				end
				GUI:PopStyleColor(1)
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, DRK_DEFr,DRK_DEFg,DRK_DEFb,DRK_DEFa)	
				drkDEFButton = GUI:Button("Defensives",90,30)
				if GUI:IsItemClicked() then
					DRKDEFQTfunc()
				end				
				GUI:PopStyleColor(1)
				GUI:PushStyleColor(GUI.Col_Button, DRK_STCr,DRK_STCg,DRK_STCb,DRK_STCa)	
				drkSTCButton = GUI:Button("Stance",90,30)				
				if GUI:IsItemClicked() then
					DRKSTCQTFunc()
				end
				GUI:PopStyleColor(1)
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, DRK_JMPr,DRK_JMPg,DRK_JMPb,DRK_JMPa)	
				drkJMPButton = GUI:Button("Jumps",90,30)				
				if GUI:IsItemClicked() then
					DRKJMPQTFunc()
				end
				GUI:PopStyleColor(1)
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, DRK_BRNr,DRK_BRNg,DRK_BRNb,DRK_BRNa)	
				drkBRNButton = GUI:Button("Burn MP",90,30)				
				if GUI:IsItemClicked() then
					DRKBRNQTFunc()
				end
				GUI:PopStyleColor(1)
				GUI:PushStyleColor(GUI.Col_Button, DRK_Unmendr,DRK_Unmendg,DRK_Unmendb,DRK_Unmenda)	
				drkUNMButton = GUI:Button("Unmend",90,30)				
				if GUI:IsItemClicked() then
					DRKUNMQTFunc()
				end
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Enable/Disable the use of your ranged attack.")
				end
				GUI:PopStyleColor(1)
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, DRK_AutoVoker,DRK_AutoVokeg,DRK_AutoVokeb,DRK_AutoVokea)
				drkAVButton = GUI:Button("Auto Voke",90,30)
				if GUI:IsItemClicked() then
					DRKAutoVokeQTfunc()
				end
				GUI:PopStyleColor(1)
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, DRK_Interruptr, DRK_Interruptg, DRK_Interruptb, DRK_Interrupta)
				PLDRUPTbutton = GUI:Button("Interrupt",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					DRKInterruptQTfunc()
				end
			end
		GUI:End()
	end		
end


-- Load Stored Settings

function drkACR.SaveSettings()
	d("[WxlfeeCore] Settings have been saved.")
	WXSave()

end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function DRKloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    DRK_Settings = scan(DRK_Settings,tbl)
end


function drkACR.LoadSettings()
	DRKloadsettings(tbl)
end


function drkACR.OnOpen()
    drkACR.GUI.open = true
	
end
 
function drkACR.OnLoad()
	checkFile()
	TabIndex = 1
	drkACR.LoadSettings()	
end

function drkACR.QTOnOpen()
	drkACR.GUIQT.open = true
end

function drkACR.OnClick(mouse,shiftState,controlState,altState,entity)
 
end
 
function drkACR.OnUpdate(event, tickcount)	
	DRK_oGCDisReady()
	DRK_Burst()
	DRKLoadQTColor()
	DRKAggroPercentage(Player.id)

end
 
return drkACR