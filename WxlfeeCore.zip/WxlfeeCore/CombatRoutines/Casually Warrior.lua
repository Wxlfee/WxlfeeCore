local CasuallyWAR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .. [[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath .. [[WARsettings.lua]]
local v = table.valid

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("WARsettings.lua","w")
		localfile:write(WAR_Settings)
		file:close()
	end
end

WAR_Settings = {
	WAR_rampartSlider = 80,
	WAR_venSlider = 60,
	WAR_thrillSlider = 50,
	WAR_shakeSlider = 90,
	WAR_bloodSlider = 85,
	WAR_equilSlider = 60,
	WAR_Defensives = true,
	WAR_FastBuff = false,
	WAR_Stance = true,
	WAR_Jumps = true,
	WAR_holmSlider = 10,
	WAR_reprisal = true,
	WAR_repSlider = 3,
	WAR_iRelease = true,
	WAR_CDs = true,
	WAR_AOE = true,
	WAR_TOM = true,
	WAR_AutoVoke = false,
	WAR_Interrupt = false,
	WAR_AOEslider = 3,
	
	WAR_QT_ON_R = 0.3,
	WAR_QT_ON_G = 0.55,
	WAR_QT_ON_B = 0.14,
	
	WAR_QT_OFF_R = 0.6,
	WAR_QT_OFF_G = 0.2,
	WAR_QT_OFF_B = 0.2,
}

local function WXSave()
	FileSave(ModuleSettings,WAR_Settings)
end

CasuallyWAR.classes = {
    [FFXIV.JOBS.WARRIOR] = true,
	[FFXIV.JOBS.MARAUDER] = true,
} 

CasuallyWAR.GUI = {
    open = true,
    visible = true,
    name = "Casually Warrior",
}

CasuallyWAR.GUIQT = {
	open = false,
	visible = true,
	name = "WX_QuickToggles",
}

CD = ActionList:Get(1,31)
provokeCD = ActionList:Get(1,7533)
innerreleaseCD = ActionList:Get(1,7389)

CasuallyWAR.warBuff = 
	{
		defiance = 91,
		stormeye = 2677,
		innerrelease = 1177,
		infuriate = 1897,
		rampart = 1191,
		vengeance = 89,
	}
	
CasuallyWAR.warSkill = 
	{
		heavyswing = {31,true},
		maim = {37,true},
		stormpath = {42,true},
		stormeye = {45,true},
		innerbeast = {49,true},
		overpower = {41,false},
		mythriltempest = {16462,false},
		steelcyclone = {51,false},
		tomahawk = {46,true},
		fellcleave = {3549,true},
		decimate = {3550,false},
		innerchaos= {16465,true},
		innercyclone= {16463,false},
		infuriate= {52,false},
		innerrelease = {7389,false},
		upheaval = {7387,true},
		orogeny = {25752,false},
		bloodwhetting = {25751,false},
		primalrend = {25753,true},
		berserk = {38,false},
		defiance = {48,false},
		onslaught={7386,true},
		reprisal = {7535,false},
		vengeance = {44,false},
		equil = {3552,false},
		holmgang = {43,true},
		rampart = {7531,false},
		rawintuition = {3551,false},
		thrillofbattle = {40,false},
		shakeitoff = {7388,false},
		provoke = {7533,true},
		interject = {7538,true},
	}
	


-- Quick Toggle Functions
function WAROpenQT()
	Settings.ACR.WAROpenQT = not Settings.ACR.WAROpenQT
	CasuallyWAR.SaveSettings()
end

function WARLoadQTColor()
local function setColorValue(setting, trueValue, falseValue)
	if setting == true then
		return trueValue
	else
		return falseValue
	end
end

-- Defensives Button Color
WAR_DEFr = setColorValue(WAR_Settings.WAR_Defensives, WAR_Settings.WAR_QT_ON_R, WAR_Settings.WAR_QT_OFF_R)
WAR_DEFg = setColorValue(WAR_Settings.WAR_Defensives, WAR_Settings.WAR_QT_ON_G, WAR_Settings.WAR_QT_OFF_G)
WAR_DEFb = setColorValue(WAR_Settings.WAR_Defensives, WAR_Settings.WAR_QT_ON_B, WAR_Settings.WAR_QT_OFF_B)
WAR_DEFa = 1

-- Fast Buff Button Color
WAR_FSTr = setColorValue(WAR_Settings.WAR_FastBuff, WAR_Settings.WAR_QT_ON_R, WAR_Settings.WAR_QT_OFF_R)
WAR_FSTg = setColorValue(WAR_Settings.WAR_FastBuff, WAR_Settings.WAR_QT_ON_G, WAR_Settings.WAR_QT_OFF_G)
WAR_FSTb = setColorValue(WAR_Settings.WAR_FastBuff, WAR_Settings.WAR_QT_ON_B, WAR_Settings.WAR_QT_OFF_B)
WAR_FSTa = 1

-- Stance Button Color
WAR_STCr = setColorValue(WAR_Settings.WAR_Stance, WAR_Settings.WAR_QT_ON_R, WAR_Settings.WAR_QT_OFF_R)
WAR_STCg = setColorValue(WAR_Settings.WAR_Stance, WAR_Settings.WAR_QT_ON_G, WAR_Settings.WAR_QT_OFF_G)
WAR_STCb = setColorValue(WAR_Settings.WAR_Stance, WAR_Settings.WAR_QT_ON_B, WAR_Settings.WAR_QT_OFF_B)
WAR_STCa = 1

-- Jump Button Color
WAR_JMPr = setColorValue(WAR_Settings.WAR_Jumps, WAR_Settings.WAR_QT_ON_R, WAR_Settings.WAR_QT_OFF_R)
WAR_JMPg = setColorValue(WAR_Settings.WAR_Jumps, WAR_Settings.WAR_QT_ON_G, WAR_Settings.WAR_QT_OFF_G)
WAR_JMPb = setColorValue(WAR_Settings.WAR_Jumps, WAR_Settings.WAR_QT_ON_B, WAR_Settings.WAR_QT_OFF_B)
WAR_JMPa = 1

-- Inner Release Color
WAR_INRr = setColorValue(WAR_Settings.WAR_Interrupt, WAR_Settings.WAR_QT_ON_R, WAR_Settings.WAR_QT_OFF_R)
WAR_INRg = setColorValue(WAR_Settings.WAR_Interrupt, WAR_Settings.WAR_QT_ON_G, WAR_Settings.WAR_QT_OFF_G)
WAR_INRb = setColorValue(WAR_Settings.WAR_Interrupt, WAR_Settings.WAR_QT_ON_B, WAR_Settings.WAR_QT_OFF_B)
WAR_INRa = 1

-- CD Color
WAR_CDsr = setColorValue(WAR_Settings.WAR_CDs, WAR_Settings.WAR_QT_ON_R, WAR_Settings.WAR_QT_OFF_R)
WAR_CDsg = setColorValue(WAR_Settings.WAR_CDs, WAR_Settings.WAR_QT_ON_G, WAR_Settings.WAR_QT_OFF_G)
WAR_CDsb = setColorValue(WAR_Settings.WAR_CDs, WAR_Settings.WAR_QT_ON_B, WAR_Settings.WAR_QT_OFF_B)
WAR_CDsa = 1

-- AOE Color
WAR_AOEr = setColorValue(WAR_Settings.WAR_AOE, WAR_Settings.WAR_QT_ON_R, WAR_Settings.WAR_QT_OFF_R)
WAR_AOEg = setColorValue(WAR_Settings.WAR_AOE, WAR_Settings.WAR_QT_ON_G, WAR_Settings.WAR_QT_OFF_G)
WAR_AOEb = setColorValue(WAR_Settings.WAR_AOE, WAR_Settings.WAR_QT_ON_B, WAR_Settings.WAR_QT_OFF_B)
WAR_AOEa = 1

-- TOM Color
WAR_TOMr = setColorValue(WAR_Settings.WAR_TOM, WAR_Settings.WAR_QT_ON_R, WAR_Settings.WAR_QT_OFF_R)
WAR_TOMg = setColorValue(WAR_Settings.WAR_TOM, WAR_Settings.WAR_QT_ON_G, WAR_Settings.WAR_QT_OFF_G)
WAR_TOMb = setColorValue(WAR_Settings.WAR_TOM, WAR_Settings.WAR_QT_ON_B, WAR_Settings.WAR_QT_OFF_B)
WAR_TOMa = 1

WAR_AutoVoker = setColorValue(WAR_Settings.WAR_AutoVoke, WAR_Settings.WAR_QT_ON_R, WAR_Settings.WAR_QT_OFF_R)
WAR_AutoVokeg = setColorValue(WAR_Settings.WAR_AutoVoke, WAR_Settings.WAR_QT_ON_G, WAR_Settings.WAR_QT_OFF_G)
WAR_AutoVokeb = setColorValue(WAR_Settings.WAR_AutoVoke, WAR_Settings.WAR_QT_ON_B, WAR_Settings.WAR_QT_OFF_B)
WAR_AutoVokea = 1

end

function WARDEFQTFunc()
	WAR_Settings.WAR_Defensives = not WAR_Settings.WAR_Defensives
	CasuallyWAR.SaveSettings()
end

function WARFSTQTFunc()
	WAR_Settings.WAR_FastBuff = not WAR_Settings.WAR_FastBuff
	CasuallyWAR.SaveSettings()
end

function WARSTCQTFunc()
	WAR_Settings.WAR_Stance = not WAR_Settings.WAR_Stance
	CasuallyWAR.SaveSettings()
end

function WARJMPQTFunc()
	WAR_Settings.WAR_Jumps = not WAR_Settings.WAR_Jumps
	CasuallyWAR.SaveSettings()
end

function WARINTQTFunc()
	WAR_Settings.WAR_Interrupt = not WAR_Settings.WAR_Interrupt
	CasuallyWAR.SaveSettings()
end

function WARCDQTFunc()
	WAR_Settings.WAR_CDs = not WAR_Settings.WAR_CDs
	CasuallyWAR.SaveSettings()
end

function WARAOEQTFunc()
	WAR_Settings.WAR_AOE = not WAR_Settings.WAR_AOE
	CasuallyWAR.SaveSettings()
end

function WARTOMQTFunc()
	WAR_Settings.WAR_TOM = not WAR_Settings.WAR_TOM
	CasuallyWAR.SaveSettings()
end

function WARAutoVokeQTfunc()
	WAR_Settings.WAR_AutoVoke = not WAR_Settings.WAR_AutoVoke
	CasuallyWAR.SaveSettings()
end

--UI Stuff
MultiTabs =  [[Main, Defensives, Test2, Discord]]
TabIndex = 1
--Buttons

function CasuallyWAR.stanceEnabled()
	--Defiance
	if Player.level >= 10 then
		if (WAR_Settings.WAR_Stance == false) then
			if CasuallyWAR:BuffActive("defiance") then
				ActionList:Get(1,48):Cast(Player.id)
			end
		end
		if (WAR_Settings.WAR_Stance == true) then
			if not CasuallyWAR:BuffActive("defiance") then
				ActionList:Get(1,48):Cast(Player.id)
			end
		end
	end
end

function WARAggroPercentage(targetid)
    aggroTargets = MEntityList("alive,attackable,aggro,targetable,maxdistance=20,distanceto=" .. tostring(targetid))
    
	if aggroTargets ~= nil then
		for i, enemyAggro in pairs(aggroTargets) do
			if Player.incombat and enemyAggro.alive and enemyAggro.AggroPercentage < 100 then
				global_enemy = enemyAggro
				return global_enemy
			end
		end
	else
		return false
	end
end

function CasuallyWAR.fastBuff()
	local currentTarget = MGetTarget()
	if Player.level < 40 then return false end
	if not CasuallyWAR:BuffActive("stormeye") and (WAR_Settings.WAR_FastBuff == true) then
		if (currentTarget.attackable) and (currentTarget.distance < 4) then
			if Player.lastcomboid == CasuallyWAR:skillID("overpower")  and CasuallyWAR.useSkill({"mythriltempest"}) then
				return true
			end		
			if CasuallyWAR.useSkill({"overpower"}) then
				return true
			end
		end
	end
end

function CasuallyWAR:skillID(string)
	if CasuallyWAR.warSkill[string] ~= nil then
		return CasuallyWAR.warSkill[string][1]
	end
end

function CasuallyWAR:LastAttackID(string)
	if CasuallyWAR:skillID(string) ~= nil then
		if Player.lastcomboid == CasuallyWAR:skillID(string) then
			return true
		end
	end
	return false
end

function CasuallyWAR:BuffActive(string)
	if CasuallyWAR.warBuff[string] ~= nil then
		if HasBuff(Player.id,CasuallyWAR.warBuff[string]) then
			return true
		end
	end
	return false
end

function CasuallyWAR:ActiveBuffDuration(string,timeLeft)
	if CasuallyWAR.warBuff[string] ~= nil then
		if HasBuff(Player.id,CasuallyWAR.warBuff[string],0,timeLeft) then
			return true
		end
	end
	return false
end

function CasuallyWAR.TargetFrom(targetid)
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5,distanceto="..tostring(targetid))
	return (table.size(targets))
end
 
function CasuallyWAR.setVar()
	for i,e in pairs(CasuallyWAR.warSkill) do
		CasuallyWAR[i] = ActionList:Get(1,e[1])
		if CasuallyWAR[i] then
			if e[2] then
				CasuallyWAR[i]["isready"] = CasuallyWAR[i]:IsReady(MGetTarget().id) else CasuallyWAR[i]["isready"] = CasuallyWAR[i]:IsReady(Player)
			end
		end
	end
end

function CasuallyWAR.useSkill(skl,string)
	local text = (string)
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = CasuallyWAR[abil].isready
		if ACTready then
			CasuallyWAR[abil]:Cast(text.id)
			return true
		end
	end
	return false
end

function WAR_oGCDisReady()
	oGCDReady = false
	WeaveTime = (CD.cdmax/5)*2.25
	CDmax = CD.cdmax
		if CD.cd < WeaveTime then
			oGCDReady = true
		end
		if (CD.cd > WeaveTime) or (CD.cd == 0) then
			oGCDReady = false
		end
	return oGCDReady
end

function CheckTempestTimer()

-- Dummy Function For now but basically it'll track the player's Surging Tempest buff time to see whether they can fit any other attack in or if it's time to force a 123 rotation in order to replenish our Surging Tempest buff.
end
 
function CasuallyWAR.Cast()
    local currentTarget = MGetTarget()
	CasuallyWAR.stanceEnabled()
	if (currentTarget == nil) then
		return false
	end
	local targetRadius = currentTarget.hitradius + 2	
	if (currentTarget.attackable and (gStartCombat or currentTarget.incombat)) then		
		CasuallyWAR.setVar()
		
		if WAR_Settings.WAR_Interrupt and oGCDisReady and currentTarget.castinginfo.castinginterruptible and warACR.useSkill({"interject"}) then
			return true
		end
		
		if global_enemy ~= nil then
			if global_enemy.AggroPercentage < 100 and global_enemy.distance2d >= 5 then
				if WAR_Settings.WAR_AutoVoke and oGCDisReady and (global_enemy.AggroPercentage < 50 or not Player.castinginfo.lastcastid == 16143) and (not provokeCD.isoncd) then
					ActionList:Get(1,7533):Cast(global_enemy.id)
					return
				end
			end
		end
		
		--BIG ATTACKS
		if (WAR_Settings.WAR_Jumps == true) then
			if CasuallyWAR.useSkill({"primalrend"}) then
				return true
			end
		elseif (WAR_Settings.WAR_Jumps == false) then
			if currentTarget.distance2d < targetRadius and CasuallyWAR.useSkill({"primalrend"}) then
				return true
			end
		end
		
		--gauge -50
		if (CasuallyWAR:BuffActive("stormeye") and CasuallyWAR:ActiveBuffDuration("stormeye",8)) then
			if WAR_Settings.WAR_AOE and CasuallyWAR.TargetFrom(Player.id) > WAR_Settings.WAR_AOEslider then
				if Player.gauge ~= nil and ((Player.gauge[1] >= 50) or (CasuallyWAR:BuffActive("innerrelease"))) and CasuallyWAR.useSkill({"steelcyclone","decimate","innercyclone"})  then
					return true
				end		
			else
				if Player.gauge ~= nil and ((Player.gauge[1] >= 50) or (CasuallyWAR:BuffActive("innerrelease")))  and CasuallyWAR.useSkill({"innerbeast","fellcleave","innerchaos"})  then
					return true
				end
			end
		end
		
		--buff  1177
		if (WAR_Settings.WAR_CDs) and oGCDReady and (currentTarget.distance2d < targetRadius ) and (CasuallyWAR:BuffActive("stormeye") or (Player.level < 50)) and CasuallyWAR.useSkill({"berserk","innerrelease"}) then
			return true
		end		
		--ogcd
		if innerreleaseCD.cd <= 50 then
			if WAR_Settings.WAR_CDs and oGCDReady and (currentTarget.distance2d < 5 ) and (not CasuallyWAR:BuffActive("innerrelease")) and (not CasuallyWAR:BuffActive("infuriate")) and CasuallyWAR:BuffActive("stormeye") and CasuallyWAR.useSkill({"infuriate"}) then
				return true
			end
		end
		--ogcd attacks
		if WAR_Settings.WAR_AOE and CasuallyWAR.TargetFrom(Player.id) > WAR_Settings.WAR_AOEslider then
			if oGCDReady and CasuallyWAR:BuffActive("stormeye") and CasuallyWAR.useSkill({"orogeny"}) then
				return true
			end			
		else
			if oGCDReady and CasuallyWAR:BuffActive("stormeye") and CasuallyWAR.useSkill({"upheaval"}) then
				return true
			end
		end
		
		-- Fast Buff Toggle Check
		CasuallyWAR.fastBuff()
		--123(4) / 56
		if WAR_Settings.WAR_AOE and CasuallyWAR.TargetFrom(Player.id) > WAR_Settings.WAR_AOEslider and Player.level >= 10 then
			if CasuallyWAR:LastAttackID("overpower") and CasuallyWAR.useSkill({"mythriltempest"}) then
				return true
			end		
			if CasuallyWAR.useSkill({"overpower"}) then
				return true
			end			
		else
			if (CasuallyWAR:BuffActive("stormeye") and not CasuallyWAR:ActiveBuffDuration("stormeye",8)) and CasuallyWAR:LastAttackID("maim") and CasuallyWAR.useSkill({"stormeye"}) then
				return true
			end
			if not CasuallyWAR:BuffActive("stormeye") and Player.lastcomboid == CasuallyWAR:skillID("maim") and CasuallyWAR.useSkill({"stormeye"}) then
				return true
			end
			
			if CasuallyWAR:LastAttackID("maim") and CasuallyWAR.useSkill({"stormpath"}) then
				return true
			end		
			if CasuallyWAR:LastAttackID("heavyswing") and CasuallyWAR.useSkill({"maim"}) then
				return true
			end
			
			if CasuallyWAR.useSkill({"heavyswing"}) then
				return true
			end
		end

		
		--range attack 
		if WAR_Settings.WAR_TOM and (currentTarget.distance2d > targetRadius) and CasuallyWAR.useSkill({"tomahawk"}) then
			return true
		end
		-- gap closer
		if (WAR_Settings.WAR_Jumps == false) then
		end
		
		if (WAR_Settings.WAR_Jumps == true) then
			if (not Player:IsMoving()) and oGCDReady and CasuallyWAR:BuffActive("stormeye") and CasuallyWAR.useSkill({"onslaught"}) and currentTarget.distance2d < 15 then
				return true
			end
		end	
				
		--Defensives
		-- Reprisal
		if CasuallyWAR.TargetFrom(Player.id) >= WAR_Settings.WAR_repSlider and currentTarget.distance2d < 2 and CasuallyWAR.useSkill({"reprisal"}) then
			return true		
		end
			if (WAR_Settings.WAR_Defensives == true) and oGCDReady then
			--Holmgang
			if (Player.hp.percent <= WAR_Settings.WAR_holmSlider) then
				ActionList:Get(1,43):Cast(Player.id)
			end
			
			-- Equilibrium (Checks HP/HP Slider)		
			if (Player.hp.percent <= WAR_Settings.WAR_equilSlider) and CasuallyWAR.useSkill({"equil"},"Player") then
				return
			end
			
			-- Raw Intuition/Bloodwhetting (Checks HP/HP Slider)
			
			if (Player.hp.percent <= WAR_Settings.WAR_bloodSlider) and CasuallyWAR.useSkill({"bloodwhetting","rawintuition"},"Player") then
				return
			end
			
			-- Thrill of Battle (Checks HP/HP Slider)		
			if (Player.hp.percent <= WAR_Settings.WAR_thrillSlider) and CasuallyWAR.useSkill({"thrillofbattle"},"Player") then
				return
			end
			
			-- Shake It Off (Checks HP/HP Slider)		
			if (Player.hp.percent <= WAR_Settings.WAR_shakeSlider) and CasuallyWAR.useSkill({"shakeitoff"},"Player") then
				return
			end
			
			-- Vengeance (Checks Rampart)
			if HasBuff(Player.id,1191) then			
				return
			elseif not HasBuff(Player.id,1191) then
				if (Player.hp.percent <= WAR_Settings.WAR_venSlider) and CasuallyWAR.useSkill({"vengeance"},"Player") then
					return
				end		
			end
			
			-- Rampart (Checks Vengeance)
			if HasBuff(Player.id,89) then
				return
			elseif not HasBuff(Player.id,89) then
				if Player.hp.percent <= WAR_Settings.WAR_rampartSlider and CasuallyWAR.useSkill({"rampart"},"Player") then
					return
				end		
			end
		end
		
	return false
	end
end



function CasuallyWAR.Draw()
    if (CasuallyWAR.GUI.open) then
		CasuallyWAR.GUI.visible, CasuallyWAR.GUI.open = GUI:Begin(CasuallyWAR.GUI.name, CasuallyWAR.GUI.open, GUI.WindowFlags_NoResize)
		if ( CasuallyWAR.GUI.visible ) then
		GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Defensives",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3			
		end
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")
		end
		
		--Tabs
		
		--Main Tab 
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:BulletText("Wxlfee's Warrior ACR")
				GUI:Text("1.1.5 Changelogs:")
				GUI:Text("Custom QT Colours.")
				GUI:Text("Interrupt and AutoVoke added.")
				GUI:Text("_________________________________________________")
			end
		--Defensives Tab
			if (TabIndex == 2) then
				GUI:SetWindowSize(367,184,0)
				GUI:BeginGroup()
				GUI:Text("_________________________________________________")
				--rampart Slider
				local ramp
				GUI:Text("Rampart")
				WAR_Settings.WAR_rampartSlider, ramp = GUI:SliderInt("HP%",WAR_Settings.WAR_rampartSlider,0,100)
				GUI:Text("_________________________________________________")
				if (ramp) then
					CasuallyWAR.SaveSettings()
				end
				--Vengeance slider
				local ven
				GUI:Text("Vengeance")
				WAR_Settings.WAR_venSlider, ven = GUI:SliderInt("HP% ",WAR_Settings.WAR_venSlider,0,100)
				GUI:Text("_________________________________________________")
				if (ven) then
					CasuallyWAR.SaveSettings()
				end
				-- Equilibrium Slider
				local equil
				GUI:Text("Equilibrium")
				WAR_Settings.WAR_equilSlider, equil = GUI:SliderInt("HP%  ",WAR_Settings.WAR_equilSlider,0,100)
				GUI:Text("_________________________________________________")
				if (equil) then
					CasuallyWAR.SaveSettings()
				end
				-- Thrill of Battle slider
				local tob
				GUI:Text("Thrill of Battle")
				WAR_Settings.WAR_thrillSlider, tob = GUI:SliderInt("HP%   ",WAR_Settings.WAR_thrillSlider,0,100)
				GUI:Text("_________________________________________________")
				if (tob) then
					CasuallyWAR.SaveSettings()
				end
				-- Shake It Off slider
				local sio
				GUI:Text("Shake It Off")
				WAR_Settings.WAR_shakeSlider, sio = GUI:SliderInt("HP%    ",WAR_Settings.WAR_shakeSlider,0,100)
				GUI:Text("_________________________________________________")
				if (sio) then
					CasuallyWAR.SaveSettings()
				end
				--Bloodwhetting // Raw Intuition slider
				local dmission
				GUI:Text("Bloodwhetting // Raw Intuition")
				WAR_Settings.WAR_bloodSlider, dmission = GUI:SliderInt("HP%     ",WAR_Settings.WAR_bloodSlider,0,100)
				GUI:Text("_________________________________________________")
				if (dmission) then
					CasuallyWAR.SaveSettings()
				end
				-- Death Save slider
				local holm
				GUI:Text("Holmgang")
				WAR_Settings.WAR_holmSlider, ldead = GUI:SliderInt("HP%      ",WAR_Settings.WAR_holmSlider,0,100)
				GUI:Text("_________________________________________________")
				if (holm) then
					CasuallyWAR.SaveSettings()
				end
				GUI:EndGroup()				
			end
		--Toggles
			if (TabIndex == 3) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",344,25)
				if GUI:IsItemClicked() then
					WAROpenQT()
				end
				WAR_Settings.WAR_reprisal, rsal = GUI:Checkbox("Use Reprisal: ", WAR_Settings.WAR_reprisal)
					if (WAR_Settings.WAR_reprisal == true) then
						local rsal
						GUI:Text("Reprisal")
						WAR_Settings.WAR_repSlider, rsal = GUI:SliderInt("Targets",WAR_Settings.WAR_repSlider,1,4)						
						if (rsal) then
							WAR_Settings.WAR_repSlider = WAR_Settings.WAR_repSlider
							CasuallyWAR.SaveSettings()
						end						
					end
					if (WAR_Settings.WAR_reprisal == false) then
					end
					GUI:Text("AOE Targets required.")
					WAR_Settings.WAR_AOEslider, aoeslider = GUI:SliderInt(">= Targets##",WAR_Settings.WAR_AOEslider,2,8)
						if (aoeslider) then
							WAR_Settings.WAR_AOEslider = WAR_Settings.WAR_AOEslider
							CasuallyWAR.SaveSettings()
						end
				GUI:Text("_________________________________________________")
				WAR_QT_ON_R, WAR_QT_ON_G, WAR_QT_ON_B, WAR_ON = GUI:ColorEdit3("Toggle On",WAR_Settings.WAR_QT_ON_R,WAR_Settings.WAR_QT_ON_G,WAR_Settings.WAR_QT_ON_B, GUI.ColorEditMode_NoInputs)
				if WAR_ON then
					WAR_Settings.WAR_QT_ON_R = WAR_QT_ON_R
					WAR_Settings.WAR_QT_ON_G = WAR_QT_ON_G
					WAR_Settings.WAR_QT_ON_B = WAR_QT_ON_B
					CasuallyWAR.SaveSettings()
				end
				GUI:SameLine()				
				WAR_QT_OFF_R, WAR_QT_OFF_G, WAR_QT_OFF_B, WAR_OFF = GUI:ColorEdit3("Toggle Off",WAR_Settings.WAR_QT_OFF_R,WAR_Settings.WAR_QT_OFF_G,WAR_Settings.WAR_QT_OFF_B, GUI.ColorEditMode_NoInputs)
				if WAR_OFF then
					WAR_Settings.WAR_QT_OFF_R = WAR_QT_OFF_R
					WAR_Settings.WAR_QT_OFF_G = WAR_QT_OFF_G
					WAR_Settings.WAR_QT_OFF_B = WAR_QT_OFF_B
					CasuallyWAR.SaveSettings()
				end
				GUI:SameLine()
				GUI:Button("S",20,20)
				if GUI:IsItemClicked() then
					CasuallyWAR.SaveSettings()
				end
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Save Colours.")
				end
				GUI:SameLine()
				GUI:Button("R",20,20)
				if GUI:IsItemClicked() then
					WAR_Settings.WAR_QT_ON_R = 0.3
					WAR_Settings.WAR_QT_ON_G = 0.55
					WAR_Settings.WAR_QT_ON_B = 0.14					
					WAR_Settings.WAR_QT_OFF_R = 0.6
					WAR_Settings.WAR_QT_OFF_G = 0.2
					WAR_Settings.WAR_QT_OFF_B = 0.2
					CasuallyWAR.SaveSettings()
				end
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Reset Colours.")
				end
				GUI:Text("_________________________________________________")
			end
		--Discord
			if (TabIndex == 4) then
				GUI:SetWindowSize(0,0,0)				
				GUI:Text("_________________________________________________")				
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")
				end
					
				GUI:Text("_________________________________________________")
			end
		end
		GUI:End()
	end
		-- Quick Toggles Menu
		if (Settings.ACR.WAROpenQT) then
		local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
			CasuallyWAR.GUIQT.visible, CasuallyWAR.GUIQT.open = GUI:Begin(CasuallyWAR.GUIQT.name, CasuallyWAR.GUIQT.open, flags2)
			if (CasuallyWAR.GUIQT.visible) then
				GUI:SetWindowSize(0,0,0)
				GUI:PushStyleColor(GUI.Col_Button, WAR_CDsr,WAR_CDsg,WAR_CDsb,WAR_CDsa)
				WARCDs = GUI:Button("CD",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					WARCDQTFunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, WAR_AOEr,WAR_AOEg,WAR_AOEb,WAR_AOEa)
				WARAOE = GUI:Button("AOE",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					WARAOEQTFunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, WAR_DEFr,WAR_DEFg,WAR_DEFb,WAR_DEFa)
				WARDefensives = GUI:Button("Defensives",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					WARDEFQTFunc()
				end
				GUI:PushStyleColor(GUI.Col_Button, WAR_STCr,WAR_STCg,WAR_STCb,WAR_STCa)	
				WARStance = GUI:Button("Stance",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					WARSTCQTFunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, WAR_JMPr,WAR_JMPg,WAR_JMPb,WAR_JMPa)	
				WARJumps = GUI:Button("Jumps",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					WARJMPQTFunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, WAR_FSTr,WAR_FSTg,WAR_FSTb,WAR_FSTa)	
				WARFastBuff = GUI:Button("Fast Buff",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					WARFSTQTFunc()
				end
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Uses AOE attack to grant Storm Eye buff faster.")
				end
				GUI:PushStyleColor(GUI.Col_Button, WAR_TOMr,WAR_TOMg,WAR_TOMb,WAR_TOMa)
				WARCDs = GUI:Button("Tomahawk",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					WARTOMQTFunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, WAR_AutoVoker,WAR_AutoVokeg,WAR_AutoVokeb,WAR_AutoVokea)
				WARAutoVoke = GUI:Button("Auto Voke",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					WARAutoVokeQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, WAR_INRr,WAR_INRg,WAR_INRb,WAR_INRa)
				WARInterrupt = GUI:Button("Interrupt",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					WARINTQTFunc()
				end
			end
		GUI:End()
	end
end

function CasuallyWAR.SaveSettings()
	d("[WxlfeeCore] Settings have been saved.")
	WXSave()

end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function WARloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    WAR_Settings = scan(WAR_Settings,tbl)
end

function CasuallyWAR.LoadSettings()
	WARloadsettings(tbl)	
end

 
function CasuallyWAR.OnOpen()
    CasuallyWAR.GUI.open = true
end

function CasuallyWAR.QTOnOpen()
	CasuallyWAR.GUIQT.open = true
end
 
function CasuallyWAR.OnLoad()
	checkFile()
	TabIndex = 1
	CasuallyWAR.LoadSettings()
	WARLoadQTColor()
end
 
function CasuallyWAR.OnClick(mouse,shiftState,controlState,altState,entity)
 
end
 
function CasuallyWAR.OnUpdate(event, tickcount)
	WAR_oGCDisReady()
	WARLoadQTColor()
	WARAggroPercentage(targetid)
end
 
return CasuallyWAR