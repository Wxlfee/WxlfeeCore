local ninACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath..[[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath..[[NINsettings.lua]]
local v = table.valid

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("NINsettings.lua","w")
		localfile:write(NIN_Settings)
		file:close()
	end
end

function fuckingmudracheckatthetopofmylua()
mudraActive = false
	if HasBuff(Player.id,496) then
		mudraActive = true
	end
end

NIN_Settings = {

	NIN_QT_GUI = false,
	NIN_POS_GUI = false,
	
	NIN_CD = true,
	NIN_AOE = true,
	NIN_MUD = true,
	NIN_HIDE = false,
	NIN_DEF = true,
	
	NIN_SWSlider = 80,
	NIN_BBSlider = 60,
	NIN_FSlider = 90,
	NIN_SSSlider = 65,
	
}


local function WXSave()
	FileSave(ModuleSettings,NIN_Settings)
end

CD = ActionList:Get(1,2240)
trickAttackCD = ActionList:Get(1,2258)
mugCD = ActionList:Get(1,2248)
tcjCD = ActionList:Get(1,7403)
kassatsuCD = ActionList:Get(1,2264)
dreamwithinadreamCD = ActionList:Get(1,3566)
bunshinCD = ActionList:Get(1,16493)
mudraCD = ActionList:Get(1,2263)

HutonMudraIndex = HutonMudraIndex or 1
DotonMudraIndex = DotonMudraIndex or 1
SuitonMudraIndex = SuitonMudraIndex or 1
RaitonMudraIndex = RaitonMudraIndex or 1
HyoshoMudraIndex = HyoshoMudraIndex or 0

ActivateHuton = ActivateHuton or false
ActivateDoton = ActivateDoton or false
ActivateSuiton = ActivateSuiton or false
ActivateRaiton = ActivateRaiton or false
ActivateHyosho = ActivateHyosho or false


ninACR.GUI = {
	open = true,
	visible = true,
	name = "Casually Ninja",
}


ninACR.GUIQT = {
	open = true,
	visible = true,
	name = "WX_QuickToggles",
}

ninACR.GUIPOS = {
	open = false,
	visible = true,
	name = "Positionals",
}

ninACR.classes = {
	[FFXIV.JOBS.NINJA] = true,
	[FFXIV.JOBS.ROGUE] = true,
}

ninACR.ninBuff = {
	
	kassatsu = 497,
	doton = 501,
	suiton = 507,
	trickattack = 3254, -- on target
	mudra = 496,
	raijuready = 2690,
	TCJ = 1186,
	hidden = 614,
	meisui = 2689,
	phantomkamaitachi = 2723,
}

ninACR.ninSkill = {

	spinningedge = {2240,true},
	gustslash = {2242,true},
	aeolianedge = {2255,true},
	armorcrush = {3563,true},
	deathblossom = {2254,false},
	haukkemuj = {16488,false},
	trickattack = {2258,true},
	assasinate = {2246,true},
	dreamwithinadream = {3566,true},
	meisui = {16489,false},
	bhavacakra = {7402,true},
	hellfrog = {7401,false},
	huraikin = {25876,true},
	fleetingRaiju = {25778,true},
	bunshin = {16493,false},
	phantomkamaitachi = {25774,true},
	mug = {2248,true},
	
	jin = {2263,false},
	chi = {2261,false},
	ten = {2259,false},
	jin2 = {18807,false},
	chi2 = {18806,false},
	ten2 = {18805,false},
	
	huton = {2269,false},
	doton = {2270,false},
	suiton = {2271,true},
	raiton = {2267,true},
	throwingdagger = {2247,true},
	kassatsu = {2264,false},
	hyosho = {16492,true},
	TCJ = {7403,false},
	fumashuriken = {18873,true},
	tcj_raiton = {18877,true},
	tcj_hyoton = {18878,true},
	tcj_suiton = {18881,true},
	
	--Defensives
	shadeshift = {2241,false},
	bloodbath = {7542,false},
	feint = {7549,true},
	secondwind = {7541,false},
	hide = {2245,false},
	
	
}

-- Positional Bullshit
function IsFlanking(entity)
	if not entity or entity.id == Player.id then return false end

	if (round(entity.pos.h,4) > round(math.pi,4) or round(entity.pos.h,4) < (-1 * round(math.pi,4))) then
		return true
	end
	
    if (entity.distance2d <= ml_global_information.AttackRange or not dorangecheck) then
        local entityHeading = nil
        
        if (entity.pos.h < 0) then
            entityHeading = entity.pos.h + 2 * math.pi
        else
            entityHeading = entity.pos.h
        end
		
		local myPos = Player.pos
        local entityAngle = math.atan2(myPos.x - entity.pos.x, myPos.z - entity.pos.z)        
        local deviation = entityAngle - entityHeading
        local absDeviation = math.abs(deviation)
        local leftover = math.abs(absDeviation - math.pi)
		
        if ((leftover < (math.pi * 1.75) and leftover > (math.pi * 1.25)) or
			(leftover < (math.pi * .75) and leftover > (math.pi * .25))) 
		then
            return true
        end
    end
	
    return false
end

function IsBehind(entity)
	if not entity or entity.id == Player.id then return false end
	
	if (round(entity.pos.h,4) > round(math.pi,4) or round(entity.pos.h,4) < (-1 * round(math.pi,4))) then
		return true
	end
	
    if (entity.distance2d <= ml_global_information.AttackRange or not dorangecheck) then
        local entityHeading = nil
        
        if (entity.pos.h < 0) then
            entityHeading = entity.pos.h + 2 * math.pi
        else
            entityHeading = entity.pos.h
        end
        
		local myPos = Player.pos
        local entityAngle = math.atan2(myPos.x - entity.pos.x, myPos.z - entity.pos.z)        
        local deviation = entityAngle - entityHeading
        local absDeviation = math.abs(deviation)
        local leftover = math.abs(absDeviation - math.pi)
		
        if (leftover > (math.pi * 1.75) or leftover < (math.pi * .25)) then
            return true
        end
    end
    return false
end

function IsFront(entity)
	if not entity or entity.id == Player.id then return false end
	
	if (round(entity.pos.h,4) > round(math.pi,4) or round(entity.pos.h,4) < (-1 * round(math.pi,4))) then
		return true
	end
	
	if (entity.distance2d <= ml_global_information.AttackRange or not dorangecheck) then
		local entityHeading = nil
		
		if (entity.pos.h < 0) then
			entityHeading = entity.pos.h + 2 * math.pi
		else
			entityHeading = entity.pos.h
		end
		
		local myPos = Player.pos
		local entityAngle = math.atan2(myPos.x - entity.pos.x, myPos.z - entity.pos.z) 
		local deviation = entityAngle - entityHeading
		local absDeviation = math.abs(deviation)
		local leftover = math.abs(absDeviation - math.pi)
		
		if (leftover > (math.pi * .75) and leftover < (math.pi * 1.25)) then
			return true
		end
	end
    return false
end

-- Output current player positional
function playerPos(target)
	target = MGetTarget()
	positional = ""
	if (IsBehind(target)) then
		positional = "Rear"
	end
	if (IsFlanking(target)) then
		positional = "Flank"
	end
	if (IsFront(target)) then
		positional = "Front"
	end
	if HasBuff(Player.id,1250) then
		positional = "T.North"
	end
	return positional
end

-- Next Positional Attack
function positionalCheck()
	CorrectPos = ""
	if Player.gauge[2] ~= 0 and Player.gauge[2] < 30000 then
		CorrectPos = "Flank"
	end
	if Player.gauge[2] ~= 0 and Player.gauge[2] > 30000 then
		CorrectPos = "Rear"
	end
	if mugCD.isoncd and mugCD.cd <= 20 then
		CorrectPos = "Rear"
	end
	return CorrectPos
end

--Funky Colour Shiz
function NINLoadQTColor()
local function setColorValue(setting, trueValue, falseValue)
	if setting == true then
		return trueValue
	else
		return falseValue
	end
end

--CD Button Color
NIN_CDr = setColorValue(NIN_Settings.NIN_CD, 0.3,0.6)
NIN_CDg = setColorValue(NIN_Settings.NIN_CD, 0.55,0.2)
NIN_CDb = setColorValue(NIN_Settings.NIN_CD, 0.14,0.2)
NIN_CDa = 1

--AOE Button Color
NIN_AOEr = setColorValue(NIN_Settings.NIN_AOE, 0.3,0.6)
NIN_AOEg = setColorValue(NIN_Settings.NIN_AOE, 0.55,0.2)
NIN_AOEb = setColorValue(NIN_Settings.NIN_AOE, 0.14,0.2)
NIN_AOEa = 1

--Mudra Button Color
NIN_MUDr = setColorValue(NIN_Settings.NIN_MUD, 0.3,0.6)
NIN_MUDg = setColorValue(NIN_Settings.NIN_MUD, 0.55,0.2)
NIN_MUDb = setColorValue(NIN_Settings.NIN_MUD, 0.14,0.2)
NIN_MUDa = 1

--Hide Button Color
NIN_HIDEr = setColorValue(NIN_Settings.NIN_HIDE, 0.3,0.6)
NIN_HIDEg = setColorValue(NIN_Settings.NIN_HIDE, 0.55,0.2)
NIN_HIDEb = setColorValue(NIN_Settings.NIN_HIDE, 0.14,0.2)
NIN_HIDEa = 1

--Defensives Button Color
NIN_DEFr = setColorValue(NIN_Settings.NIN_DEF, 0.3,0.6)
NIN_DEFg = setColorValue(NIN_Settings.NIN_DEF, 0.55,0.2)
NIN_DEFb = setColorValue(NIN_Settings.NIN_DEF, 0.14,0.2)
NIN_DEFa = 1

end

-- QT Functions

function NINCDQTfunc()
	NIN_Settings.NIN_CD = not NIN_Settings.NIN_CD
	NIN_CDr, NIN_CDg, NIN_CDb =
		NIN_Settings.NIN_CD and 0.3 or 0.6,
		NIN_Settings.NIN_CD and 0.55 or 0.2,
		NIN_Settings.NIN_CD and 0.14 or 0.2,
	NIN_CDa == 1
	ninACR.SaveSettings()
end

function NINAOEQTfunc()
	NIN_Settings.NIN_AOE = not NIN_Settings.NIN_AOE
	NIN_AOEr, NIN_AOEg, NIN_AOEb =
		NIN_Settings.NIN_AOE and 0.3 or 0.6,
		NIN_Settings.NIN_AOE and 0.55 or 0.2,
		NIN_Settings.NIN_AOE and 0.14 or 0.2,
	NIN_AOEa == 1
	ninACR.SaveSettings()
end

function NINMUDQTfunc()
	NIN_Settings.NIN_MUD = not NIN_Settings.NIN_MUD
	NIN_MUDr, NIN_MUDg, NIN_MUDb =
		NIN_Settings.NIN_MUD and 0.3 or 0.6,
		NIN_Settings.NIN_MUD and 0.55 or 0.2,
		NIN_Settings.NIN_MUD and 0.14 or 0.2,
	NIN_MUDa == 1
	ninACR.SaveSettings()
end

function NINHIDEQTfunc()
	NIN_Settings.NIN_HIDE = not NIN_Settings.NIN_HIDE
	NIN_HIDEr, NIN_HIDEg, NIN_HIDEb =
		NIN_Settings.NIN_HIDE and 0.3 or 0.6,
		NIN_Settings.NIN_HIDE and 0.55 or 0.2,
		NIN_Settings.NIN_HIDE and 0.14 or 0.2,
	NIN_HIDEa == 1
	ninACR.SaveSettings()
end

function NINDEFQTfunc()
	NIN_Settings.NIN_DEF = not NIN_Settings.NIN_DEF
	NIN_DEFr, NIN_DEFg, NIN_DEFb =
		NIN_Settings.NIN_DEF and 0.3 or 0.6,
		NIN_Settings.NIN_DEF and 0.55 or 0.2,
		NIN_Settings.NIN_DEF and 0.14 or 0.2,
	NIN_DEFa == 1
	ninACR.SaveSettings()
end


function NINOpenPOS()
	Settings.ACR.NINOpenPOS = not Settings.ACR.NINOpenPOS
	ninACR.SaveSettings()
end


function checkMudraStacks()
mudraStacks = mudraStacks or 2
if (mudraCD.cd <= 20) and not (mudraCD.cd == 0) then
	mudraStacks = 0
elseif (mudraCD.cd == 0) then
	mudraStacks = 2
elseif (mudraCD.cd >= 20 and mudraCD.cd <= 40) then
	mudraStacks = 1
end
	return mudraStacks
end

function mudraIsReady()
mudraReady = false
	if (mudraStacks ~= 0) then
		mudraReady = true
	end
end

function kassatsuIsReady()
kassaReady = false
	if ninACR:ActiveBuff("kassatsu") then
		kassaReady = true
	end
	return kassaReady
end

function MudraCombos()
	if ActivateHuton then
		hutonCombo()
	end
	if ActivateDoton then
		dotonCombo()
	end
	if ActivateSuiton then
		suitonCombo()
	end
	if ActivateRaiton then
		suitonCombo()
	end
	if ActivateHyosho then
		hyoshoCombo()
	end
end

function resetMudraCombos()	
	mudraActive = false
	chiUsed = false
	jinUsed = false
	tenUsed = false
	--Huton
	HutonCompletedMudra = false
	
	-- Doton
	DotonCompletedMudra = false
	
	
	-- Suiton
	SuitonCompletedMudra = false
	
	-- Raiton
	RaitonCompletedMudra = false
	
	--Hyosho
	HyoshoCompletedMudra = false
end

chiUsed = false
jinUsed = false
tenUsed = false


function hutonCombo()
	ninACR.setVarMudra()
	HutonCompletedMudra = false
	local storedTime = storedTime or 15
	
	storedTime = storedTime + 1
	if storedTime > 15 then
		storedTime = 15
	end
	
	-- Jin
	if Player.castinginfo.lastcastid == 18807 then
		jinUsed = true
	-- Chi2
	elseif Player.castinginfo.lastcastid == 18806 then
		chiUsed = true
	-- Ten2
	elseif Player.castinginfo.lastcastid == 18805 then
		tenUsed = true
		HutonCompletedMudra = true
	end
		
	if storedTime == 15 and not HutonCompletedMudra then
		if chiUsed and ninACR.useSkill({"ten2"}) then
			storedTime = 0
			return true
		elseif jinUsed and ninACR.useSkill({"chi2"}) then
			storedTime = 0
			return true
		elseif ninACR.useSkill({"jin"}) then
			storedTime = 0
			return true
		end
	end
	return false
end

function dotonCombo()
	ninACR.setVarMudra()
    local dotonMudra = {"jin", "ten2", "chi2"}
    local storedTime = storedTime or 15
	DotonCompletedMudra = false

    storedTime = storedTime + 1
    if storedTime > 15 then
        storedTime = 15
    end	
	
	-- Jin
	if Player.castinginfo.lastcastid == 2263 then
		jinUsed = true
	-- Chi2
	elseif Player.castinginfo.lastcastid == 18806 then
		chiUsed = true
		DotonCompletedMudra = true
	-- Ten2
	elseif Player.castinginfo.lastcastid == 18805 then
		tenUsed = true		
	end
		
	if storedTime == 15 and not DotonCompletedMudra then
		if tenUsed and ninACR.useSkill({"chi2"}) then
			storedTime = 0
			return true
		elseif jinUsed and ninACR.useSkill({"ten2"}) then
			storedTime = 0
			return true
		elseif ninACR.useSkill({"jin"}) then
			storedTime = 0
			return true
		end
	end
	return false
end

function raitonCombo()
	ninACR.setVarMudra()
    local raitonMudra = {"ten", "chi2"}
    local storedTime = storedTime or 15
	RaitonCompletedMudra = false

    storedTime = storedTime + 1
    if storedTime > 15 then
        storedTime = 15
    end	
	

	-- Chi2
	if Player.castinginfo.lastcastid == 18806 then
		chiUsed = true
		RaitonCompletedMudra = true
	-- Ten
	elseif Player.castinginfo.lastcastid == 2259 then
		tenUsed = true		
	end		
		
	if storedTime == 15 and not RaitonCompletedMudra then
		if tenUsed and ninACR.useSkill({"chi2"}) then
			storedTime = 0
			return true
		elseif ninACR.useSkill({"ten"}) then
			storedTime = 0
			return true
		end
	end
	return false
end

function suitonCombo()
	ninACR.setVarMudra()
    local suitonMudra = {"ten", "chi2", "jin2"}
    local storedTime = storedTime or 15
	SuitonCompletedMudra = false

    storedTime = storedTime + 1
    if storedTime > 15 then
        storedTime = 15
    end	
	
	-- Chi2
	if Player.castinginfo.lastcastid == 18806 then
		chiUsed = true
	-- Ten
	elseif Player.castinginfo.lastcastid == 2259 then
		tenUsed = true
	-- Jin2
	elseif Player.castinginfo.lastcastid == 18807 then
		jinUsed = true
		SuitonCompletedMudra = true
	end
		
	if storedTime == 15 and not SuitonCompletedMudra then
		if chiUsed and ninACR.useSkill({"jin2"}) then
			storedTime = 0
			return true
		elseif tenUsed and ninACR.useSkill({"chi2"}) then
			storedTime = 0
			return true
		elseif ninACR.useSkill({"ten"}) then
			storedTime = 0
			return true
		end
	end
	return false
end

function hyoshoCombo()
	ninACR.setVarMudra()
    local hyoshoMudra = {"chi2", "jin2"}
    local storedTime = storedTime or 15
	HyoshoCompletedMudra = false

    storedTime = storedTime + 1
    if storedTime > 15 then
        storedTime = 15
    end	
	
	-- Chi2
	if Player.castinginfo.lastcastid == 18806 then
		chiUsed = true
	-- Ten
	elseif Player.castinginfo.lastcastid == 18807 then
		jinUsed = true
		HyoshoCompletedMudra = true
	end	
		
	if storedTime == 15 and not HyoshoCompletedMudra then
		if chiUsed and ninACR.useSkill({"jin2"}) then
			storedTime = 0
			return true
		elseif ninACR.useSkill({"chi2"}) then
			storedTime = 0
			return true
		end
	end
	return false
end

function ninACR:AttackID(string)
	if ninACR.ninSkill[string] ~= nil then
		return ninACR.ninSkill[string][1]
	end
end

function ninACR:LastAttackID(string)
	if ninACR:AttackID(string) ~= nil then
		if Player.lastcomboid == ninACR:AttackID(string) then
			return true
		end
	end
	return false
end

function ninACR:ActiveBuff(string)
	if ninACR.ninBuff[string] ~= nil then
		if HasBuff(Player.id,ninACR.ninBuff[string]) then
			return true
		end
	end
	return false
end

function ninACR:ActiveBuffDuration(string,timeLeft)
	if ninACR.drgBuff[string] ~= nil then
		if HasBuff(Player.id,ninACR.drgBuff[string],0,timeLeft) then
			return true
		end
	end
	return false
end

function ninACR:ActiveBuffTarget(string)
	if ninACR.ninBuff[string] ~= nil then
		if HasBuff(MGetTarget().id,ninACR.ninBuff[string]) then
			return true
		end
	end
	return false
end

function ninACR:ActiveBuffTargetDuration(string,timeLeft)
	if ninACR.ninBuff[string] ~= nil then
		if HasBuff(MGetTarget().id,ninACR.ninBuff[string],0,timeLeft) then
			return true
		end
	end
	return false
end

function ninACR.TargetFrom(entity)
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5,incombat,distanceto="..tostring(entity))
	return (table.size(targets))
end

function ninACR.TargetEnemyNearby()
	local isEnemy = false
	local targets = MEntityList("alive,incombat")
	if targets ~= nil then
		isEnemy = true
	end
	return isEnemy
end

function ninACR.setVar()
	for i,e in pairs(ninACR.ninSkill) do
		ninACR[i] = ActionList:Get(1,e[1])
		if ninACR[i] then
			if e[2] then
				ninACR[i]["isready"] = ninACR[i]:IsReady(MGetTarget().id) else ninACR[i]["isready"] = ninACR[i]:IsReady(Player)
			end
		end
	end
end

function ninACR.setVarMudra()
	for i,e in pairs(ninACR.ninSkill) do
		ninACR[i] = ActionList:Get(1,e[1])
		if ninACR[i] then
			ninACR[i]["isready"] = ninACR[i]:IsReady(Player)
		end
	end
end

function ninACR.useSkill(skl,string)
	local text = (string)
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = ninACR[abil].isready
		if ACTready then
			ninACR[abil]:Cast(text.id)
			return true
		end
	end
	return false
end

function NIN_oGCDisReady()
	oGCDReady = false
	WeaveTime = (CD.cdmax/5)*2.25
	CDmax = CD.cdmax
		if (CD.cd > WeaveTime) or (CD.cd == 0) then
			oGCDReady = false
		end
		if (CD.cd < WeaveTime) then
			oGCDReady = true
		end
		if mudraActive then
			oGCDReady = false
		end
end

function hideOOC()
	inCombat = Player.incombat
	if NIN_Settings.NIN_HIDE and not inCombat and not ninACR:ActiveBuff("hidden") then
		ActionList:Get(1,2245):Cast(Player.id)
	elseif not NIN_Settings.NIN_HIDE and ninACR:ActiveBuff("hidden") then
		SendTextCommand("/statusoff Hidden")
	end
end

useDoton = false
useHyosho = false
useRaiton = false
useSuiton = false

function NIN_Mudra_Combos()
local playerLevel = Player.level

	if (not ninACR:ActiveBuff("mudra")) then
		if Player.level >= 76 and ninACR:ActiveBuff("kassatsu") and Player.gauge[2] ~= 0 then
			useHyosho = true
		else
			useHyosho = false
		end
	end
	
	if (not ninACR:ActiveBuff("mudra")) and (not ninACR:ActiveBuff("TCJ")) and mudraReady then
		if (not ninACR:ActiveBuff("suiton")) and mugCD.isoncd and ((not trickAttackCD.isoncd) or (trickAttackCD.isoncd and trickAttackCD.cd >= 58)) and Player.gauge[2] ~= 0 then
			useSuiton = true
		else
			useSuiton = false
		end
		
		if (not ninACR:ActiveBuff("meisui")) and (not ninACR:ActiveBuff("phantomkamaitachi")) and (not ninACR:ActiveBuff("kassatsu")) and ninACR.TargetFrom(Player.id) > 2 and Player.level >= 45 and Player.gauge[2] ~= 0 then
			useDoton = true
		else
			useDoton = false
		end
		
		if (not ninACR:ActiveBuff("meisui")) and (not ninACR:ActiveBuff("phantomkamaitachi")) and (not ninACR:ActiveBuff("kassatsu")) and kassatsuCD.isoncd and Player.level >= 35 and (trickAttackCD.isoncd and trickAttackCD.cd <= 41) and Player.gauge[2] ~= 0 then
			useRaiton = true
		else	
			useRaiton = false
		end
	end
end

function ninACR.Cast()
	hideOOC()
	storedTime = storedTime
	if storedTime == nil then
		storedTime = 0
	end
	storedTime = storedTime + 1
	if storedTime > 15 then
		storedTime = 15
	end	
	local currentTarget = MGetTarget()
	if Player.incombat then
	
		if NIN_Settings.NIN_MUD then
			ninACR.setVarMudra()
			if useHyosho then
				if Player.castinginfo.lastcastid == 18807 then
					useHyosho = false
					HyoshoCompletedMudra = true
				elseif Player.castinginfo.lastcastid == 18806 and ninACR.useSkill({"jin2"}) then
					return true
				elseif ninACR.useSkill({"chi2"}) then
					return true
				end
				return
			end
		end
		
		if NIN_Settings.NIN_MUD then
			ninACR.setVarMudra()
	
			if (Player.level >= 50) and oGCDReady and not ninACR:ActiveBuff("kassatsu") and trickAttackCD.isoncd and dreamwithinadreamCD.isoncd and ninACR.useSkill({"kassatsu"}) then
				return true
			end
			
			-- Huton | Combo
			if (ninACR.TargetFrom(Player.id) > 0) and mudraReady and mudraStacks >= 1 and ((Player.level >= 45) and (Player.level < 60)) and (Player.gauge[2] == 0) then
				hutonCombo()
			end

			
			-- Suiton | Combo
			if useSuiton then				
				if Player.castinginfo.lastcastid == 18807 then
					useSuiton = false
					SuitonCompletedMudra = true
					return
				elseif Player.castinginfo.lastcastid == 18806 and ninACR.useSkill({"jin2"}) then
					storedTime = 0
					return true
				elseif Player.castinginfo.lastcastid == 2259 and ninACR.useSkill({"chi2"}) then
					storedTime = 0
					return true
				elseif ninACR.useSkill({"ten"}) then
					storedTime = 0
					return true
				end
				return
			end
			
			-- Doton | Combo
			if useDoton then
				if Player.castinginfo.lastcastid == 18806 then
					useDoton = false
					DotonCompletedMudra = true
					return
				elseif Player.castinginfo.lastcastid == 18805 and ninACR.useSkill({"chi2"}) then
					return true
				elseif Player.castinginfo.lastcastid == 2263 and ninACR.useSkill({"ten2"}) then
					return true
				elseif ninACR.useSkill({"jin"}) then
					return true
				end
				return
			end
			
			if useRaiton then
				if Player.castinginfo.lastcastid == 18806 then
					useRaiton = false
					RaitonCompletedMudra = true
				elseif Player.castinginfo.lastcastid == 2259 and ninACR.useSkill({"chi2"}) then
					return true
				elseif ninACR.useSkill({"ten"}) then
					return true
				end
				return
			end
		end
	end
	if (currentTarget == nil) then return false end
	local targetRadius = currentTarget.hitradius + 3
	if (currentTarget.attackable and (gStartCombat or currentTarget.incombat)) then
		ninACR.setVar()
		
		
		-- Huton Shortcut
		if (Player.level >= 60) and Player.gauge[2] == 0 then
			if ninACR.useSkill({"huraikin"}) then
				return
			end
		end
		
		-- Huton | L60+
		if HutonCompletedMudra and ninACR.useSkill({"huton"}) then
			resetMudraCombos()
			return true
		end
		
		if HyoshoCompletedMudra and ninACR.useSkill({"hyosho"}) then
			resetMudraCombos()
			return true
		end
		
		if RaitonCompletedMudra and ninACR.useSkill({"raiton"}) then
			resetMudraCombos()
			return true
		end
		
		-- Suiton | After Combo
		if SuitonCompletedMudra and ninACR.useSkill({"suiton"}) then
			resetMudraCombos()
			return true
		end
		
		-- Doton | After Combo
		if DotonCompletedMudra and ninACR.useSkill({"doton"}) then
			resetMudraCombos()
			return true
		end
		
		if mudraActive == false then
		
			if NIN_Settings.NIN_CD and NIN_Settings.NIN_MUD and oGCDReady and mudraReady and ninACR:LastAttackID("gustslash") and ninACR.useSkill({"mug"}) then
				return true
			end
			
			-- Let's just pretend this shit doesn't exist, cuz I hate it, it sucks, fuck this shit, if you're reading this I can't be arsed to put up with this shit ability that is most likely viable and essential for big dick damage but I don't care because I don't play Ninja, I just made it cuz harr harr funny dagger guy go stabby stabby 
			
			-- Update: I stil hate Ninja but I'm trying this out, if it gets removed later.. it's cuz I fucking hate it.
			
			if not mudraActive and oGCDReady and mugCD.isoncd and mugCD.cd <= 19 then
				if (not Player.ismoving) and kassatsuCD.isoncd and (not ninACR.ActiveBuff("kassatsu")) and ninACR.useSkill({"TCJ"}) then
					return true
				end
			end
			
			if ninACR:ActiveBuff("TCJ") then
				if Player.castinginfo.lastcastid == 18881 and ninACR.useSkill({"tcj_raiton"}) then
					return true
				elseif Player.castinginfo.lastcastid == 18873 and ninACR.useSkill({"tcj_suiton"}) then
					return true
				elseif ninACR.useSkill({"fumashuriken"}) then
					return true
				end
			end
			
			if ninACR.useSkill({"phantomkamaitachi"}) then
				return true
			end
					
			if NIN_Settings.NIN_CD and oGCDReady and mugCD.isoncd and mugCD.cd <= 19 and ninACR.useSkill({"bunshin"}) then
				return true
			end
					
			if ((mugCD.isoncd and mugCD.cd >= 20) or bunshinCD.isoncd) or not NIN_Settings.NIN_CD then
				if (ninACR.TargetFrom(Player.id) > 2) then
					if oGCDReady and ninACR.useSkill({"hellfrog"}) then
						return true
					end
				else 
					if oGCDReady and ninACR.useSkill({"bhavacakra"}) then
						return true
					end
				end
			end
			


			if ninACR:ActiveBuff("raijuready") and ninACR.useSkill({"fleetingRaiju"}) then
				return true
			end
			
			if NIN_Settings.NIN_CD and ninACR:ActiveBuff("suiton") and ninACR.useSkill({"trickattack"}) then
				return true
			end
			
			if NIN_Settings.NIN_CD and trickAttackCD.isoncd and ninACR.useSkill({"meisui"}) then
				return true
			end
			
			if Player.level >= 45 then
				if NIN_Settings.NIN_CD and oGCDReady and not mudraActive and ninACR:ActiveBuffTarget("trickattack") and ninACR.useSkill({"assasinate","dreamwithinadream"}) then
					return true
				end
			else
				if NIN_Settings.NIN_CD and oGCDReady and not mudraActive and ninACR.useSkill({"assasinate","dreamwithinadream"}) then
					return true
				end
			end
				
		-- 123 combo
		
			if NIN_Settings.NIN_AOE and (Player.level >= 38) and (ninACR.TargetFrom(Player.id) > 2) then
				if ninACR:LastAttackID("deathblossom") and ninACR.useSkill({"haukkemuj"}) then
					return true
				end
				if ninACR.useSkill({"deathblossom"}) then
					return true
				end
			elseif currentTarget.distance > targetRadius and ninACR.useSkill({"throwingdagger"}) then
				return true
			else
				if ninACR:LastAttackID("gustslash") and (mugCD.isoncd and mugCD.cd >= 20) and Player.gauge[2] < 30000 and ninACR.useSkill({"armorcrush"}) then
					return true
				end
				if ninACR:LastAttackID("gustslash") and ninACR.useSkill({"aeolianedge"}) then
					return true
				end
				if ninACR:LastAttackID("spinningedge") and ninACR.useSkill({"gustslash"}) then
					return true
				end
				if ninACR.useSkill({"spinningedge"}) then
					return true
				end
			end
		end
		

		
		if NIN_Settings.NIN_DEF and oGCDReady and not mudraActive then
			-- Second Wind
			if Player.hp.percent <= NIN_Settings.NIN_SWSlider and ninACR.useSkill({"secondwind"}) then
				return
			end
			-- Feint
			if Player.hp.percent <= NIN_Settings.NIN_FSlider and ninACR.useSkill({"feint"}) then
				return
			end
			-- Shade Shift
			if Player.hp.percent <= NIN_Settings.NIN_SSSlider and ninACR.useSkill({"shadeshift"}) then
				return
			end
			-- Bloodbath
			if Player.hp.percent <= NIN_Settings.NIN_BBSlider and ninACR.useSkill({"bloodbath"}) then
				return
			end
		end
		mudraActive = false
	end
end

TabIndex = 1

function ninACR.Draw()
	if (ninACR.GUI.open) then
	ninACR.GUI.visible, ninACR.GUI.open = GUI:Begin(ninACR.GUI.name, ninACR.GUI.open, GUI.WindowFlags_NoResize)
	if ( ninACR.GUI.visible ) then
		GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Utility",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3
		end
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")
		end

		
		-- Tabs
		
		--Main Tab 
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Text("Wxlfee's Ninja ACR")
				GUI:Text("1.2.0 Changelogs:")
				GUI:Text("Reworked Mudra System - Again... :'c")
				GUI:Text("Altered Mudra Priority.")
				GUI:Text("Added additional checks for Raiton.")
				GUI:Text("_________________________________________________")
			end
		--Defensives Tab
			if (TabIndex == 2) then
				GUI:SetWindowSize(367,184,0)
				GUI:BeginGroup()
				GUI:Text("_________________________________________________")
				--SecondWind Slider
				local ninsw
				GUI:Text("Second Wind")
				NIN_Settings.NIN_SWSlider, ninsw = GUI:SliderInt("HP%",NIN_Settings.NIN_SWSlider,0,100)
				GUI:Text("_________________________________________________")
				if (ninsw) then					
					NIN_Settings.NIN_SWSlider = NIN_Settings.NIN_SWSlider
					ninACR.SaveSettings()
				end
				local feint
				GUI:Text("Feint")
				NIN_Settings.NIN_FSlider, feint = GUI:SliderInt("HP%#",NIN_Settings.NIN_FSlider,0,100)
				GUI:Text("_________________________________________________")
				if (feint) then					
					NIN_Settings.NIN_FSlider = NIN_Settings.NIN_FSlider
					ninACR.SaveSettings()
				end
				local bldbth
				GUI:Text("Bloodbath")
				NIN_Settings.NIN_BBSlider, bldbth = GUI:SliderInt("HP%##",NIN_Settings.NIN_BBSlider,0,100)
				GUI:Text("_________________________________________________")
				if bldbth then					
					NIN_Settings.NIN_BBSlider = NIN_Settings.NIN_BBSlider
					ninACR.SaveSettings()
				end
				local sshift
				GUI:Text("Shade Shift")
				NIN_Settings.NIN_SSSlider, sshift = GUI:SliderInt("HP%###",NIN_Settings.NIN_SSSlider,0,100)
				GUI:Text("_________________________________________________")
				if sshift then					
					NIN_Settings.NIN_SSSlider = NIN_Settings.NIN_SSSlider
					ninACR.SaveSettings()
				end				
				GUI:EndGroup()
			end
			--Toggles
			if (TabIndex == 3) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",168,30)
				if GUI:IsItemClicked() then
					NIN_Settings.NIN_QT_GUI = not NIN_Settings.NIN_QT_GUI
					ninACR.SaveSettings()
				end
				GUI:SameLine()
				GUI:Button("Open Positional UI",168,30)
				if GUI:IsItemClicked() then
					NIN_Settings.NIN_POS_GUI = not NIN_Settings.NIN_POS_GUI
					ninACR.SaveSettings()
				end
				
				GUI:Text("_________________________________________________")
			end
			--Discord
			if (TabIndex == 4) then
				GUI:SetWindowSize(0,0,0)				
				GUI:Text("_________________________________________________")				
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")
				end
				GUI:Text("_________________________________________________")
				
				-- You can ignore this :) I was just testing stuff and kept it here in case I need to mess about again :)) 
				
				-- GUI:Text("[Mudra Buff]")
				-- GUI:SameLine()
				-- if mudraActive then
					-- GUI:Text(" || True")
				-- else
					-- GUI:Text(" || False")
				-- end
				-- GUI:Text("Number of enemies: "..ninACR.TargetFrom(Player.id))
				-- GUI:Text("_________________________________________________")
				-- GUI:Text("Active Mudra Combo: ")
				-- if useSuiton then
					-- GUI:SameLine()
					-- GUI:Text("Use suiton")
				-- end
				-- if useRaiton then
					-- GUI:SameLine()
					-- GUI:Text("Use raiton")
				-- end
				-- if useDoton then
					-- GUI:SameLine()
					-- GUI:Text("Use doton")
				-- end
				-- if useHyosho then
					-- GUI:SameLine()
					-- GUI:Text("Use hyosho")
				-- end
				-- GUI:Text("_________________________________________________")
			end
		end			
        GUI:End()
	end
		if (NIN_Settings.NIN_QT_GUI) then
		ninACR.GUIQT.visible, ninACR.GUIQT.open = GUI:Begin(ninACR.GUIQT.name, ninACR.GUIQT.open, GUI.WindowFlags_NoResize + GUI.WindowFlags_NoTitleBar)
			if (ninACR.GUIQT.visible) then
				GUI:SetWindowSize(0,0,0)
				GUI:PushStyleColor(GUI.Col_Button, NIN_CDr,NIN_CDg,NIN_CDb,NIN_CDa)
				cdButton = GUI:Button("CD",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					NINCDQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, NIN_AOEr,NIN_AOEg,NIN_AOEb,NIN_AOEa)
				aoeButton = GUI:Button("AOE",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					NINAOEQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, NIN_MUDr,NIN_MUDg,NIN_MUDb,NIN_MUDa)
				mudraButton = GUI:Button("Mudra",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					NINMUDQTfunc()
				end
				GUI:PushStyleColor(GUI.Col_Button, NIN_HIDEr,NIN_HIDEg,NIN_HIDEb,NIN_HIDEa)
				hideButton = GUI:Button("Hide",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					NINHIDEQTfunc()
				end
				if GUI:IsItemHovered() then
					GUI:SetTooltip("Automatically hides outside of combat, rather pointless but I guess it may have it's uses.")
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, NIN_DEFr,NIN_DEFg,NIN_DEFb,NIN_DEFa)
				defensiveButton = GUI:Button("Defensives",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					NINDEFQTfunc()
				end
			end
			GUI:End()
		end
		
		if (NIN_Settings.NIN_POS_GUI) then
		local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
			ninACR.GUIPOS.visible, ninACR.GUIPOS.open = GUI:Begin(ninACR.GUIPOS.name, ninACR.GUIPOS.open, flags2)
				if (ninACR.GUIPOS.visible) then
					GUI:SetWindowSize(210,50,0)
					GUI:Text("Current Positional: ")
					GUI:SameLine()
					if CorrectPos ~= nil then
						if positional == CorrectPos then
							GUI:TextColored(0.3,1,0.14,1,positional)
						elseif not positional == CorrectPos then
							GUI:TextColored(1,0.2,0.2,1,positional)
						else
							GUI:Text(positional)
						end
					end
					GUI:Separator()
					GUI:Text("Next Positional: ")
					GUI:SameLine()
					GUI:Text(CorrectPos)
				end
			GUI:End()
		end
end


function ninACR.SaveSettings()
	d("[WxlfeeCore] Settings have been saved.")
	WXSave()
end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function NINloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    GNB_Settings = scan(NIN_Settings,tbl)
end

function ninACR.LoadSettings()
	NINloadsettings(tbl)
end

function ninACR.OnOpen()
    ninACR.GUI.open = true
end

function ninACR.OnLoad()
	TabIndex = 1
	ninACR.LoadSettings()
	NINLoadQTColor()
	CasuallyACRActive = true
	ActiveACRname = ninACR.GUI.name
end

function ninACR.OnClick(mouse,shiftState,controlState,altState,entity)

end
function ninACR.OnUpdate(event, tickcount)
	fuckingmudracheckatthetopofmylua()
	playerPos(target)
	positionalCheck()
	NIN_oGCDisReady()
	checkMudraStacks()
	mudraIsReady()
	kassatsuIsReady()
	MudraCombos()
	NIN_Mudra_Combos()
	if not mudraActive then
		resetMudraCombos()
	end
end

RegisterEventHandler("ninACR.QTDraw", ninACR.QTDraw, "Casually Ninja")
return ninACR