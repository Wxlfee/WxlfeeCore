local CasuallyDRG = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .. [[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath .. [[DRGsettings.lua]]
local v = table.valid

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("DRGsettings.lua","w")
		localfile:write(DRG_Settings)
		localfile:close()
	end
end

local DRG_Settings = {
	
	DRG_QT_GUI = false,
	DRG_POS_GUI = false,
	
	DRG_CD = true,
	DRG_AOE = true,
	DRG_Jump = true,
	DRG_LOTD = true,
	DRG_TN = false,
	DRG_DEF = true,
	
	DRG_JumpBind = nil,
	DRG_HoldJump = false,	
	
	DRG_feintSlider = 80,
	DRG_secondwindSlider = 50,
	DRG_bloodbathSlider = 90,
	
}

--Abilities to track and all that jazz you know how it be.
CD = ActionList:Get(1,75)
HighJumpCD = ActionList:Get(1,16478)
MirageDiveCD = ActionList:Get(1,7399)
lanceChargeCD = ActionList:Get(1,85)
dragonfirediveCD = ActionList:Get(1,96)
blitCD = ActionList:Get(1,3557)
dsightCD = ActionList:Get(1,7398)
geirskogulCD = ActionList:Get(1,3555)

if QuestCompleted(1695) then
	DRG_can_use_geir = true
else
	DRG_can_use_geir = false
end

if QuestCompleted(1690) then
	DRG_can_use_blit = true
else
	DRG_can_use_blit = false
end


local function WXSave()
	FileSave(ModuleSettings,DRG_Settings)
end

CasuallyDRG.classes = {
    [FFXIV.JOBS.DRAGOON] = true,
	[FFXIV.JOBS.LANCER] = true,
} 

CasuallyDRG.GUI = {
    open = true,
    visible = true,
    name = "Casually Dragoon",
}

CasuallyDRG.GUIQT = {
	open = false,
	visible = true,
	name = "QuickToggles",
}

CasuallyDRG.GUIPOS = {
	open = false,
	visible = false,
	name = "Positional UI",
}



CasuallyDRG.drgBuff = 
	{
		powersurge = 2720,
		fangandclaw = 802,
		wheelingthrust = 803,
		truenorth = 1250,
		lancecharge = 1864,
		dragonsight = 1910,
	}
	
CasuallyDRG.drgSkill = 
	{
		truethrust = {75,true},
		vorpalthrust = {78,true},
		fullthrust = {84,true},
		lancecharge = {85,false},
		disembowel = {87,true},
		chaosthrust = {88,true},
		wheelingthrust = {3556,true},
		fangandclaw = {3554,true},
		raidenthrust = {16479,true},
		doomspike = {86,true},
		sonicthrust = {7397,true},
		coerthantorment = {16477,true},
		nastrond = {7400,true},
		geirskogul = {3555,true},
		dragonsight = {7398,false},
		battlelitany = {3557,false},
		jump = {92,true},
		highjump = {16478,true},
		miragedive = {7399,true},
		spineshatterdive = {95,true},
		dragonfiredive = {96,true},
		stardiver = {16480,true},
		truenorth = {7546,false},
		draconianfury = {25770,true},
		heavensthrust = {25771,true},
		chaoticspring = {25772,true},
		wyrmwindthrust = {25773,true},
		lifesurge = {83,false},
		piercingtalon = {90,true},
		secondwind = {7541,false},
		bloodbath = {7542,false},
		feint = {7549,true},
		
	}

--function for toggle colours--
function LoadColor()
local function setColorValue(setting, trueValue, falseValue)
    if setting == true then
        return trueValue
    else
        return falseValue
    end
end

-- JumpQTColor
DRGCDr = setColorValue(DRG_Settings.DRG_CD, 0.3, 0.6)
DRGCDg = setColorValue(DRG_Settings.DRG_CD, 0.55, 0.2)
DRGCDb = setColorValue(DRG_Settings.DRG_CD, 0.14, 0.2)
DRGCDa = 1

DRGAOEr = setColorValue(DRG_Settings.DRG_AOE, 0.3, 0.6)
DRGAOEg = setColorValue(DRG_Settings.DRG_AOE, 0.55, 0.2)
DRGAOEb = setColorValue(DRG_Settings.DRG_AOE, 0.14, 0.2)
DRGAOEa = 1

DRGJMPr = setColorValue(DRG_Settings.DRG_Jump, 0.3, 0.6)
DRGJMPg = setColorValue(DRG_Settings.DRG_Jump, 0.55, 0.2)
DRGJMPb = setColorValue(DRG_Settings.DRG_Jump, 0.14, 0.2)
DRGJMPa = 1

DRGLOTDr = setColorValue(DRG_Settings.DRG_LOTD, 0.3, 0.6)
DRGLOTDg = setColorValue(DRG_Settings.DRG_LOTD, 0.55, 0.2)
DRGLOTDb = setColorValue(DRG_Settings.DRG_LOTD, 0.14, 0.2)
DRGLOTDa = 1

DRGTNr = setColorValue(DRG_Settings.DRG_TN, 0.3, 0.6)
DRGTNg = setColorValue(DRG_Settings.DRG_TN, 0.55, 0.2)
DRGTNb = setColorValue(DRG_Settings.DRG_TN, 0.14, 0.2)
DRGTNa = 1

DRGDEFr = setColorValue(DRG_Settings.DRG_DEF, 0.3, 0.6)
DRGDEFg = setColorValue(DRG_Settings.DRG_DEF, 0.55, 0.2)
DRGDEFb = setColorValue(DRG_Settings.DRG_DEF, 0.14, 0.2)
DRGDEFa = 1

end


-- Open Quick Toggles Func
function DRGOpenQT()
  DRG_Settings.DRG_QT_GUI = not DRG_Settings.DRG_QT_GUI
  CasuallyDRG.SaveSettings()
end
-- Open Positional UI Func 
function DRGOpenPOS()
  DRG_Settings.DRG_POS_GUI = not DRG_Settings.DRG_POS_GUI
  CasuallyDRG.SaveSettings()
end

--CDs
function DRGCDQTfunc()
	DRG_Settings.DRG_CD = not DRG_Settings.DRG_CD
	DRGCDr, DRGCDg, DRGCDb =
		DRG_Settings.DRG_CD and 0.3 or 0.60,
		DRG_Settings.DRG_CD and 0.55 or 0.2,
		DRG_Settings.DRG_CD and 0.14 or 0.2,
	DRGCDa == 1
	CasuallyDRG.SaveSettings()
end

-- AOE
function DRGAOEQTfunc()
	DRG_Settings.DRG_AOE = not DRG_Settings.DRG_AOE
	DRGAOEr, DRGAOEg, DRGAOEb =
		DRG_Settings.DRG_AOE and 0.3 or 0.60,
		DRG_Settings.DRG_AOE and 0.55 or 0.2,
		DRG_Settings.DRG_AOE and 0.14 or 0.2,
	DRGAOEa == 1
	CasuallyDRG.SaveSettings()
end
-- Jumps
function JumpQTfunc()
	DRG_Settings.DRG_Jump = not DRG_Settings.DRG_Jump
	DRGJMPr, DRGJMPg, DRGJMPb =
		DRG_Settings.DRG_Jump and 0.3 or 0.6,
		DRG_Settings.DRG_Jump and 0.55 or 0.2,
		DRG_Settings.DRG_Jump and 0.14 or 0.2,
	DRGJMPa == 1
	CasuallyDRG.SaveSettings()
end

--Life of the Dragon
function LOTDQTfunc()
	DRG_Settings.DRG_LOTD = not DRG_Settings.DRG_LOTD
	DRGLOTDr, DRGLOTDg, DRGLOTDb =
		DRG_Settings.DRG_LOTD and 0.3 or 0.60,
		DRG_Settings.DRG_LOTD and 0.55 or 0.2,
		DRG_Settings.DRG_LOTD and 0.14 or 0.2,
	DRGLOTDa == 1
	CasuallyDRG.SaveSettings()
end

--True North
function DRGTNQTfunc()
	DRG_Settings.DRG_TN = not DRG_Settings.DRG_TN
	DRGTNr, DRGTNg, DRGTNb =
		DRG_Settings.DRG_TN and 0.3 or 0.60,
		DRG_Settings.DRG_TN and 0.55 or 0.2,
		DRG_Settings.DRG_TN and 0.14 or 0.2,
	DRGTNa == 1
	CasuallyDRG.SaveSettings()
end

-- Defensives
function DRGDEFQTfunc()
	DRG_Settings.DRG_DEF = not DRG_Settings.DRG_DEF
	DRGDEFr, DRGDEFg, DRGDEFb =
		DRG_Settings.DRG_DEF and 0.3 or 0.60,
		DRG_Settings.DRG_DEF and 0.55 or 0.2,
		DRG_Settings.DRG_DEF and 0.14 or 0.2,
	DRGDEFa == 1
	CasuallyDRG.SaveSettings()
end

-- End of Buttons --

-- Start of Positional Scan --
function IsFlanking(entity)
	if not entity or entity.id == Player.id then return false end

	if (round(entity.pos.h,4) > round(math.pi,4) or round(entity.pos.h,4) < (-1 * round(math.pi,4))) then
		return true
	end
	
    if (entity.distance2d <= ml_global_information.AttackRange or not dorangecheck) then
        local entityHeading = nil
        
        if (entity.pos.h < 0) then
            entityHeading = entity.pos.h + 2 * math.pi
        else
            entityHeading = entity.pos.h
        end
		
		local myPos = Player.pos
        local entityAngle = math.atan2(myPos.x - entity.pos.x, myPos.z - entity.pos.z)        
        local deviation = entityAngle - entityHeading
        local absDeviation = math.abs(deviation)
        local leftover = math.abs(absDeviation - math.pi)
		
        if ((leftover < (math.pi * 1.75) and leftover > (math.pi * 1.25)) or
			(leftover < (math.pi * .75) and leftover > (math.pi * .25))) 
		then
            return true
        end
    end
	
    return false
end

function IsBehind(entity)
	if not entity or entity.id == Player.id then return false end
	
	if (round(entity.pos.h,4) > round(math.pi,4) or round(entity.pos.h,4) < (-1 * round(math.pi,4))) then
		return true
	end
	
    if (entity.distance2d <= ml_global_information.AttackRange or not dorangecheck) then
        local entityHeading = nil
        
        if (entity.pos.h < 0) then
            entityHeading = entity.pos.h + 2 * math.pi
        else
            entityHeading = entity.pos.h
        end
        
		local myPos = Player.pos
        local entityAngle = math.atan2(myPos.x - entity.pos.x, myPos.z - entity.pos.z)        
        local deviation = entityAngle - entityHeading
        local absDeviation = math.abs(deviation)
        local leftover = math.abs(absDeviation - math.pi)
		
        if (leftover > (math.pi * 1.75) or leftover < (math.pi * .25)) then
            return true
        end
    end
    return false
end

function IsFront(entity)
	if not entity or entity.id == Player.id then return false end
	
	if (round(entity.pos.h,4) > round(math.pi,4) or round(entity.pos.h,4) < (-1 * round(math.pi,4))) then
		return true
	end
	
	if (entity.distance2d <= ml_global_information.AttackRange or not dorangecheck) then
		local entityHeading = nil
		
		if (entity.pos.h < 0) then
			entityHeading = entity.pos.h + 2 * math.pi
		else
			entityHeading = entity.pos.h
		end
		
		local myPos = Player.pos
		local entityAngle = math.atan2(myPos.x - entity.pos.x, myPos.z - entity.pos.z) 
		local deviation = entityAngle - entityHeading
		local absDeviation = math.abs(deviation)
		local leftover = math.abs(absDeviation - math.pi)
		
		if (leftover > (math.pi * .75) and leftover < (math.pi * 1.25)) then
			return true
		end
	end
    return false
end
-- End of Positional Scan
-- Output current player positional
function playerPos(target)
	target = MGetTarget()
	positional = ""
	if (IsBehind(target)) then
		positional = "Rear"
	end
	if (IsFlanking(target)) then
		positional = "Flank"
	end
	if (IsFront(target)) then
		positional = "Front"
	end
	if HasBuff(Player.id,1250) then
		positional = "T.North"
	end
	if (target.id == Player.id) then
		positional = "Cutie!"
	end
	return positional
end

-- Next Positional Attack
function DRGpositionalCheck()
	CorrectPos = ""
	if CasuallyDRG:LastAttackID("disembowel") then
		CorrectPos = "Rear"
	elseif CasuallyDRG:LastAttackID("chaosthrust") or CasuallyDRG:LastAttackID("chaoticspring") then
		CorrectPos = "Rear"
	elseif CasuallyDRG:LastAttackID("fangandclaw") then
		CorrectPos = "Rear"
	elseif CasuallyDRG:LastAttackID("wheelingthrust") then
		CorrectPos = "Flank"
	elseif CasuallyDRG:LastAttackID("fullthrust") or CasuallyDRG:LastAttackID("heavensthrust") then
		CorrectPos = "Flank"
	elseif CasuallyDRG:LastAttackID("truethrust") then
		CorrectPos = ""
	elseif CasuallyDRG:LastAttackID("raidenthrust") then
		CorrectPos = ""
	end
	return CorrectPos
end


function DRG_TwoMinCheck()
dsightReady = false
blitReady = false
dragonfirediveReady = false
lancechargeReady = false
firstfocusReady = false

burstReady = false
TwoBurstReady = false

	--Level 66 or above
	if Player.level >= 66 then
		if not dsightCD.isoncd then
			dsightReady = true
		end
		if (not blitCD.isoncd) or blitCD.isoncd and blitCD.cd >= 115 then
			blitReady = true
		end
		if (not dragonfirediveCD.isoncd) or dragonfirediveCD.isoncd and dragonfirediveCD.cd >= 110 then
			dragonfirediveReady = true
		end
		if (dsightReady and blitReady and dragonfirediveReady) or CasuallyDRG:BuffActive("dragonsight") then
			TwoBurstReady = true			
		end
		if (not lanceChargeCD.isoncd) or CasuallyDRG:BuffActive("lancecharge") then
			burstReady = true
		end
	--Level 52 to 65	
	elseif (Player.level <= 65 and Player.level >= 52) and DRG_can_use_blit then
		if not blitCD.isoncd then
			blitReady = true
		end
		if (not dragonfirediveCD.isoncd) or dragonfirediveCD.isoncd and dragonfirediveCD.cd >= 110 then
			dragonfirediveReady = true
		end
		if (blitReady and dragonfirediveReady) or CasuallyDRG:BuffActive("battlelitany") then
			TwoBurstReady = true
		end
		if (not lanceChargeCD.isoncd) or CasuallyDRG:BuffActive("lancecharge") then
			burstReady = true
		end
	--Level 51 or below	
	else
		if (not lanceChargeCD.isoncd) or CasuallyDRG:BuffActive("lancecharge") then
			TwoBurstReady = true
			burstReady = true
		end
	end
return burstReady
	
end

	
		



-- function CasuallyDRG.myParty()
    -- local myParty = MEntityList("myparty")
    -- local jobValues = {34, 39, 20, 30, 7, 31, 32, 23, 38, 25}
    -- local partyMembers = {}
	-- if myParty == nil then
		-- return false
	-- end
    -- for _, member in pairs(myParty) do
        -- if table.concat(jobValues, ","):find(member.job) and (member.id ~= Player.id) then
            -- table.insert(partyMembers,member.id)
        -- end
    -- end	
    -- return partyMembers
-- end

-- function DSightMember()
    -- local partyMembers = CasuallyDRG.myParty()
	-- if partyMembers == true then
		-- for _, member in pairs(partyMembers) do
			-- if CasuallyDRG.useSkill({"dragonsight"},member.id) then
				-- return true
			-- end
		-- end
	-- else
		-- return false
	-- end
-- end

function CasuallyDRG:skillID(string)
	if CasuallyDRG.drgSkill[string] ~= nil then
		return CasuallyDRG.drgSkill[string][1]
	end
end

function CasuallyDRG:LastAttackID(string)
	if CasuallyDRG:skillID(string) ~= nil then
		if Player.lastcomboid == CasuallyDRG:skillID(string) then
			return true
		end
	end
	return false
end


function CasuallyDRG:BuffActive(string)
	if CasuallyDRG.drgBuff[string] ~= nil then
		if HasBuff(Player.id,CasuallyDRG.drgBuff[string]) then
			return true
		end
	end
	return false
end

function CasuallyDRG:ActiveBuffDuration(string,timeLeft)
	if CasuallyDRG.drgBuff[string] ~= nil then
		if HasBuff(Player.id,CasuallyDRG.drgBuff[string],0,timeLeft) then
			return true
		end
	end
	return false
end


function CasuallyDRG.TargetFrom(entity)
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5,distanceto="..tostring(entity))
	return (table.size(targets))
end	

function CasuallyDRG.setVar()
	for i,e in pairs(CasuallyDRG.drgSkill) do
		CasuallyDRG[i] = ActionList:Get(1,e[1])
		if CasuallyDRG[i] then
			if e[2] then
				CasuallyDRG[i]["isready"] = CasuallyDRG[i]:IsReady(MGetTarget().id) else CasuallyDRG[i]["isready"] = CasuallyDRG[i]:IsReady(Player)
			end
		end
	end
end

function CasuallyDRG.useSkill(skl,string)
	local text = (string)
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = CasuallyDRG[abil].isready
		if ACTready then
			CasuallyDRG[abil]:Cast(text.id)
			return true
		end
	end
	return false
end

function DRG_oGCDisReady()
	oGCDReady = false
	WeaveTime = (CD.cdmax/5)*2.25
	CDmax = CD.cdmax
		if CD.cd < WeaveTime then
			oGCDReady = true
		end
		if (CD.cd > WeaveTime) or (CD.cd == 0) then
			oGCDReady = false
		end
	return oGCDReady
end
 
function CasuallyDRG.Cast()
    local currentTarget = MGetTarget()
	if (currentTarget == nil) then
		return false
	end
	local targetRadius = currentTarget.hitradius + 3
	if (currentTarget.attackable and (gStartCombat or currentTarget.incombat)) then
		CasuallyDRG.setVar()
		
		--gauge[2] = Mirage Dive # uses.
		if DRG_can_use_geir then
			if  (burstReady and (not geirskogulCD.isoncd or geirskogulCD.cd >= 25)) and DRG_Settings.DRG_LOTD and oGCDReady and CasuallyDRG.useSkill({"lancecharge"}) then
				return true
			end
		elseif not DRG_can_use_geir then
			if  (burstReady) and DRG_Settings.DRG_LOTD and oGCDReady and CasuallyDRG.useSkill({"lancecharge"}) then
				return true
			end
		end
		
		--ogcd miragedive proc
		if (((dsightCD.isoncd) or (blitCD.isoncd)) or not DRG_Settings.DRG_CD) then
			if DRG_Settings.DRG_LOTD and oGCDReady and (geirskogulCD.isoncd and geirskogulCD.cd <= 5) and CasuallyDRG.useSkill({"miragedive"}) then
				return true
			end
			if DRG_Settings.DRG_LOTD and oGCDReady and HighJumpCD.isoncd and CasuallyDRG.useSkill({"geirskogul"}) then
				return true
			end
		end
		
		if oGCDReady and (DRG_Settings.DRG_TN) and (not CasuallyDRG:BuffActive("truenorth")) and (CasuallyDRG:LastAttackID("heavensthrust") or CasuallyDRG:LastAttackID("disembowel")) and CasuallyDRG.useSkill({"truenorth"}) and (positional ~= CorrectPos) then
			return true
		end
		
		if oGCDReady and CasuallyDRG:LastAttackID("vorpalthrust") and (not HasBuff(Player.id,116)) and CasuallyDRG.useSkill({"lifesurge"}) then
			return true
		end
		
		if oGCDReady and CasuallyDRG.useSkill({"stardiver","nastrond"}) then
			return true
		end
		
		if oGCDReady and (burstReady or (Player.castinginfo.lastcastid == 3556 or Player.castinginfo.lastcastid == 3554)) and CasuallyDRG.useSkill({"wyrmwindthrust"}) then
			return true
		end
		--Doesn't work for now, using alternative
		--DSightMember()
		if TwoBurstReady and oGCDReady and (DRG_Settings.DRG_CD) and CasuallyDRG.useSkill({"dragonsight"}) then
			return true
		end
		
		-- Battle Litany
		if TwoBurstReady and oGCDReady and (DRG_Settings.DRG_CD) and CasuallyDRG.useSkill({"battlelitany"}) then
			return true
		end
		
		--ogcd jump
		if DRG_Settings.DRG_Jump and (GUI:IsKeyDown(DRG_Settings.DRG_JumpBind) == false) and oGCDReady then
		
			if (DRG_can_use_geir) and (burstReady or (lanceChargeCD.isoncd and lanceChargeCD.cd <= 40)) and CasuallyDRG.useSkill({"jump","highjump"}) then
				return true
			end
			if (not DRG_can_use_geir) and (burstReady or (lanceChargeCD.isoncd and lanceChargeCD.cd <= 40)) and CasuallyDRG.useSkill({"jump","highjump","spineshatterdive","dragonfiredive"}) then
				return true
			end			
			
			if (TwoBurstReady) and CasuallyDRG.useSkill({"spineshatterdive","dragonfiredive"}) then
				return true
			end
			
		end
		
		

		
		if currentTarget.distance2d > targetRadius and CasuallyDRG.useSkill({"piercingtalon"}) then
			return true
		end	
		
		--extended 123 / 145 combo
		if CasuallyDRG.useSkill({"fangandclaw"}) then
			return true
		end
		if CasuallyDRG.useSkill({"wheelingthrust"}) then
			return true
		end

		--123 145 combo / 123 aoe combo
		if DRG_Settings.DRG_AOE and CasuallyDRG.TargetFrom(currentTarget.id) > 2 then
			if CasuallyDRG:LastAttackID("sonicthrust") and CasuallyDRG.useSkill({"coerthantorment"}) then
				return true
			end		
			if CasuallyDRG:LastAttackID("doomspike") and CasuallyDRG.useSkill({"sonicthrust"}) then
				return true
			end		
			if CasuallyDRG.useSkill({"doomspike","draconianfury"}) then
				return true
			end			
		else
			if CasuallyDRG:LastAttackID("disembowel") and CasuallyDRG.useSkill({"chaosthrust","chaoticspring"}) then
				return true
			end
			if (CasuallyDRG:BuffActive("powersurge") and not CasuallyDRG:ActiveBuffDuration("powersurge",10)) and (CasuallyDRG:LastAttackID("truethrust") or CasuallyDRG:LastAttackID("raidenthrust")) and CasuallyDRG.useSkill({"disembowel"}) then
				return true
			end
			if not CasuallyDRG:BuffActive("powersurge") and (CasuallyDRG:LastAttackID("truethrust") or CasuallyDRG:LastAttackID("raidenthrust")) and CasuallyDRG.useSkill({"disembowel"}) then
				return true
			end		
			if CasuallyDRG:LastAttackID("vorpalthrust") and CasuallyDRG.useSkill({"fullthrust","heavensthrust"}) then
				return true
			end
			if (CasuallyDRG:LastAttackID("truethrust") or CasuallyDRG:LastAttackID("raidenthrust")) and CasuallyDRG.useSkill({"vorpalthrust"}) then
				return true
			end
			if CasuallyDRG.useSkill({"truethrust"}) then
				return true
			end
		end
		
		if (DRG_Settings.DRG_DEF) then
			if (Player.hp.percent <= DRG_Settings.DRG_bloodbathSlider) and CasuallyDRG.useSkill({"bloodbath"}, "Player") then
				return true
			end
			if (Player.hp.percent <= DRG_Settings.DRG_secondwindSlider) and CasuallyDRG.useSkill({"secondwind"}, "Player") then
				return true
			end
			if (Player.hp.percent <= DRG_Settings.DRG_feintSlider) and CasuallyDRG.useSkill({"feint"}) then
				return true
			end
		end

	return false
	end
end

MultiTabs =  [[Main, Defensives, Test2, Discord]]
TabIndex = 1


function CasuallyDRG.Draw()
    if (CasuallyDRG.GUI.open) then	
	CasuallyDRG.GUI.visible, CasuallyDRG.GUI.open = GUI:Begin(CasuallyDRG.GUI.name, CasuallyDRG.GUI.open, GUI.WindowFlags_NoResize)
	if ( CasuallyDRG.GUI.visible ) then 
       GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Utility",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3
		end
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")			
		end
		
		--Tabs
		
		--Main Tab 
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Text("Wxlfee's Dragoon ACR")
				GUI:Text("1.1.0 Changelogs:")
				GUI:Text("Complete rotation recode.")
				GUI:Text("Reworked Quick Toggles.")
				GUI:Text("1-90 Levelling support.")
				GUI:Text("_________________________________________________")
			end
		--Defensives Tab
			if (TabIndex == 2) then
				GUI:BeginGroup()
				GUI:Text("_________________________________________________")
				--rampart Slider
				local ramp
				GUI:Text("Second Wind")
				DRG_Settings.DRG_secondwindSlider, ramp = GUI:SliderInt("HP%",DRG_Settings.DRG_secondwindSlider,0,100)
				GUI:Text("_________________________________________________")
				if (ramp) then
					d(DRG_Settings.DRG_secondwindSlider)
					DRG_Settings.DRG_secondwindSlider = DRG_Settings.DRG_secondwindSlider
					CasuallyDRG.SaveSettings()
				end
				local feint
				GUI:Text("Feint")
				DRG_Settings.DRG_feintSlider, feint = GUI:SliderInt("HP%##",DRG_Settings.DRG_feintSlider,0,100)
				GUI:Text("_________________________________________________")
				if (feint) then
					d(DRG_Settings.DRG_feintSlider)
					DRG_Settings.DRG_feintSlider = DRG_Settings.DRG_feintSlider
					CasuallyDRG.SaveSettings()
				end
				local bldbth
				GUI:Text("Bloodbath")
				DRG_Settings.DRG_bloodbathSlider, bldbth = GUI:SliderInt("HP####",DRG_Settings.DRG_bloodbathSlider,0,100)
				GUI:Text("_________________________________________________")
				if bldbth then
					d(DRG_Settings.DRG_bloodbathSlider)
					DRG_Settings.DRG_bloodbathSlider = DRG_Settings.DRG_bloodbathSlider
					CasuallyDRG.SaveSettings()
				end
				GUI:EndGroup()
			end
			--Toggles
			if (TabIndex == 3) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",168,30)
				if GUI:IsItemClicked() then
					DRGOpenQT()
				end
				GUI:SameLine()
				GUI:Button("Open Positional UI",168,30)
				if GUI:IsItemClicked() then
					DRGOpenPOS()
				end
				DRG_Settings.DRG_HoldJump, jmpKey = GUI:Checkbox("Enable Hold Jump Keybind", DRG_Settings.DRG_HoldJump)
				if (DRG_Settings.DRG_HoldJump == true) then
					DRG_Settings.DRG_JumpBind = GUI:Keybind("Hold Keybind",DRG_Settings.DRG_JumpBind,100)
					GUI:Button("Reset Keybind",100,20)
					if GUI:IsItemClicked() then
						DRG_Settings.DRG_JumpBind = nil
					end
				end
				GUI:Text("_________________________________________________")
			end
			--Discord
			if (TabIndex == 4) then
				GUI:SetWindowSize(0,0,0)				
				GUI:Text("_________________________________________________")				
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")					
				end
				GUI:Text("_________________________________________________")
				if burstReady then
					GUI:Text("Burst is Ready")
				elseif not burstReady then
					GUI:Text("Burst not Ready")
				end
				GUI:Text("_________________________________________________")
			end
		end			
        GUI:End()
		end
		
		if (DRG_Settings.DRG_QT_GUI) then
		local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
			CasuallyDRG.GUIQT.visible, CasuallyDRG.GUIQT.open = GUI:Begin(CasuallyDRG.GUIQT.name, CasuallyDRG.GUIQT.open, flags2)
				if (CasuallyDRG.GUIQT.visible) then
					GUI:SetWindowSize(0,0,0)
					GUI:PushStyleColor(GUI.Col_Button, DRGCDr,DRGCDg,DRGCDb,DRGCDa)					
					local CDButton = GUI:Button("CD",90,30)
					GUI:PopStyleColor(1)					
					if GUI:IsItemClicked() then
						DRGCDQTfunc()
					end
					if GUI:IsItemHovered() then
						GUI:SetTooltip("Enable/Disable CDs.")
					end					
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, DRGAOEr,DRGAOEg,DRGAOEb,DRGAOEa)
					local AOEButton = GUI:Button("AOE",90,30)
					GUI:PopStyleColor(1)	
					if GUI:IsItemClicked() then
						DRGAOEQTfunc()
					end
					if GUI:IsItemHovered() then
						GUI:SetTooltip("Enable/Disable AOE attacks.")
					end									
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, DRGJMPr,DRGJMPg,DRGJMPb,DRGJMPa)
					local JumpButton = GUI:Button("Jumps",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						JumpQTfunc()
					end
					if GUI:IsItemHovered() then
						GUI:SetTooltip("Enable/Disable the use of Jumping attacks.")
					end
					GUI:PushStyleColor(GUI.Col_Button, DRGLOTDr,DRGLOTDg,DRGLOTDb,DRGLOTDa)
					local LOTDButton = GUI:Button("Life Dragon",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						LOTDQTfunc()
					end
					if GUI:IsItemHovered() then
						GUI:SetTooltip("Enable/Disable Life of the Dragon phase.")
					end
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, DRGTNr,DRGTNg,DRGTNb,DRGTNa)
					local TNButton = GUI:Button("True North",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						DRGTNQTfunc()
					end
					if GUI:IsItemHovered() then
						GUI:SetTooltip("Automatically use True North if current positional is incorrect.")
					end					
					GUI:SameLine()
					GUI:PushStyleColor(GUI.Col_Button, DRGDEFr,DRGDEFg,DRGDEFb,DRGDEFa)
					local DEFButton = GUI:Button("Defensives",90,30)
					GUI:PopStyleColor(1)
					if GUI:IsItemClicked() then
						DRGDEFQTfunc()
					end
					if GUI:IsItemHovered() then
						GUI:SetTooltip("Enable/Disable the use of mitigation.")
					end
				end
			GUI:End()
		end
		
		--Positional UI
		if (DRG_Settings.DRG_POS_GUI) then
		local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
			CasuallyDRG.GUIPOS.visible, CasuallyDRG.GUIPOS.open = GUI:Begin(CasuallyDRG.GUIPOS.name, CasuallyDRG.GUIPOS.open, flags2)
				if (CasuallyDRG.GUIPOS.visible) then
					GUI:SetWindowSize(210,70,0)
					GUI:Text("Current Positional: ")
					GUI:SameLine()
					if CorrectPos ~= nil then
						if positional == CorrectPos then
							GUI:TextColored(0.3,1,0.14,1,positional)
						elseif not positional == CorrectPos then
							GUI:TextColored(1,0.2,0.2,1,positional)
						else
							GUI:Text(positional)
						end
					end
					--GUI:NewLine()
					GUI:Separator()
					GUI:Text("Next Positional: ")
					GUI:SameLine()					
					GUI:Text(CorrectPos)									
					GUI:Separator()
					if (DRG_Settings.DRG_HoldJump) then
						local DRGJMPtext = "            Jump"
						if (GUI:IsKeyDown(DRG_Settings.DRG_JumpBind) == true) then
							GUI:TextColored(1,0.2,0.2,1,DRGJMPtext)
						elseif (GUI:IsKeyDown(DRG_Settings.DRG_JumpBind) == false) then
							GUI:TextColored(0.3,1,0.14,1,DRGJMPtext)
						elseif (DRG_Settings.DRG_JumpBind == nil) then
							GUI:Text("Key not bound.")
						end
					end
				end
			GUI:End()
		end
end
 

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function DRGloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    DRG_Settings = scan(DRG_Settings,tbl)
end

 
function CasuallyDRG.SaveSettings()
	WXSave()
	d("[WxlfeeCore] - Settings have been saved.")	

end

function CasuallyDRG.LoadSettings()
	DRGloadsettings(tbl)
		
end


function CasuallyDRG.OnOpen()
    CasuallyDRG.GUI.open = true
end

function CasuallyDRG.QTOnOpen()
	CasuallyDRG.GUIQT.open = true
end

function CasuallyDRG.POSOnOpen()
	CasuallyDRG.GUIPOS.open = true
end


function CasuallyDRG.OnLoad()
    TabIndex = 1
	CasuallyDRG.LoadSettings()
	LoadColor()
	CasuallyACRActive = true
	ActiveACRname = CasuallyDRG.GUI.name
end
 
function CasuallyDRG.OnClick(mouse,shiftState,controlState,altState,entity)
 
end
 
function CasuallyDRG.OnUpdate(event, tickcount)
	DRG_TwoMinCheck()
	playerPos(target)
	DRGpositionalCheck()
	DRG_oGCDisReady()	
end
 
return CasuallyDRG