local bluACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath..[[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath..[[BLUsettings.lua]]
local v = table.valid

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("BLUsettings.lua","w")
		localfile:write(BLU_Settings)
		file:close()
	end
end

local BLU_Settings = {
	BLU_QT_GUI = false,
	
	BLU_CD = true,
	BLU_AOE = false,
	BLU_DEF = true,
	BLU_FSO = false,
	BLU_MF = false,
	BLU_FIN = false,
	
	BLU_WWSlider = 50,
}

local function WXSave()
	FileSave(ModuleSettings,BLU_Settings)
end

bluACR.classes = {
	[FFXIV.JOBS.BLUEMAGE] = true,
}

bluACR.GUI = {
	open = true,
	visible = true,
	name = "Casually Blue Mage",
}

bluACR.GUIQT = {
	open = false,
	visible = true,
	name = "WX_QuickToggles",
}

CD = ActionList:Get(1,)

bluACR.bluBuff = {

}

bluACR.bluSkill = {

}

function BLUOpenQT()
	BLU_Settings.BLU_QT_GUI = not BLU_Settings.BLU_QT_GUI
	bluACR.SaveSettings()
end

-- Quick Toggle Load Color

function BLULoadQTColor()
local function setColorValue(setting, trueValue, falseValue)
	if Setting == true then
		return trueValue
	else
		return falseValue
	end
end

-- CD Color
BLUCDr = setColorValue(BLU_Settings.BLU_CD, 0.3, 0.6)
BLUCDg = setColorValue(BLU_Settings.BLU_CD, 0.55, 0.2)
BLUCDb = setColorValue(BLU_Settings.BLU_CD, 0.14, 0.2)
BLUCDa = 1

-- AOE Color
BLUAOEr = setColorValue(BLU_Settings.BLU_AOE, 0.3, 0.6)
BLUAOEg = setColorValue(BLU_Settings.BLU_AOE, 0.55, 0.2)
BLUAOEb = setColorValue(BLU_Settings.BLU_AOE, 0.14, 0.2)
BLUAOEa = 1

-- Def Color
BLUDEFr = setColorValue(BLU_Settings.BLU_DEF, 0.3, 0.6)
BLUDEFg = setColorValue(BLU_Settings.BLU_DEF, 0.55, 0.2)
BLUDEFb = setColorValue(BLU_Settings.BLU_DEF, 0.14, 0.2)
BLUDEFa = 1

-- Final Sting Opener
BLUFSOr = setColorValue(BLU_Settings.BLU_FSO, 0.3, 0.6)
BLUFSOg = setColorValue(BLU_Settings.BLU_FSO, 0.55, 0.2)
BLUFSOb = setColorValue(BLU_Settings.BLU_FSO, 0.14, 0.2)
BLUFSOa = 1

-- Moon Flute Burst
BLUMFr = setColorValue(BLU_Settings.BLU_MF, 0.3, 0.6)
BLUMFg = setColorValue(BLU_Settings.BLU_MF, 0.55, 0.2)
BLUMFb = setColorValue(BLU_Settings.BLU_MF, 0.14, 0.2)
BLUMFa = 1

-- Finisher Burst
BLUFINr = setColorValue(BLU_Settings.BLU_FIN, 0.3, 0.6)
BLUFINg = setColorValue(BLU_Settings.BLU_FIN, 0.55, 0.2)
BLUFINb = setColorValue(BLU_Settings.BLU_FIN, 0.14, 0.2)
BLUFINa = 1

end

function BLUCDQTfunc()
	BLU_Settings.BLU_CD = not BLU_Settings.BLU_CD
	BLUCDr, BLUCDg, BLUCDb =
		BLU_Settings.BLU_CD and 0.3 or 0.6,
		BLU_Settings.BLU_CD and 0.55 or 0.2,
		BLU_Settings.BLU_CD and 0.14 or 0.2,
	BLUCDa == 1
	bluACR.SaveSettings()
end

function BLUAOEQTfunc()
	BLU_Settings.BLU_AOE = not BLU_Settings.BLU_AOE
	BLUAOEr, BLUAOEg, BLUAOEb =
		BLU_Settings.BLU_AOE and 0.3 or 0.6,
		BLU_Settings.BLU_AOE and 0.55 or 0.2,
		BLU_Settings.BLU_AOE and 0.14 or 0.2,
	BLUAOEa == 1
	bluACR.SaveSettings()
end

function BLUDEFQTfunc()
	BLU_Settings.BLU_DEF = not BLU_Settings.BLU_DEF
	BLUDEFr, BLUDEFg, BLUDEFb =
		BLU_Settings.BLU_DEF and 0.3 or 0.6,
		BLU_Settings.BLU_DEF and 0.55 or 0.2,
		BLU_Settings.BLU_DEF and 0.14 or 0.2,
	BLUDEFa == 1
	bluACR.SaveSettings()
end

function BLUFSOQTfunc()
	BLU_Settings.BLU_FSO = not BLU_Settings.BLU_FSO
	BLUFSOr, BLUFSOg, BLUFSOb =
		BLU_Settings.BLU_FSO and 0.3 or 0.6,
		BLU_Settings.BLU_FSO and 0.55 or 0.2,
		BLU_Settings.BLU_FSO and 0.14 or 0.2,
	BLUFSOa == 1
	bluACR.SaveSettings()
end

function BLUMFQTfunc()
	BLU_Settings.BLU_MF = not BLU_Settings.BLU_MF
	BLUMFr, BLUMFg, BLUMFb =
		BLU_Settings.BLU_MF and 0.3 or 0.6,
		BLU_Settings.BLU_MF and 0.55 or 0.2,
		BLU_Settings.BLU_MF and 0.14 or 0.2,
	BLUMFa == 1
	bluACR.SaveSettings()
end

function BLUBRNQTfunc()
	BLU_Settings.BLU_FIN = not BLU_Settings.BLU_FIN
	BLUFINr, BLUFINg, BLUFINb =
		BLU_Settings.BLU_FIN
		BLU_Settings.BLU_FIN
		BLU_Settings.BLU_FIN
		BLU_Settings.BLU_FIN


return bluACR