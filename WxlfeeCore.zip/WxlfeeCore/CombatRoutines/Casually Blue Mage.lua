local bluACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath..[[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath..[[BLUsettings.lua]]
local v = table.valid

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("BLUsettings.lua","w")
		localfile:write(BLU_Settings)
		file:close()
	end
end

local BLU_Settings = {
	BLU_QT_GUI = false,
	
	BLU_CD = true,
	BLU_AOE = false,
	BLU_DEF = true,
	BLU_FSO = false,
	BLU_MF = false,
	BLU_FIN = false,
	
	BLU_WWSlider = 50,
	
	BLU_QT_ON_R = 0.3,
	BLU_QT_ON_G = 0.55,
	BLU_QT_ON_B = 0.14,
	
	BLU_QT_OFF_R = 0.6,
	BLU_QT_OFF_G = 0.2,
	BLU_QT_OFF_B = 0.2,
}

local function WXSave()
	FileSave(ModuleSettings,BLU_Settings)
end

bluACR.classes = {
	[FFXIV.JOBS.BLUEMAGE] = true,
}

bluACR.GUI = {
	open = true,
	visible = true,
	name = "Casually Blue Mage",
}

bluACR.GUIQT = {
	open = false,
	visible = true,
	name = "WX_QuickToggles",
}

CD = ActionList:Get(1,11385)

bluACR.bluBuff = {

}

bluACR.bluSkill = {

}

function BLUOpenQT()
	BLU_Settings.BLU_QT_GUI = not BLU_Settings.BLU_QT_GUI
	bluACR.SaveSettings()
end

-- Quick Toggle Load Color

function BLULoadQTColor()
local function setColorValue(setting, trueValue, falseValue)
	if Setting == true then
		return trueValue
	else
		return falseValue
	end
end

-- CD Color
BLUCDr = setColorValue(BLU_Settings.BLU_CD, BLU_Settings.BLU_QT_ON_R, BLU_Settings.BLU_QT_OFF_R)
BLUCDg = setColorValue(BLU_Settings.BLU_CD, BLU_Settings.BLU_QT_ON_G, BLU_Settings.BLU_QT_OFF_G)
BLUCDb = setColorValue(BLU_Settings.BLU_CD, BLU_Settings.BLU_QT_ON_B, BLU_Settings.BLU_QT_OFF_B)
BLUCDa = 1

-- AOE Color
BLUAOEr = setColorValue(BLU_Settings.BLU_AOE, BLU_Settings.BLU_QT_ON_R, BLU_Settings.BLU_QT_OFF_R)
BLUAOEg = setColorValue(BLU_Settings.BLU_AOE, BLU_Settings.BLU_QT_ON_G, BLU_Settings.BLU_QT_OFF_G)
BLUAOEb = setColorValue(BLU_Settings.BLU_AOE, BLU_Settings.BLU_QT_ON_B, BLU_Settings.BLU_QT_OFF_B)
BLUAOEa = 1

-- Def Color
BLUDEFr = setColorValue(BLU_Settings.BLU_DEF, BLU_Settings.BLU_QT_ON_R, BLU_Settings.BLU_QT_OFF_R)
BLUDEFg = setColorValue(BLU_Settings.BLU_DEF, BLU_Settings.BLU_QT_ON_G, BLU_Settings.BLU_QT_OFF_G)
BLUDEFb = setColorValue(BLU_Settings.BLU_DEF, BLU_Settings.BLU_QT_ON_B, BLU_Settings.BLU_QT_OFF_B)
BLUDEFa = 1

-- Final Sting Opener
BLUFSOr = setColorValue(BLU_Settings.BLU_FSO, BLU_Settings.BLU_QT_ON_R, BLU_Settings.BLU_QT_OFF_R)
BLUFSOg = setColorValue(BLU_Settings.BLU_FSO, BLU_Settings.BLU_QT_ON_G, BLU_Settings.BLU_QT_OFF_G)
BLUFSOb = setColorValue(BLU_Settings.BLU_FSO, BLU_Settings.BLU_QT_ON_B, BLU_Settings.BLU_QT_OFF_B)
BLUFSOa = 1

-- Moon Flute Burst
BLUMFr = setColorValue(BLU_Settings.BLU_MF, BLU_Settings.BLU_QT_ON_R, BLU_Settings.BLU_QT_OFF_R)
BLUMFg = setColorValue(BLU_Settings.BLU_MF, BLU_Settings.BLU_QT_ON_G, BLU_Settings.BLU_QT_OFF_G)
BLUMFb = setColorValue(BLU_Settings.BLU_MF, BLU_Settings.BLU_QT_ON_B, BLU_Settings.BLU_QT_OFF_B)
BLUMFa = 1

-- Finisher Burst
BLUFINr = setColorValue(BLU_Settings.BLU_FIN, BLU_Settings.BLU_QT_ON_R, BLU_Settings.BLU_QT_OFF_R)
BLUFINg = setColorValue(BLU_Settings.BLU_FIN, BLU_Settings.BLU_QT_ON_G, BLU_Settings.BLU_QT_OFF_G)
BLUFINb = setColorValue(BLU_Settings.BLU_FIN, BLU_Settings.BLU_QT_ON_B, BLU_Settings.BLU_QT_OFF_B)
BLUFINa = 1

end

function BLUCDQTfunc()
	BLU_Settings.BLU_CD = not BLU_Settings.BLU_CD
	bluACR.SaveSettings()
end

function BLUAOEQTfunc()
	BLU_Settings.BLU_AOE = not BLU_Settings.BLU_AOE
	bluACR.SaveSettings()
end

function BLUDEFQTfunc()
	BLU_Settings.BLU_DEF = not BLU_Settings.BLU_DEF
	bluACR.SaveSettings()
end

function BLUFSOQTfunc()
	BLU_Settings.BLU_FSO = not BLU_Settings.BLU_FSO
	bluACR.SaveSettings()
end

function BLUMFQTfunc()
	BLU_Settings.BLU_MF = not BLU_Settings.BLU_MF
	bluACR.SaveSettings()
end

function BLUBRNQTfunc()
	BLU_Settings.BLU_FIN = not BLU_Settings.BLU_FIN
	bluACR.SaveSettings()
end


return bluACR