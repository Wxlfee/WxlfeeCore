local rprACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .. [[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath .. [[RPRsettings.lua]]
local v = table.valid


local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("GNBsettings.lua","w")
		localfile:write(GNB_Settings)
		file:close()
	end
end

RPR_Settings = {
	RPR_QT_GUI = false,
	RPR_POS_GUI = false,
	
	RPR_CD = true,
	RPR_AOE = true,
	RPR_DEF = true,
	RPR_Soul = false,
	RPR_TN = false,
	RPR_Harpe = false,
	RPR_Enshroud = true,
	
	RPR_arcSlider = 70,
	RPR_bbSlider = 80,
	RPR_feintSlider = 75,
	
}

local function WXSave()
	FileSave(ModuleSettings,RPR_Settings)
end

rprACR.classes = {
    [FFXIV.JOBS.REAPER] = true,
} 

rprACR.GUI = 
{
    open = true,
    visible = true,
    name = "Casually Reaper",
}

rprACR.GUIQT =
{
	open = false,
	visible = true,
	name = "WX_QuickToggles",
}

rprACR.GUIPOS =
{
	open = false,
	visible = true,
	name = "Positional UI",
}

CD = ActionList:Get(1,24373)
ArcaneCircleCD = ActionList:Get(1,24405)

rprACR.rprBuff = 
	{
		deathdesign = 2586,
		soulreaver = 2587,
		enhancedgibbet = 2588,
		enhancedgallows = 2589,
		arcanecircle = 2599,
		soulsow = 2594,
		enshrouded = 2593,
		immortalsacrifice = 2592,
		enhancedvoidreaping = 2590,
		enhancedcrossreaping = 2591,
		truenorth = 1250,
		
		
	}
		

rprACR.rprSkill = 
	{
		slice = {24373,true},
		waxingslice = {24374,true},
		infernalslice = {24375,true},
		bloodstalk = {24389,true},
		unveiledgibbet = {24390,true},
		unveiledgallows = {24391,true},
		gibbet = {24382,true},
		gallows = {24383,true},
		soulslice = {24380,true},
		shadowofdeath = {24378,true},
		spinningscythe = {24376,false},
		nightmarescythe = {24377,false},	
		grimswathe = {24392,true},
		guillotine  = {24384,true},
		soulscythe  = {24381,false},
		whorlofdeath  = {24379,false},
		gluttony = {24393,true},
		enshroud = {24394,false},
		voidreaping = {24395,true},
		crossreaping = {24396,true},
		lemureslice = {24399,true},
		lemurescythe = {24400,true},
		communio = {24398,true},
		soulsow = {24387,false},
		harpe = {24386,true},
		
		harvestmoon = {24388,true},
		
		arcanecircle = {24405,false},
		plentifulharvest = {24385,true},
		
		bloodbath = {7542,false},
		feint = {7549,true},
		secondwind = {7541,false},
		arcanecrest = {24404,false},

	}

function RPROpenQT()
	RPR_Settings.RPR_QT_GUI = not RPR_Settings.RPR_QT_GUI
	rprACR.SaveSettings()
end

function RPROpenPOS()
	RPR_Settings.RPR_POS_GUI = not RPR_Settings.RPR_POS_GUI
	rprACR.SaveSettings()
end

function RPR_oGCDisReady()
oGCDReady = false
CDMax = CD.cdmax
WeaveTime = (CDMax / 5) * 2.25
	if CD.cd < WeaveTime then
		oGCDReady = true
	elseif (CD.cd > WeaveTime) or (CD.cd == 0) then
		oGCDReady = false
	end
end




function IsFlanking(entity)
	if not entity or entity.id == Player.id then return false end

	if (round(entity.pos.h,4) > round(math.pi,4) or round(entity.pos.h,4) < (-1 * round(math.pi,4))) then
		return true
	end
	
    if (entity.distance2d <= ml_global_information.AttackRange or not dorangecheck) then
        local entityHeading = nil
        
        if (entity.pos.h < 0) then
            entityHeading = entity.pos.h + 2 * math.pi
        else
            entityHeading = entity.pos.h
        end
		
		local myPos = Player.pos
        local entityAngle = math.atan2(myPos.x - entity.pos.x, myPos.z - entity.pos.z)        
        local deviation = entityAngle - entityHeading
        local absDeviation = math.abs(deviation)
        local leftover = math.abs(absDeviation - math.pi)
		
        if ((leftover < (math.pi * 1.75) and leftover > (math.pi * 1.25)) or
			(leftover < (math.pi * .75) and leftover > (math.pi * .25))) 
		then
            return true
        end
    end
	
    return false
end

function IsBehind(entity)
	if not entity or entity.id == Player.id then return false end
	
	if (round(entity.pos.h,4) > round(math.pi,4) or round(entity.pos.h,4) < (-1 * round(math.pi,4))) then
		return true
	end
	
    if (entity.distance2d <= ml_global_information.AttackRange or not dorangecheck) then
        local entityHeading = nil
        
        if (entity.pos.h < 0) then
            entityHeading = entity.pos.h + 2 * math.pi
        else
            entityHeading = entity.pos.h
        end
        
		local myPos = Player.pos
        local entityAngle = math.atan2(myPos.x - entity.pos.x, myPos.z - entity.pos.z)        
        local deviation = entityAngle - entityHeading
        local absDeviation = math.abs(deviation)
        local leftover = math.abs(absDeviation - math.pi)
		
        if (leftover > (math.pi * 1.75) or leftover < (math.pi * .25)) then
            return true
        end
    end
    return false
end

function IsFront(entity)
	if not entity or entity.id == Player.id then return false end
	
	if (round(entity.pos.h,4) > round(math.pi,4) or round(entity.pos.h,4) < (-1 * round(math.pi,4))) then
		return true
	end
	
	if (entity.distance2d <= ml_global_information.AttackRange or not dorangecheck) then
		local entityHeading = nil
		
		if (entity.pos.h < 0) then
			entityHeading = entity.pos.h + 2 * math.pi
		else
			entityHeading = entity.pos.h
		end
		
		local myPos = Player.pos
		local entityAngle = math.atan2(myPos.x - entity.pos.x, myPos.z - entity.pos.z) 
		local deviation = entityAngle - entityHeading
		local absDeviation = math.abs(deviation)
		local leftover = math.abs(absDeviation - math.pi)
		
		if (leftover > (math.pi * .75) and leftover < (math.pi * 1.25)) then
			return true
		end
	end
    return false
end

-- Output current player positional
function playerPos(target)
	local target = MGetTarget()
	positional = ""
	if (IsBehind(target)) then
		positional = "Rear"
	end
	if (IsFlanking(target)) then
		positional = "Flank"
	end
	if (IsFront(target)) then
		positional = "Front"
	end
	if HasBuff(Player.id,1250) then
		positional = "T.North"
	end
	return positional
end

-- Next Positional Attack
function RPRpositionalCheck()
	CorrectPos = ""
	if not rprACR:ActiveBuff("enhancedgallows") and not rprACR:ActiveBuff("enhancedgibbet") then
		CorrectPos = "Rear"
	end
	if rprACR:ActiveBuff("enhancedgibbet") then
		CorrectPos = "Flank"
	end
	if rprACR:ActiveBuff("enhancedgallows") then
		CorrectPos = "Rear"
	end
	if rprACR:ActiveBuff("truenorth") then
		CorrectPos = "TrueNorth"
	end
	return CorrectPos
end


function RPRLoadQTColor()
local function setColorValue(setting, trueValue, falseValue)
	if setting == true then
		return trueValue
	else
		return falseValue
	end
end

-- CD Color
RPRCDr = setColorValue(RPR_Settings.RPR_CD, 0.3, 0.6)
RPRCDg = setColorValue(RPR_Settings.RPR_CD, 0.55, 0.2)
RPRCDb = setColorValue(RPR_Settings.RPR_CD, 0.14, 0.2)
RPRCDa = 1

-- AOE Button Color
RPRAOEr = setColorValue(RPR_Settings.RPR_AOE, 0.3, 0.6)
RPRAOEg = setColorValue(RPR_Settings.RPR_AOE, 0.55, 0.2)
RPRAOEb = setColorValue(RPR_Settings.RPR_AOE, 0.14, 0.2)
RPRAOEa = 1

-- Defensives Button Color
RPRDEFr = setColorValue(RPR_Settings.RPR_DEF, 0.3, 0.6)
RPRDEFg = setColorValue(RPR_Settings.RPR_DEF, 0.55, 0.2)
RPRDEFb = setColorValue(RPR_Settings.RPR_DEF, 0.14, 0.2)
RPRDEFa = 1

-- Enshroud Button Color
RPRENSHROUDr = setColorValue(RPR_Settings.RPR_Enshroud, 0.3, 0.6)
RPRENSHROUDg = setColorValue(RPR_Settings.RPR_Enshroud, 0.55, 0.2)
RPRENSHROUDb = setColorValue(RPR_Settings.RPR_Enshroud, 0.14, 0.2)
RPRENSHROUDa = 1

-- Soulsow OoC Button Color
RPRSOULr = setColorValue(RPR_Settings.RPR_Soul, 0.3, 0.6)
RPRSOULg = setColorValue(RPR_Settings.RPR_Soul, 0.55, 0.2)
RPRSOULb = setColorValue(RPR_Settings.RPR_Soul, 0.14, 0.2)
RPRSOULa = 1

-- True North Color
RPRTNr = setColorValue(RPR_Settings.RPR_TN, 0.3, 0.6)
RPRTNg = setColorValue(RPR_Settings.RPR_TN, 0.55, 0.2)
RPRTNb = setColorValue(RPR_Settings.RPR_TN, 0.14, 0.2)
RPRTNa = 1

-- Harpe Color
RPRHRPr = setColorValue(RPR_Settings.RPR_Harpe, 0.3, 0.6)
RPRHRPg = setColorValue(RPR_Settings.RPR_Harpe, 0.55, 0.2)
RPRHRPb = setColorValue(RPR_Settings.RPR_Harpe, 0.14, 0.2)
RPRHRPa = 1
end

--QT Functions


function RPRCDQTfunc()
	RPR_Settings.RPR_CD = not RPR_Settings.RPR_CD
	RPRCDr, RPRCDg, RPRCDb =
		RPR_Settings.RPR_CD and 0.3 or 0.60,
		RPR_Settings.RPR_CD and 0.55 or 0.2,
		RPR_Settings.RPR_CD and 0.14 or 0.2,
	RPRCDa == 1
	rprACR.SaveSettings()
end

function RPRAOEQTfunc()
	RPR_Settings.RPR_AOE = not RPR_Settings.RPR_AOE
	RPRAOEr, RPRAOEg, RPRAOEb =
		RPR_Settings.RPR_AOE and 0.3 or 0.60,
		RPR_Settings.RPR_AOE and 0.55 or 0.2,
		RPR_Settings.RPR_AOE and 0.14 or 0.2,
	RPRAOEa == 1
	rprACR.SaveSettings()
end

function RPRDEFQTfunc()
	RPR_Settings.RPR_DEF = not RPR_Settings.RPR_DEF
	RPRDEFr, RPRDEFg, RPRDEFb =
		RPR_Settings.RPR_DEF and 0.3 or 0.60,
		RPR_Settings.RPR_DEF and 0.55 or 0.2,
		RPR_Settings.RPR_DEF and 0.14 or 0.2,
	RPRDEFa == 1
	rprACR.SaveSettings()
end

function RPRENSHROUDQTfunc()
	RPR_Settings.RPR_Enshroud = not RPR_Settings.RPR_Enshroud
	RPRENSHROUDr, RPRENSHROUDg, RPRENSHROUDb =
		RPR_Settings.RPR_Enshroud and 0.3 or 0.60,
		RPR_Settings.RPR_Enshroud and 0.55 or 0.2,
		RPR_Settings.RPR_Enshroud and 0.14 or 0.2,
	RPRENSHROUDa == 1
	rprACR.SaveSettings()
end

function RPRSOULQTfunc()
	RPR_Settings.RPR_Soul = not RPR_Settings.RPR_Soul
	RPRSOULr, RPRSOULg, RPRSOULb =
		RPR_Settings.RPR_Soul and 0.3 or 0.60,
		RPR_Settings.RPR_Soul and 0.55 or 0.2,
		RPR_Settings.RPR_Soul and 0.14 or 0.2,
	RPRSOULa == 1
	rprACR.SaveSettings()
end

function RPRTNQTfunc()
	RPR_Settings.RPR_TN = not RPR_Settings.RPR_TN
	RPRTNr, RPRTNg, RPRTNb =
		RPR_Settings.RPR_TN and 0.3 or 0.6,
		RPR_Settings.RPR_TN and 0.55 or 0.2,
		RPR_Settings.RPR_TN and 0.14 or 0.2,
	RPRTNa == 1
	rprACR.SaveSettings()
end

function RPRHRPQTfunc()
	RPR_Settings.RPR_Harpe = not RPR_Settings.RPR_Harpe
	RPRHRPr, RPRHRPg, RPRHRPb =
		RPR_Settings.RPR_Harpe and 0.3 or 0.6,
		RPR_Settings.RPR_Harpe and 0.55 or 0.2,
		RPR_Settings.RPR_Harpe and 0.14 or 0.2,
	RPRHRPa == 1
	rprACR.SaveSettings()
end

-- Out of Combat Soulsow // Needs Quick Toggle Function
function RPRSoulSow()
	if RPR_Settings.RPR_Soul then
		if not rprACR:ActiveBuff("soulsow") and not Player.incombat then
			ActionList:Get(1,24387):Cast(Player.id)
		end
	end
end


function rprACR.TargetFrom()
	local value = 0
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5")
	if targets ~= nil then
		for i,e in pairs(targets) do 
			value = value + 1 
		end
	end
	return value
end
 
function rprACR.setVar()
	for i,e in pairs(rprACR.rprSkill) do
		rprACR[i] = ActionList:Get(1,e[1])
		if rprACR[i] then
			if e[2] then
				rprACR[i]["isready"] = rprACR[i]:IsReady(MGetTarget().id) else rprACR[i]["isready"] = rprACR[i]:IsReady(Player)
			end
		end
	end
end

function rprACR:ActiveBuff(string)
	if rprACR.rprBuff[string] ~= nil then
		if HasBuff(Player.id,rprACR.rprBuff[string]) then
			return true
		end
	end
	return false
end

function rprACR:ActiveBuffDuration(string,timeLeft)
	if rprACR.rprBuff[string] ~= nil then
		if HasBuff(Player.id,rprACR.rprBuff[string],0,timeLeft) then
			return true
		end
	end
	return false
end

function rprACR:ActiveBuffOthers(string)
	local target = MGetTarget()
	if rprACR.rprBuff[string] ~= nil then
		if HasBuff(target.id,rprACR.rprBuff[string]) then
			return true
		end
	end
	return false
end

function rprACR:ActiveBuffOthersDuration(string, timeLeftOthers)
	local target = MGetTarget()
	if rprACR.rprBuff[string] ~= nil then
		if HasBuff(target.id,rprACR.rprBuff[string],0,timeLeftOthers) then
			return true
		end
	end
	return false
end

function rprACR.useSkill(skl,string)
	local text = (string)
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = rprACR[abil].isready
		if ACTready and text then
			rprACR[abil]:Cast(text.id)
			return true
		end
	end
	return false
end

function rprACR:skillID(string)
	if rprACR.rprSkill[string] ~= nil then
		return rprACR.rprSkill[string][1]
	end
end

function rprACR:LastAttackID(string)
	if rprACR:skillID(string) ~= nil then
		if Player.lastcomboid == rprACR:skillID(string) then
			return true
		end
	end
	return false
end

function rprACR:PersonalDOT()
local target = MGetTarget()
deathdesignActive = false
deathdesignDuration = deathdesignDuration or 0

if target == nil then return false end
	if table.valid(target.buffs) then
		for _, buff in pairs(target.buffs) do
			if ((buff.id == 2586) and buff.ownerid == Player.id) then
				deathdesignActive = true
				deathdesignDuration = buff.duration
			end
		end
	end
end
				
-- gauge 4 enshroud stacks || gauge 5 oGCD uses if 1 then ready 
function rprACR.Cast()
	RPRSoulSow()
    local currentTarget = MGetTarget()
	if (currentTarget == nil) then
		return false
	end
	local targetRadius = currentTarget.hitradius + 2
	if (currentTarget.attackable and (gStartCombat or currentTarget.incombat)) then
		rprACR.setVar()
		
		-- Enshroud Phase
		if rprACR:ActiveBuff("enshrouded") then
			if Player.gauge[4] == 1 and Player.gauge[3] ~= 0 and RPR_Settings.RPR_CD and rprACR.useSkill({"arcanecircle"}) then
				return
			end
			if Player.gauge[5] == 2 then
				if RPR_Settings.RPR_AOE and rprACR.TargetFrom() > 2 then
					if rprACR.useSkill({"lemurescythe"}) then
						return
					end
				else
					if rprACR.useSkill({"lemureslice"}) then
						return
					end
				end
			end
			if Player.gauge[4] == 1 and not Player:IsMoving() and rprACR.useSkill({"communio"}) then
				return
			end
			if (Player.level < 90) and Player.gauge[4] == 1 then
				if rprACR:ActiveBuff("enhancedcrossreaping") and rprACR.useSkill({"crossreaping"}) then
					return
				elseif rprACR:ActiveBuff("enhancedvoidreaping") and rprACR.useSkill({"voidreaping"}) then
					return
				end
			end
			if Player.gauge[4] > 1 and rprACR:ActiveBuff("enhancedcrossreaping") and rprACR.useSkill({"crossreaping"}) then
				return
			end
			if Player.gauge[4] > 1 and rprACR:ActiveBuff("enhancedvoidreaping") and rprACR.useSkill({"voidreaping"}) then
				return
			end
			if Player.gauge[4] > 1 and not rprACR:ActiveBuff("enhancedcrossreaping") and not rprACR:ActiveBuff("enhancedvoidreaping") and rprACR.useSkill({"crossreaping"}) then
				return
			end
		end
		
		-- Soulsow used - When to use Harvest Moon
		if (currentTarget.distance2d > targetRadius) and rprACR:ActiveBuff("soulsow") and rprACR.useSkill({"harvestmoon"}) then
			return
		end
		
		-- Arcane Circle if we have no resources.
		if RPR_Settings.RPR_CD and deathdesignActive and (not rprACR:ActiveBuff("enshrouded")) and (Player.gauge[2] < 10) and rprACR.useSkill({"arcanecircle"}, "Player") then
			return true
		end
			
		if (not rprACR:ActiveBuff("soulreaver")) and rprACR:ActiveBuff("immortalsacrifice") and rprACR.useSkill({"plentifulharvest"}) then
			return	
		end
			
		if RPR_Settings.RPR_Enshroud and ((ArcaneCircleCD.cd <= 95) or (ArcaneCircleCD.cd >= 112)) and not rprACR:ActiveBuff("soulreaver") and deathdesignActive and deathdesignDuration > 12 and rprACR.useSkill({"enshroud"}) then
			return
		elseif RPR_Settings.RPR_Enshroud and ((ArcaneCircleCD.cd <= 95) or (ArcaneCircleCD.cd >= 112)) and not rprACR:ActiveBuff("soulreaver") and deathdesignActive and deathdesignDuration <= 12 and rprACR.useSkill({"shadowofdeath"}) then
			return
		end
			
		--30sGCD (because they're GCDs for whatever reason.. :hqplaydead:)
		if deathdesignActive then
			if RPR_Settings.RPR_AOE and rprACR.TargetFrom() > 2 then
				if (not HasBuff(Player.id,2587)) and (Player.gauge ~= nil) and (Player.gauge[1] <= 50) and rprACR.useSkill({"soulscythe"}) then 
					return true
				end			
			else
				if (not HasBuff(Player.id,2587)) and (Player.gauge ~= nil) and (Player.gauge[1] <= 50) and rprACR.useSkill({"soulslice"}) then 
					return true
				end
			end
		end
		
		if (not rprACR:ActiveBuff("arcanecircle")) and rprACR.useSkill({"gluttony"}) then
			return
		end

		--ogcd gauge skills
		if RPR_Settings.RPR_AOE and rprACR.TargetFrom() > 2 then
			if rprACR.useSkill({"grimswathe"}) then
				return true
			end
		else
			if rprACR.useSkill({"bloodstalk","unveiledgibbet","unveiledgallows"}) then
				return true
			end	
		end			
			
		--procs gcd after gauge skill
		if RPR_Settings.RPR_AOE and rprACR.TargetFrom() > 2 then
			if rprACR:ActiveBuff("soulreaver") and rprACR.useSkill({"guillotine"}) then
				return true
			end		
		else
			if rprACR:ActiveBuff("soulreaver") and rprACR:ActiveBuff("enhancedgallows") and rprACR.useSkill({"gallows"}) then
				return true
			end	
			if rprACR:ActiveBuff("soulreaver") and rprACR:ActiveBuff("enhancedgibbet") and rprACR.useSkill({"gibbet"}) then
				return true
			end		
			if rprACR:ActiveBuff("soulreaver") and rprACR.useSkill({"gallows"}) then
				return true
			end
		end
		-- Apply debuff on foe(s)
		if RPR_Settings.RPR_AOE and rprACR.TargetFrom() > 2 then
			if ((deathdesignDuration <= 3) or (not deathdesignActive)) and rprACR.useSkill({"whorlofdeath"}) then
				return true
			end
		else
			if ((deathdesignDuration <= 3) or (not deathdesignActive))and rprACR.useSkill({"shadowofdeath"}) then
				return true
			end
		end
		
		if RPR_Settings.RPR_Harpe and currentTarget.distance2d > targetRadius and not Player:IsMoving() and rprACR.useSkill({"harpe"}) then
			ActionList:Get(1,24386):Cast(currentTarget.id)
			return
		end
		
		--123 combo // 12 aoe combo
		if RPR_Settings.RPR_AOE and rprACR.TargetFrom() > 2 then
			if rprACR:LastAttackID("spinningscythe") and rprACR.useSkill({"nightmarescythe"}) then
				return true
			end						
			if rprACR.useSkill({"spinningscythe"})  then
				return true
			end			
		else
			if rprACR:LastAttackID("waxingslice") and rprACR.useSkill({"infernalslice"}) then
				return true
			end		
			if rprACR:LastAttackID("slice") and rprACR.useSkill({"waxingslice"}) then
				return true
			end				
			if rprACR.useSkill({"slice"}) then
				return true
			end
		end
		
		-- Defensives
		if RPR_Settings.RPR_DEF and oGCDReady then
			if Player.hp.percent <= RPR_Settings.RPR_bbSlider and rprACR.useSkill({"bloodbath"},"Player") then
				return
			end
			
			if Player.hp.percent <= RPR_Settings.RPR_feintSlider and rprACR.useSkill({"feint"}) then
				return
			end
			
			if Player.hp.percent <= RPR_Settings.RPR_arcSlider and rprACR.useSkill({"arcanecrest"},"Player") then
				return
			end
		end
		
	return false
	end
end



function rprACR.Draw()
    if (rprACR.GUI.open) then	
	rprACR.GUI.visible, rprACR.GUI.open = GUI:Begin(rprACR.GUI.name, rprACR.GUI.open, GUI.WindowFlags_NoResize)
	if ( rprACR.GUI.visible ) then 
            GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Utility",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3			
		end
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")
		end
		
		--Tabs
		
		--Main Tab 
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:BulletText("Wxlfee's Reaper ACR")
				GUI:Text("1.1.1 Changelogs:")
				GUI:Text("Rotation rewritten.")
				GUI:Text("New QTs added.")
				GUI:Text("_________________________________________________")
			end
		-- Utility Tab
			if (TabIndex == 2) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Text("Arcane Crest")
				RPR_Settings.RPR_arcSlider, crest = GUI:SliderInt("HP%",RPR_Settings.RPR_arcSlider,0,100)
				if crest then
					RPR_Settings.RPR_arcSlider = RPR_Settings.RPR_arcSlider
					rprACR.SaveSettings()
				end
				GUI:Text("_________________________________________________")
				GUI:Text("Bloodbath")
				RPR_Settings.RPR_bbSlider, blood = GUI:SliderInt("HP%##",RPR_Settings.RPR_bbSlider,0,100)
				if blood then
					RPR_Settings.RPR_bbSlider = RPR_Settings.RPR_bbSlider
					rprACR.SaveSettings()
				end
				GUI:Text("_________________________________________________")
				GUI:Text("Feint")
				RPR_Settings.RPR_feintSlider, feint = GUI:SliderInt("HP%###",RPR_Settings.RPR_feintSlider,0,100)
				if feint then
					RPR_Settings.RPR_feintSlider = RPR_Settings.RPR_feintSlider
					rprACR.SaveSettings()
				end
				GUI:Text("_________________________________________________")
			end
			if (TabIndex == 3) then
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",168,30)
				if GUI:IsItemClicked() then
					RPROpenQT()
				end
				GUI:SameLine()
				GUI:Button("Open Positional UI",168,30)
				if GUI:IsItemClicked() then
					RPROpenPOS()
				end
			end
			if (TabIndex == 4) then
				GUI:Text("_________________________________________________")
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")					
				end
				GUI:Text("_________________________________________________")
			end
        end
        GUI:End()
    end
	
	-- Quick Toggles
	if (RPR_Settings.RPR_QT_GUI) then
	local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
	rprACR.GUIQT.visible, rprACR.GUIQT.open = GUI:Begin(rprACR.GUIQT.name, rprACR.GUIQT.open, flags2)
	if (rprACR.GUIQT.visible) then
		GUI:SetWindowSize(0,0,0)
		-- CD
		GUI:PushStyleColor(GUI.Col_Button, RPRCDr,RPRCDg,RPRCDb,RPRCDa)
		rprCDButton = GUI:Button("CD",90,30)
		GUI:PopStyleColor(1)
		if GUI:IsItemClicked() then
			RPRCDQTfunc()
		end
		GUI:SameLine()
		-- AOE
		GUI:PushStyleColor(GUI.Col_Button, RPRAOEr,RPRAOEg,RPRAOEb,RPRAOEa)	
		rprAOE = GUI:Button("AOE",90,30)
		GUI:PopStyleColor(1)
		if GUI:IsItemClicked() then
			RPRAOEQTfunc()
		end
		GUI:SameLine()
		-- Defensives
		GUI:PushStyleColor(GUI.Col_Button, RPRDEFr,RPRDEFg,RPRDEFb,RPRDEFa)	
		rprDEFButton = GUI:Button("Defensives",90,30)
		GUI:PopStyleColor(1)
		if GUI:IsItemClicked() then
			RPRDEFQTfunc()
		end
		if GUI:IsItemHovered() then
			GUI:SetTooltip("Enables abilities such as Bloodbath/Second Wind/Feint \n I suggest NOT using this in raids.")
		end
		--Enshroud
		GUI:PushStyleColor(GUI.Col_Button, RPRENSHROUDr,RPRENSHROUDg,RPRENSHROUDb,RPRENSHROUDa)	
		rprEnshroudButton = GUI:Button("Enshroud",90,30)
		GUI:PopStyleColor(1)
		if GUI:IsItemClicked() then
			RPRENSHROUDQTfunc()
		end
		if GUI:IsItemHovered() then
			GUI:SetTooltip("Enables Enshroud Phase.")
		end
		GUI:SameLine()
		--Soulsow
		GUI:PushStyleColor(GUI.Col_Button, RPRSOULr,RPRSOULg,RPRSOULb,RPRSOULa)	
		rprSOULButton = GUI:Button("Soulsow OoC",90,30)
		GUI:PopStyleColor(1)
		if GUI:IsItemClicked() then
			RPRSOULQTfunc()
		end
		if GUI:IsItemHovered() then
			GUI:SetTooltip("Uses Soulsow out of combat.")
		end
		GUI:SameLine()
		-- Harpe
		GUI:PushStyleColor(GUI.Col_Button, RPRHRPr,RPRHRPg,RPRHRPb,RPRHRPa)
		rprHarpeButton = GUI:Button("Harpe",90,30)
		GUI:PopStyleColor(1)
		if GUI:IsItemClicked() then
			RPRHRPQTfunc()
		end
		if GUI:IsItemHovered() then
			GUI:SetTooltip("Enable/Disable Harpe.")
		end
		GUI:PushStyleColor(GUI.Col_Button, RPRTNr,RPRTNg,RPRTNb,RPRTNa)
		rprTNButton = GUI:Button("TN",90,30)
		GUI:PopStyleColor(1)
		if GUI:IsItemClicked() then
			RPRTNQTfunc()
		end
		if GUI:IsItemHovered() then
			GUI:SetTooltip("Enable True North for wrong positionals")
		end
	end
	GUI:End()
	end
	
	if (RPR_Settings.RPR_POS_GUI) then
	local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
		rprACR.GUIPOS.visible, rprACR.GUIPOS.open = GUI:Begin(rprACR.GUIPOS.name, rprACR.GUIPOS.open, flags2)
			if (rprACR.GUIPOS.visible) then
				GUI:SetWindowSize(210,50,0)
				GUI:Text("Current Positional: ")
				GUI:SameLine()
				if CorrectPos ~= nil then
					if positional == CorrectPos then
						GUI:TextColored(0.3,1,0.14,1,positional)
					elseif not positional == CorrectPos then
						GUI:TextColored(1,0.2,0.2,1,positional)
					else
						GUI:Text(positional)
					end
				end
				GUI:Separator()
				GUI:Text("Next Positional: ")
				GUI:SameLine()
				GUI:Text(CorrectPos)
			end
		GUI:End()
	end
end

function rprACR.SaveSettings()
	d("[WxlfeeCore] Settings have been saved.")
	WXSave()
end

function rprACR.LoadSettings()
	RPRloadsettings(tbl)
end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function RPRloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    RPR_Settings = scan(RPR_Settings,tbl)
end

function rprACR.OnOpen()
    rprACR.GUI.open = true
end
 
function rprACR.OnLoad()
	checkFile()
	rprACR.LoadSettings()
	RPRLoadQTColor()
	CasuallyVersion = "1.0.0"
end
 
function rprACR.OnClick(mouse,shiftState,controlState,altState,entity)
 
end
 
function rprACR.OnUpdate(event, tickcount)
	playerPos(target)
	RPRpositionalCheck()
	rprACR:PersonalDOT()
	RPR_oGCDisReady()
	rprACR.LoadSettings()
end
 
return rprACR