local pldACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .. [[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath .. [[PLDsettings.lua]]
local v = table.valid


CD = ActionList:Get(1,9)
FoFCD = ActionList:Get(1,20)

local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("PLDsettings.lua","w")
		localfile:write(PLD_Settings)
		file:close()
	end
end

local PLD_Settings = {
	PLD_QT_GUI = false,
	
	PLD_CDs = true,
	PLD_AOE = true,
	PLD_DEF = true,
	PLD_Jump = true,
	PLD_Stance = true,
	PLD_ShieldLob = true,
	PLD_AutoVoke = false,
	PLD_Interrupt = false,
	PLD_Reprisal = true,
	
	PLD_repSlider = 3,
	PLD_AOEslider = 3,
	
	PLD_RAMPslider = 80,
	PLD_SENTslider = 60,
	PLD_Bulkwarkslider = 90,
	PLD_DivineVeilslider = 65,
}

local function WXSave()
	FileSave(ModuleSettings,PLD_Settings)
end

pldACR.classes = {
	[FFXIV.JOBS.GLADIATOR] = true,
	[FFXIV.JOBS.PALADIN] = true,
}

pldACR.GUI = {
	open = true,
	visible = true,
	name = "Casually Paladin",
}

pldACR.GUIQT = {
	open = false,
	visible = true,
	name = "WX_QuickToggles",
}

pldACR.pldBuff = {
		ironwill = 79,
		fightorflight = 76,
		divinemight = 2673,
		swordoath = 1902,
		requiescat = 1368,
		confiteorready = 3019,
		holysheltron = 2674,
		rampart = 1191,
		sentinel = 74,
	}



pldACR.pldSkill = {

		fastblade = {9,true},
		riotblade = {15,true},
		rageofhalone = {21,true},
		royalauthority = {3539,true},
		shieldlob = {24,true},
		goringblade = {3538,true},
		confiteor = {16459,true},
		bladeoffaith = {25748,true},
		bladeoftruth = {25749,true},
		bladeofvalor = {25750,true},
		holyspirit = {7384,true},
		holycircle = {16458,false},
		atonement = {16460,true},
		
		
		-- AOE
		totaleclipse = {7381,false},
		
		-- oGCD
		intervene = {16461,true},
		circleofscorne = {23,false},
		spiritswithin = {29,true},
		expiacion = {25747,true},
		requiescat = {7383,true},
		
		interject = {7538,true},
		
		
		
		-- Buffs
		fightorflight = {20,false},
		
		-- Defensives
		rampart = {7531,false},
		sentinel = {17,false},
		bulwark = {22,false},
		divineveil = {3540,false},
		sheltron = {3542,false},
		holysheltron = {25746,false},
		reprisal = {7535,false},
		
		
	}

function PLDOpenQT()
	PLD_Settings.PLD_QT_GUI = not PLD_Settings.PLD_QT_GUI
	pldACR.SaveSettings()
end

-- Quick Toggle Load Color

function PLDLoadQTColor()
local function setColorValue(setting, trueValue, falseValue)
	if setting == true then
		return trueValue
	else
		return falseValue
	end
end

-- CD Color
PLDCDr = setColorValue(PLD_Settings.PLD_CDs, 0.3, 0.6)
PLDCDg = setColorValue(PLD_Settings.PLD_CDs, 0.55, 0.2)
PLDCDb = setColorValue(PLD_Settings.PLD_CDs, 0.14, 0.2)
PLDCDa = 1

-- AOE Color
PLDAOEr = setColorValue(PLD_Settings.PLD_AOE, 0.3, 0.6)
PLDAOEg = setColorValue(PLD_Settings.PLD_AOE, 0.55, 0.2)
PLDAOEb = setColorValue(PLD_Settings.PLD_AOE, 0.14, 0.2)
PLDAOEa = 1

--Stance Color
PLDSTANCEr = setColorValue(PLD_Settings.PLD_Stance, 0.3, 0.6)
PLDSTANCEg = setColorValue(PLD_Settings.PLD_Stance, 0.55, 0.2)
PLDSTANCEb = setColorValue(PLD_Settings.PLD_Stance, 0.14, 0.2)
PLDSTANCEa = 1

--Jump Color
PLDJUMPr = setColorValue(PLD_Settings.PLD_Jump, 0.3, 0.6)
PLDJUMPg = setColorValue(PLD_Settings.PLD_Jump, 0.55, 0.2)
PLDJUMPb = setColorValue(PLD_Settings.PLD_Jump, 0.14, 0.2)
PLDJUMPa = 1

--Defensives
PLDDEFr = setColorValue(PLD_Settings.PLD_DEF, 0.3, 0.6)
PLDDEFg = setColorValue(PLD_Settings.PLD_DEF, 0.55, 0.2)
PLDDEFb = setColorValue(PLD_Settings.PLD_DEF, 0.14, 0.2)
PLDDEFa = 1

--Ranged Attack
PLDLOBr = setColorValue(PLD_Settings.PLD_ShieldLob, 0.3,0.6)
PLDLOBg = setColorValue(PLD_Settings.PLD_ShieldLob, 0.55,0.2)
PLDLOBb = setColorValue(PLD_Settings.PLD_ShieldLob, 0.14,0.2)
PLDLOBa = 1

--Auto Voke
PLDVOKEr = setColorValue(PLD_Settings.PLD_AutoVoke, 0.3, 0.6)
PLDVOKEg = setColorValue(PLD_Settings.PLD_AutoVoke, 0.55, 0.2)
PLDVOKEb = setColorValue(PLD_Settings.PLD_AutoVoke, 0.14, 0.2)
PLDVOKEa = 1

--Interrupt
PLDRUPTr = setColorValue(PLD_Settings.PLD_Interrupt, 0.3, 0.6)
PLDRUPTg = setColorValue(PLD_Settings.PLD_Interrupt, 0.55, 0.2)
PLDRUPTb = setColorValue(PLD_Settings.PLD_Interrupt, 0.14, 0.2)
PLDRUPTa = 1
end

-- Quick Toggle functions

function PLDOpenQT()
	PLD_Settings.PLD_QT_GUI = not PLD_Settings.PLD_QT_GUI
	pldACR.SaveSettings()
end

function PLDCDQTfunc()
	PLD_Settings.PLD_CDs = not PLD_Settings.PLD_CDs
	pldACR.SaveSettings()
end

function PLDAOEQTfunc()
	PLD_Settings.PLD_AOE = not PLD_Settings.PLD_AOE
	pldACR.SaveSettings()
end

function PLDJUMPQTfunc()
	PLD_Settings.PLD_Jump = not PLD_Settings.PLD_Jump
	pldACR.SaveSettings()
end

function PLDDEFQTfunc()
	PLD_Settings.PLD_DEF = not PLD_Settings.PLD_DEF
	pldACR.SaveSettings()
end

function PLDStanceQTfunc()
	PLD_Settings.PLD_Stance = not PLD_Settings.PLD_Stance
	pldACR.SaveSettings()
end

function PLDVOKEQTfunc()
	PLD_Settings.PLD_AutoVoke = not PLD_Settings.PLD_AutoVoke
	pldACR.SaveSettings()
end

function PLDLOBQTfunc()
	PLD_Settings.PLD_ShieldLob = not PLD_Settings.PLD_ShieldLob
	pldACR.SaveSettings()
end

function PLDRUPTQTfunc()
	PLD_Settings.PLD_Interrupt = not PLD_Settings.PLD_Interrupt
	pldACR.SaveSettings()
end

function PLDAggroPercentage(targetid)
    aggroTargets = MEntityList("alive,attackable,aggro,targetable,maxdistance=20,distanceto=" .. tostring(targetid))
    
	if aggroTargets ~= nil then
		for i, enemyAggro in pairs(aggroTargets) do
			if Player.incombat and enemyAggro.alive and enemyAggro.AggroPercentage < 100 then
				global_enemy = enemyAggro
				return global_enemy
			end
		end
	else
		return false
	end
end



function pldACR.stanceEnabled()
	if (PLD_Settings.PLD_Stance) then
		if not pldACR:BuffActive("ironwill") then
			ActionList:Get(1,28):Cast(Player.id)
		end
	end
	if (not PLD_Settings.PLD_Stance) then
		if pldACR:BuffActive("ironwill") then
			ActionList:Get(1,28):Cast(Player.id)
		end
	end
end

function pldACR:skillID(string)
	if pldACR.pldSkill[string] ~= nil then
		return pldACR.pldSkill[string][1]
	end
end

function pldACR:LastAttackID(string)
	if pldACR:skillID(string) ~= nil then
		if Player.lastcomboid == pldACR:skillID(string) then
			return true
		end
	end
	return false
end

function pldACR:BuffActive(string)
	if pldACR.pldBuff[string] ~= nil then
		if HasBuff(Player.id,pldACR.pldBuff[string]) then
			return true
		end
	end
	return false
end

-- Misc BS
TabIndex = 1

function pldACR.TargetFrom(entity)
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5,distanceto="..tostring(entity))
	return (table.size(targets))
end

function pldACR.setVar()
	for i,e in pairs(pldACR.pldSkill) do
		pldACR[i] = ActionList:Get(1,e[1])
		if pldACR[i] then
			if e[2] then
				pldACR[i]["isready"] = pldACR[i]:IsReady(MGetTarget().id) else pldACR[i]["isready"] = pldACR[i]:IsReady(Player)
			end
		end
	end
end

function pldACR.useSkill(skl,string)
	local text = (string)
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = pldACR[abil].isready
		if ACTready then
			pldACR[abil]:Cast(text.id)
			return true
		end
	end
	return false
end

function PLD_oGCDReady()
	oGCDisReady = false
	WeaveTime = (CD.cdmax/5)*2.25
	CDMax = CD.cdmax
		if CD.cd < WeaveTime then
			oGCDisReady = true
		elseif (CD.cd > WeaveTime) or (CD.cd == 0) then
			oGCDisReady = false
		end
end

local function CheckSkillsUnlock()
local PlayerLevel = Player.level
local shieldlob_id = ActionList:Get(1,24)
can_use_shield_lob = false

if PlayerLevel >= shieldlob_id.level and QuestCompleted(262) then
	can_use_shield_lob = true
else
	can_use_shield_lob = false
end

end

function PLDCheckDefensives()
PLD_NoActiveBuff = true

	if pldACR:BuffActive("rampart") then
		PLD_NoActiveBuff = false
	end

	if pldACR:BuffActive("sentinel") then
		PLD_NoActiveBuff = false
	end
	
return GNB_NoActiveBuff

end

function PLD_OneMinCheck()
local playerLevel = Player.level
OneMinReady = false
PLD_is_Pooling = false

if pldACR:BuffActive("fightorflight") then
	OneMinReady = true
end

if (FoFCD.isoncd and FoFCD.cd >= 50) then
	PLD_is_Pooling = true
elseif (PLD_Settings.PLD_CDs and not FoFCD.isoncd) then
	PLD_is_Pooling = true
end
-- Level 90 Check
	if playerLevel == 90 then

	end
-- Temp < 90 Check
	if playerLevel <= 89 then

	end
end

function pldACR.Cast()
	local currentTarget = MGetTarget()
	pldACR.stanceEnabled()
	if (currentTarget == nil) then
		return false
	end
	local targetRadius = currentTarget.hitradius + 2
	if (currentTarget.attackable and (gStartCombat or currentTarget.incombat)) then
		pldACR.setVar()
		
		if PLD_Settings.PLD_Interrupt and oGCDisReady and currentTarget.castinginfo.castinginterruptible and pldACR.useSkill({"interject"}) then
			return true
		end
		
		if PLD_Settings.PLD_Jump and oGCDisReady and pldACR:BuffActive("fightorflight") and pldACR.useSkill({"intervene"}) then
			return true
		end
		
		if currentTarget.distance <= 5 and PLD_Settings.PLD_CDs then
			if oGCDisReady and pldACR.useSkill({"fightorflight"}) then
				return true
			end
		end
		
		if PLD_Settings.PLD_CDs then
			if not pldACR:BuffActive("requiescat") and not PLD_is_Pooling then
				if pldACR:BuffActive("divinemight") and pldACR.TargetFrom(Player.id) > 2 then
					if pldACR.useSkill({"holycircle"}) then
						return true
					end
				elseif pldACR:BuffActive("divinemight") then
					if pldACR.useSkill({"holyspirit"}) then
						return true
					end
				end
			end
		end
			
		if pldACR:BuffActive("requiescat") and Player.level == 90 then
			if pldACR.useSkill({"confiteor", "bladeoffaith", "bladeoftruth", "bladeofvalor"}) then
				return true
			end
		elseif pldACR:BuffActive("requiescat") then
			if pldACR.useSkill({"confiteor"}) then
				return true
			end
			if pldACR.useSkill({"holyspirit"}) then
				return true
			end
		end
				
		if (OneMinReady or (not PLD_is_Pooling)) and oGCDisReady then
			if pldACR.useSkill({"spiritswithin", "expiacion"}) then
				return true
			end
			if pldACR.useSkill({"circleofscorne"}) then
				return true
			end
		end
			
		if PLD_Settings.PLD_CDs and OneMinReady then
			if pldACR.useSkill({"goringblade"}) then
				return true
			end
			if oGCDisReady and pldACR.useSkill({"requiescat"}) then
				return true
			end
		end
		
		if Player.gauge[1] >= 95 and oGCDisReady and pldACR.useSkill({"sheltron", "holysheltron"}) then
			return true
		end	

		
		if PLD_Settings.PLD_ShieldLob and currentTarget.distance2d > targetRadius and can_use_shield_lob and pldACR.useSkill({"shieldlob"}) then
			return true
		end
		
		if pldACR.useSkill({"atonement"}) then
			return true
		end	
		if (PLD_Settings.PLD_AOE) and pldACR.TargetFrom(Player.id) >= 2 and currentTarget.distance <= targetRadius then
			if pldACR.useSkill({"totaleclipse"}) then
				return true
			end
		else
			if pldACR:LastAttackID("riotblade") and pldACR.useSkill({"rageofhalone","royalauthority"}) then
				return true
			elseif pldACR:LastAttackID("fastblade") and pldACR.useSkill({"riotblade"}) then
				return true
			else
				if pldACR.useSkill({"fastblade"}) then
					return true
				end
			end
		end
		if pldACR.TargetFrom(Player.id) >= PLD_Settings.PLD_repSlider and pldACR.useSkill({"reprisal"}) then
			return true
		end
		if PLD_Settings.PLD_DEF and oGCDisReady then
			if PLD_NoActiveBuff and Player.hp.percent <= PLD_Settings.PLD_RAMPslider and pldACR.useSkill({"rampart"}) then
				return true
			end
			
			if PLD_NoActiveBuff and Player.hp.percent <= PLD_Settings.PLD_SENTslider and pldACR.useSkill({"sentinel"}) then
				return true
			end
			
			if Player.hp.percent <= PLD_Settings.PLD_Bulkwarkslider and pldACR.useSkill({"bulwark"}) then
				return true
			end
			
			if Player.hp.percent <= PLD_Settings.PLD_DivineVeilslider and pldACR.useSkill({"divineveil"}) then
				return true
			end
		end
	
	return false
	end
end

function pldACR.Draw()
	if (pldACR.GUI.open) then
	pldACR.GUI.visible, pldACR.GUI.open = GUI:Begin(pldACR.GUI.name, pldACR.GUI.open, GUI.WindowFlags_NoResize)
	if (pldACR.GUI.visible) then
		GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Defensives",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3
		end
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")
		end
		
		-- Tabs
		
		--Main Tab
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:BulletText("Wxlfee's Paladin ACR")
				GUI:Text("1.0.0 Changelogs:")
				GUI:Text("L90 Tested.")
				GUI:Text("Interrupt toggle implemented.")
				GUI:Text("_________________________________________________")
			end
		--Defensives Tab
			if (TabIndex == 2) then
				GUI:SetWindowSize(367,184,0)
				GUI:Text("_________________________________________________")
				local ramp
				GUI:Text("Rampart")
				PLD_Settings.PLD_RAMPslider, ramp = GUI:SliderInt("HP%", PLD_Settings.PLD_RAMPslider,0,100)
				GUI:Text("_________________________________________________")
				if (ramp) then
					d(PLD_Settings.PLD_RAMPslider)
					PLD_Settings.PLD_RAMPslider = PLD_Settings.PLD_RAMPslider
					pldACR.SaveSettings()
				end
				GUI:Text("Sentinel")
				PLD_Settings.PLD_SENTslider, sent = GUI:SliderInt("HP% ", PLD_Settings.PLD_SENTslider,0,100)
				GUI:Text("_________________________________________________")
				if (sent) then
					d(PLD_Settings.PLD_SENTslider)
					PLD_Settings.PLD_SENTslider = PLD_Settings.PLD_SENTslider
					pldACR.SaveSettings()
				end
				GUI:Text("Bulwark")
				PLD_Settings.PLD_Bulkwarkslider, bulw = GUI:SliderInt("HP%  ", PLD_Settings.PLD_Bulkwarkslider,0,100)
				GUI:Text("_________________________________________________")
				if (bulw) then
					d(PLD_Settings.PLD_Bulkwarkslider)
					PLD_Settings.PLD_Bulkwarkslider = PLD_Settings.PLD_Bulkwarkslider
					pldACR.SaveSettings()
				end
				GUI:Text("Divine Veil")
				PLD_Settings.PLD_DivineVeilslider, divveil = GUI:SliderInt("HP%   ", PLD_Settings.PLD_DivineVeilslider,0,100)
				GUI:Text("_________________________________________________")
				if (divveil) then
					d(PLD_Settings.PLD_DivineVeilslider)
					PLD_Settings.PLD_DivineVeilslider = PLD_Settings.PLD_DivineVeilslider
					pldACR.SaveSettings()
				end
			end
			if (TabIndex == 3) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",344,25)
				if GUI:IsItemClicked() then
					PLDOpenQT()
				end
				PLD_Settings.PLD_Reprisal, rsal = GUI:Checkbox("Use Reprisal: ", PLD_Settings.PLD_Reprisal)
					if (PLD_Settings.PLD_Reprisal == true) then
						local rsal
						GUI:Text("Reprisal")
						PLD_Settings.PLD_repSlider, rsal = GUI:SliderInt("Targets",PLD_Settings.PLD_repSlider,1,4)						
						if (rsal) then
							PLD_Settings.PLD_repSlider = PLD_Settings.PLD_repSlider
							pldACR.SaveSettings()
						end						
					end
					if (PLD_Settings.WAR_reprisal == false) then
					end
					GUI:Text("AOE Targets required.")
					PLD_Settings.PLD_AOEslider, aoeslider = GUI:SliderInt(">= Targets##",PLD_Settings.PLD_AOEslider,2,8)
						if (aoeslider) then
							PLD_Settings.PLD_AOEslider = PLD_Settings.PLD_AOEslider
							pldACR.SaveSettings()
						end
			end
			if (TabIndex == 4) then
				GUI:SetWindowSize(0,0,0)				
				GUI:Text("_________________________________________________")				
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")
				end
				GUI:Text("_________________________________________________")
			end
		
		end
		GUI:End()
		
		if (PLD_Settings.PLD_QT_GUI) then
		local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
			pldACR.GUIQT.visible, pldACR.GUIQT.open = GUI:Begin(pldACR.GUIQT.name, pldACR.GUIQT.open, flags2)
			if (pldACR.GUIQT.visible) then
				GUI:SetWindowSize(0,0,0)
				GUI:PushStyleColor(GUI.Col_Button, PLDCDr, PLDCDg, PLDCDb, PLDCDa)
				PLDCDButton = GUI:Button("CD",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					PLDCDQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, PLDAOEr, PLDAOEg, PLDAOEb, PLDAOEa)
				PLDAOEButton = GUI:Button("AOE",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					PLDAOEQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, PLDDEFr, PLDDEFg, PLDDEFb, PLDDEFa)
				PLDDEFButton = GUI:Button("Defensives",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					PLDDEFQTfunc()
				end
				GUI:PushStyleColor(GUI.Col_Button, PLDSTANCEr, PLDSTANCEg, PLDSTANCEb, PLDSTANCEa)
				PLDStanceButton = GUI:Button("Stance",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					PLDStanceQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, PLDJUMPr, PLDJUMPg, PLDJUMPb, PLDJUMPa)
				PLDJMPButton = GUI:Button("Jumps",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					PLDJUMPQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, PLDLOBr, PLDLOBg, PLDLOBb, PLDLOBa)
				PLDLOBbutton = GUI:Button("Shield Lob",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					PLDLOBQTfunc()
				end
				GUI:PushStyleColor(GUI.Col_Button, PLDVOKEr, PLDVOKEg, PLDVOKEb, PLDVOKEa)
				PLDVOKEbutton = GUI:Button("Auto Voke",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					PLDVOKEQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, PLDRUPTr, PLDRUPTg, PLDRUPTb, PLDRUPTa)
				PLDRUPTbutton = GUI:Button("Interrupt",90,30)
				GUI:PopStyleColor(1)
				if GUI:IsItemClicked() then
					PLDRUPTQTfunc()
				end
			end
		GUI:End()
	end
end
end

function pldACR.OnOpen()
	pldACR.GUI.open = true
end

function pldACR.QTOnOpen()
	pldACR.GUIQT.open = true
end

function pldACR.SaveSettings()
	d("[WxlfeeCore] Settings have been saved.")
	WXSave()
end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function PLDloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    PLD_Settings = scan(PLD_Settings,tbl)
end

function pldACR.LoadSettings()
	PLDloadsettings(tbl)
end

function pldACR.OnLoad()
	checkFile()
	TabIndex = 1
	pldACR.LoadSettings()	
end

function pldACR.OnClick(mouse,shiftState,controlState,altState,entity)

end

function pldACR.OnUpdate(event, tickcount)
	PLD_oGCDReady()
	CheckSkillsUnlock()
	PLDLoadQTColor()
	PLD_OneMinCheck()
	PLDCheckDefensives()
	PLDAggroPercentage(Player.id)
end

return pldACR