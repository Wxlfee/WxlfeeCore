smnACR = {isPVE = true, isPVP = false}
local LuaPath = GetLuaModsPath()
local ModulePath = LuaPath .. [[WxlfeeCore\\Settings\\]]
local ModuleSettings = ModulePath .. [[SMNsettings.lua]]
local v = table.valid


local function checkFile()
local localfile = ModuleSettings
	if localfile == nil then
		localfile = io.open("SMNsettings.lua","w")
		localfile:write(SMN_Settings)
		file:close()
	end
end

function CalculateNewPosition(mousex, minx, maxx, sizex, currentPos, tsize)
    local itemWidth = sizex / tsize
    local mouseIndex = math.floor((mousex - minx) / itemWidth) + 1
    d(math.max(1, math.min(tsize, mouseIndex)))
    return math.max(1, math.min(tsize, mouseIndex))
end

local SMN_Settings = {
	SMN_QT_GUI = false,
	
	Summons = {
	[1] = "Ifrit", 
	[2] = "Titan", 
	[3] = "Garuda",
	},
	
	SMN_CD = true,
	SMN_AOE = true,
	SMN_Pets = true,
	SMN_Jumps = true,
	SMN_DEF = false,
	
	SMN_Addle_Slider = 80,
	SMN_Aegis_Slider = 90,
	SMN_Lucid_Slider = 75,
	
}

smnACR.summonOrder = {
	Summons = SMN_Settings.Summons,
	pos = 0,
	lastPos = -1,
}

-- 25800 - aethercharge
-- 25808 - ruby ruin
local function WXSave()
	FileSave(ModuleSettings,SMN_Settings)
end

smnACR.classes = {
	[FFXIV.JOBS.SUMMONER] = true,
	[FFXIV.JOBS.ARCANIST] = true,
}

smnACR.GUI = {
	open = true,
	visible = true,
	name = "Casually Summoner",
}

smnACR.GUIQT = {
	open = true,
	visible = true,
	name = "WX_QuickToggles"
}

CD = ActionList:Get(1,69)
EnergyDrainCD = ActionList:Get(1,16508)
SearingLightCD = ActionList:Get(1,25801)
summonBahamutCD = ActionList:Get(1,7427)

smnACR.smnBuff =
	{
		aetherflow = 304,
		furtherruin = 2701,
		
		IfritFavour = 2724,
		TitanFavour = 2853,
		GarudaFavour = 2725,
		
		radiantaegis = 2702,
		
	}

smnACR.smnSkill =
	{
		ruin = {163,true}, -- Low Level Main Cast
		ruin3 = {3579,true}, -- High Level Main Cast
		gemshine = {25883,true},
		astralflow = {25822,true},
		ruin4 = {7426,true}, -- Insta Cast // Use for movement/pooling
		outburst = {16511,true}, -- Low Level AOE Cast
		tridisaster = {25826,true}, -- High Level AOE Cast
		fester = {181,true}, -- Aetherflow stack oGCD
		painflare = {3578,true}, -- Aetherflow stack AOE oGCD
		aethercharge = {25800,true},
		energydrain = {16508,true}, -- oGCD Grants Further Ruin // 2 Aetherflow stacks
		energysiphon = {16510,true}, -- AOE oGCD Grants Further Ruin // 2 Aetherflow stacks
		dreadwyrmtrance = {3581,false}, -- L58 Bruhamut ability
		
		-- Buffs
		searinglight = {25801,false},
		radiantaegis = {25799,false},
		addle = {7560,true},
		luciddreaming = {7562,false},
		
		-- Pet Stuff
		summonCarbuncle = {25798,false}, -- Summon Carbuncle - Initial Pet Summon
		summonRuby = {25802,true}, -- Summon Ruby Carbuncle - Ruby Attack
		summonTopaz = {25803,true}, -- Summon Topaz Carbuncle - Topaz Attack
		summonEmerald = {25804,true}, -- Summon Emerald Carbuncle - Emerald Attack
		
		summonBahamut = {7427,true},
		deathflare = {3582,true},
		enkindleBahamut = {7429,true},
		astralimpulse = {25820,true},
		astralflare = {25821,true},
		
		summonPhoenix = {25831,true},
		enkindlePhoenix = {16516,true},
		rekindle = {25830,true},
		phoenixsingle = {16514,true},
		phoenixaoe = {16515,true},
		
		summonTitanII = {25839,true},
		topazRite = {25824,true},
		topazruin3 = {25818,true},
		mountainbuster = {25836,true},
		topazcatastrophe = {25833,true},
		
		summonIfritII = {25838,true},
		rubyRite = {25823,true},
		rubyruin3 = {25817,true},
		crimsoncyclone = {25835,true}, -- Dash
		crimsonstrike = {25885,true},-- Book slap
		rubycatastrophe = {25832,true},
		
		summonGarudaII = {25840,true},
		emeraldRite = {25825,true},
		emeraldruin3 = {25819,true},
		slipstream = {25837,true},
		emeraldcatastrophe = {25834,true},
	
		summonTitan = {25806,true}, -- Summon Titan
		summonGaruda = {25807,true}, -- Summon Garuda
		summonIfrit = {25805,true}, -- Summon Ifrit
		
		topazRuin = {25812,true}, -- Topaz Ruin
		emeraldRuin = {25813,true},
		rubyRuin = {25808,true},
		
		-- Mitigation
		radiantaegis = {25799,false}, -- 20% Shield / 2 Stack
		physick = {16230,false}, -- Shit heal, worthless but I guess useful sub level 30
		addle = {7560,true}, -- 10% Magic Mit // 5% Physical Mit
		
		
	}
	
-- Gauges

-- [1] = Time left for Baha and Phoe
-- [2] =
-- [3] = Rite Charges
-- [4] =
-- [5] = Ifrit Charge
-- [6] = Titan Charge
-- [7] = Garuda Charge
-- [8] = 
-- [9] = Which Summon is active








local mode = "Swap"
local names = {
	"Ifrit", "Titan", "Garuda"
}

local draggedItem = nil
local draggedItemIndex = nil
local mx, my = GUI:GetMousePos()

function DrawDraggableButton()
	for i, name in ipairs(names) do
		local x = (i-1) % 3 * 100 + 50
		local y = math.floor((i - 1) / 3) * 100 + 50
		
		
		GUI:AddLine(x-30, y-30,60,60)
		GUI:Text(name, x-15,y-6)
		
		if GUI:IsMouseDown() then			
			if mx >= x - 30 and mx <= x + 30 and my >= y - 30 and my <= y + 30 then
				draggedItem = name
				draggedItemIndex = i
			end
		end
	end
	
	if draggedItem then
		GUI:Text(mode .. "" .. draggedItem, mx, my)
	end
end



function SMNOpenQT()
	SMN_Settings.SMN_QT_GUI = not SMN_Settings.SMN_QT_GUI
	smnACR.SaveSettings()
end

-- Quick Toggle Load Color

function SMNLoadQTColor()
local function setColorValue(setting, trueValue, falseValue)
	if setting == true then
		return trueValue
	else
		return falseValue
	end
end

-- CD Color
SMNCDr = setColorValue(SMN_Settings.SMN_CD, 0.3, 0.6)
SMNCDg = setColorValue(SMN_Settings.SMN_CD, 0.55, 0.2)
SMNCDb = setColorValue(SMN_Settings.SMN_CD, 0.14, 0.2)
SMNCDa = 1

-- AOE Color
SMNAOEr = setColorValue(SMN_Settings.SMN_AOE, 0.3, 0.6)
SMNAOEg = setColorValue(SMN_Settings.SMN_AOE, 0.55, 0.2)
SMNAOEb = setColorValue(SMN_Settings.SMN_AOE, 0.14, 0.2)
SMNAOEa = 1

-- Pets Color
SMNPETr = setColorValue(SMN_Settings.SMN_Pets, 0.3, 0.6)
SMNPETg = setColorValue(SMN_Settings.SMN_Pets, 0.55, 0.2)
SMNPETb = setColorValue(SMN_Settings.SMN_Pets, 0.14, 0.2)
SMNPETa = 1

-- Jump Color
SMNJMPr = setColorValue(SMN_Settings.SMN_Jumps, 0.3, 0.6)
SMNJMPg = setColorValue(SMN_Settings.SMN_Jumps, 0.55, 0.2)
SMNJMPb = setColorValue(SMN_Settings.SMN_Jumps, 0.14, 0.2)
SMNJMPa = 1

-- Defensives Color
SMNDEFr = setColorValue(SMN_Settings.SMN_DEF, 0.3, 0.6)
SMNDEFg = setColorValue(SMN_Settings.SMN_DEF, 0.55, 0.2)
SMNDEFb = setColorValue(SMN_Settings.SMN_DEF, 0.14, 0.2)
SMNDEFa = 1
end

-- Quick Toggle Functions

function SMNOpenQT()
	SMN_Settings.SMN_QT_GUI = not SMN_Settings.SMN_QT_GUI
	smnACR.SaveSettings()
end

function SMNCDQTfunc()
	SMN_Settings.SMN_CD = not SMN_Settings.SMN_CD
	SMNCDr, SMNCDg, SMNCDb =
		SMN_Settings.SMN_CD and 0.3 or 0.6,
		SMN_Settings.SMN_CD and 0.55 or 0.2,
		SMN_Settings.SMN_CD and 0.14 or 0.2,
	SMNCDa == 1
	smnACR.SaveSettings()
end

function SMNAOEQTfunc()
	SMN_Settings.SMN_AOE = not SMN_Settings.SMN_AOE
	SMNAOEr, SMNAOEg, SMNAOEb =
		SMN_Settings.SMN_AOE and 0.3 or 0.6,
		SMN_Settings.SMN_AOE and 0.55 or 0.2,
		SMN_Settings.SMN_AOE and 0.14 or 0.2,
	SMNAOEa == 1
	smnACR.SaveSettings()
end

function SMNPETQTfunc()
	SMN_Settings.SMN_Pets = not SMN_Settings.SMN_Pets
	SMNPETr, SMNPETg, SMNPETb =
		SMN_Settings.SMN_Pets and 0.3 or 0.6,
		SMN_Settings.SMN_Pets and 0.55 or 0.2,
		SMN_Settings.SMN_Pets and 0.14 or 0.2,
	SMNPETa == 1
	smnACR.SaveSettings()
end

function SMNJMPQTfunc()
	SMN_Settings.SMN_Jumps = not SMN_Settings.SMN_Jumps
	SMNJMPr, SMNJMPg, SMNJMPb =
		SMN_Settings.SMN_Jumps and 0.3 or 0.6,
		SMN_Settings.SMN_Jumps and 0.55 or 0.2,
		SMN_Settings.SMN_Jumps and 0.14 or 0.2,
	SMNJMPa == 1
	smnACR.SaveSettings()
end

function SMNDEFQTfunc()
	SMN_Settings.SMN_DEF = not SMN_Settings.SMN_DEF
	SMNDEFr, SMNDEFg, SMNDEFb =
		SMN_Settings.SMN_DEF and 0.3 or 0.6,
		SMN_Settings.SMN_DEF and 0.55 or 0.2,
		SMN_Settings.SMN_DEF and 0.14 or 0.2,
	SMNDEFa == 1
	smnACR.SaveSettings()
end

function smnACR:skillID(string)
	if smnACR.smnSkill[string] ~= nil then
		return smnACR.smnSkill[string][1]
	end
end

function smnACR:LastAttackID(string)
	if smnACR:skillID(string) ~= nil then
		if Player.lastcomboid == smnACR:skillID(string) then
			return true
		end
	end
	return false
end

function smnACR:BuffActive(string)
	if smnACR.smnBuff[string] ~= nil then
		if HasBuff(Player.id,smnACR.smnBuff[string]) then
			return true
		end
	end
	return false
end

-- Misc BS
TabIndex = 1

function smnACR.TargetFrom(entity)	
	local targets = MEntityList("alive,attackable,targetable,maxdistance=5,distanceto="..tostring(entity))
	return (table.size(targets))
end

function smnACR.setVar()
	for i,e in pairs(smnACR.smnSkill) do
		smnACR[i] = ActionList:Get(1,e[1])
		if smnACR[i] then
			if e[2] then
				smnACR[i]["isready"] = smnACR[i]:IsReady(MGetTarget().id) else smnACR[i]["isready"] = smnACR[i]:IsReady(Player)
			end
		end
	end
end

function smnACR.useSkill(skl,string)
	local text = (string)
	if text == nil then
		text = MGetTarget()
	end
	for t, abil in pairs(skl) do
		local ACTready = smnACR[abil].isready
		if ACTready then
			smnACR[abil]:Cast(text.id)
			return true
		end
	end
	return false
end

function SMN_oGCDReady()
oGCDisReady = false
WeaveTime = (CD.cdmax/5)*2.75
CDMax = CD.cdmax
	if CD.cd < WeaveTime then
		oGCDisReady = true
	elseif (CD.cd > WeaveTime) or (CD.cd == 0) then
		oGCDisReady = false
	end
end

local function CheckMovement()
Is_Moving = false

	if Player:IsMoving() then
		Is_Moving = true
	end
end

function check4Buncle()
cast_buncle = false
need_buncle = need_buncle or 0

need_buncle = need_buncle + 1

if need_buncle >= 500 then
	cast_buncle = true
end

if (Player.pet) then
	need_buncle = 0
end

end

function SMN_TwoMinCheck()
TwoMinReady = false
BahaReady = false

	if Player.level == 90 then
		if not summonBahamutCD.isoncd then
			BahaReady = true
		elseif summonBahamutCD.isoncd and summonBahamutCD.cd <= 110 then
			BahaReady = true
		end
		if BahaReady then
			TwoMinReady = true
		end
	end
end

function smnACR.Cast()
	local currentTarget = MGetTarget()
	-- Casting Buncle if he's not out already
	if (cast_buncle) and SMN_Settings.SMN_Pets and not Is_Moving then
		ActionList:Get(1,25798):Cast(Player.id)
		return
	end
	if (currentTarget == nil) then
		return false
	end
	local targetRadius = currentTarget.hitradius + 2	
	if (currentTarget.attackable and (gStartCombat or currentTarget.incombat)) then
		smnACR.setVar()
		
		-- Searing Light buff.
		if SMN_Settings.SMN_CD and oGCDisReady and TwoMinReady and smnACR.useSkill({"searinglight"}) then
			d("Attempt to cast Searing Light")
			return true
		end
		
		if SMN_Settings.SMN_DEF and oGCDisReady then
			if (Player.hp.percent <= SMN_Settings.SMN_Addle_Slider) and smnACR.useSkill({"addle"}) then
				return true
			end		
			if not smnACR:BuffActive("radiantaegis") then
				if (Player.hp.percent <= SMN_Settings.SMN_Aegis_Slider) and smnACR.useSkill({"radiantaegis"}, "Player") then
					return true
				end
			end
		end
		if oGCDisReady and (Player.mp.percent <= SMN_Settings.SMN_Lucid_Slider) and smnACR.useSkill({"luciddreaming"}) then
			return true
		end
		
		if (Player.gauge[2] == 0) and SMN_Settings.SMN_Pets and (SearingLightCD.isoncd and SearingLightCD.cd < 110) then
			if smnACR.useSkill({"summonBahamut","dreadwyrmtrance","aethercharge"}) then
				return true
			end
		end
		
		if Player.level < 66 then
			if smnACR.useSkill({"dreadwyrmtrance","aethercharge"}) then
				return true
			end
			if smnACR.TargetFrom(currentTarget.id) > 2 and smnACR.useSkill({"energysiphon"}) then
				return true
			elseif oGCDisReady and smnACR.useSkill({"energydrain"}) then
				return true
			end
		end
		
		if (Player.gauge[2] == 0) and SMN_Settings.SMN_Pets then
			if smnACR.useSkill({"summonPhoenix"}) then
				return
			end
			-- Order 1
			if (Player.gauge[5] == 1) and smnACR.summonOrder.Summons[1] == "Ifrit" then
				if smnACR.useSkill({"summonIfrit","summonIfritII","summonRuby"}) then
					return true
				end
			elseif (Player.gauge[6] == 1) and smnACR.summonOrder.Summons[1] == "Titan" then			
				if smnACR.useSkill({"summonTitan","summonTitanII","summonTopaz"}) then
					return true
				end
			elseif (Player.gauge[7] == 1) and smnACR.summonOrder.Summons[1] == "Garuda" then				
				if smnACR.useSkill({"summonGaruda","summonGarudaII","summonEmerald"}) then
					return true
				end
			end
			-- Order 2
			if (Player.gauge[5] == 1) and smnACR.summonOrder.Summons[2] == "Ifrit" then
				if smnACR.useSkill({"summonIfrit","summonIfritII","summonRuby"}) then
					return true
				end
			elseif (Player.gauge[6] == 1) and smnACR.summonOrder.Summons[2] == "Titan" then			
				if smnACR.useSkill({"summonTitan","summonTitanII","summonTopaz"}) then
					return true
				end
			elseif (Player.gauge[7] == 1) and smnACR.summonOrder.Summons[2] == "Garuda" then				
				if smnACR.useSkill({"summonGaruda","summonGarudaII","summonEmerald"}) then
					return true
				end
			end
			-- Order 3
			if (Player.gauge[5] == 1) and smnACR.summonOrder.Summons[3] == "Ifrit" then
				if smnACR.useSkill({"summonIfrit","summonIfritII","summonRuby"}) then
					return true
				end
			elseif (Player.gauge[6] == 1) and smnACR.summonOrder.Summons[3] == "Titan" then			
				if smnACR.useSkill({"summonTitan","summonTitanII","summonTopaz"}) then
					return true
				end
			elseif (Player.gauge[7] == 1) and smnACR.summonOrder.Summons[3] == "Garuda" then				
				if smnACR.useSkill({"summonGaruda","summonGarudaII","summonEmerald"}) then
					return true
				end
			end
		end
		
		-- Bahamut and Phoenix Shit
		if (Player.gauge[1] > 0) then
			if oGCDisReady and smnACR.useSkill({"deathflare","enkindleBahamut","enkindlePhoenix"}) then
				return true
			end
			if SMN_Settings.SMN_AOE and smnACR.TargetFrom(currentTarget.id) > 2 then
				if smnACR.useSkill({"astralflare","phoenixaoe"}) then
					return true
				end
			else
				if smnACR.useSkill({"astralimpulse","phoenixsingle"}) then
					return true
				end
			end
		end
		-- Ifrit Shit
		if (Player.gauge[9] == 1) or smnACR:BuffActive("IfritFavour") then
			if SMN_Settings.SMN_Jumps and smnACR.useSkill({"crimsoncyclone","crimsonstrike"}) then
				return true
			end
			if SMN_Settings.SMN_AOE and smnACR.TargetFrom(currentTarget.id) > 2 then
				if (not Is_Moving) and Player.gauge[3] > 0 and smnACR.useSkill({"rubycatastrophe"}) then
					return true
				end
			else
				if (not Is_Moving) and Player.gauge[3] > 0 and smnACR.useSkill({"rubyRite","rubyruin3"}) then
					return true
				end
			end
		end
		
		--Titan Shit
		if (Player.gauge[9] == 2) or smnACR:BuffActive("TitanFavour") then
			if smnACR.useSkill({"mountainbuster"}) then
				return true
			end
			if SMN_Settings.SMN_AOE and smnACR.TargetFrom(currentTarget.id) > 2 then
				if Player.gauge[3] > 0 and smnACR.useSkill({"topazcatastrophe"}) then
					return true
				end
			else
				if Player.gauge[3] > 0 and smnACR.useSkill({"topazRite","topazruin3"}) then
					return true
				end
			end
		end
		
		--Garuwuda Shit
		if Player.gauge[9] == 3 or smnACR:BuffActive("GarudaFavour") then
			if (not Is_Moving) and smnACR.useSkill({"slipstream"}) then
				return true
			end
			if SMN_Settings.SMN_AOE and smnACR.TargetFrom(currentTarget.id) > 2 then
				if Player.gauge[3] > 0 and smnACR.useSkill({"emeraldcatastrophe"}) then
					return true
				end
			else
				if Player.gauge[3] > 0 and smnACR.useSkill({"emeraldRite","emeraldruin3"}) then
					return true
				end
			end
		end
		
		if SMN_Settings.SMN_AOE and smnACR.TargetFrom(currentTarget.id) > 2 then
			if oGCDisReady and (SearingLightCD.isoncd and SearingLightCD.cd <= 110) and smnACR.useSkill({"energysiphon"}) then
				return true
			end
		else
			if oGCDisReady and (SearingLightCD.isoncd and SearingLightCD.cd <= 110) and smnACR.useSkill({"energydrain"}) then
				return true
			end
		end
		
		
		if SMN_Settings.SMN_AOE and smnACR.TargetFrom(currentTarget.id) > 2 then
			if oGCDisReady and smnACR.useSkill({"painflare"}) then
				return true
			end
		else
			if oGCDisReady and smnACR.useSkill({"fester"}) then
				return true
			end
		end

		if Is_Moving and (not smnACR:BuffActive("furtherruin")) and (not oGCDisReady) and smnACR.useSkill({"fester"}) then
			return true
		end
		
		-- Use Ruin4 if EG is about to come off CD
		if (EnergyDrainCD.isoncd and EnergyDrainCD.cd >= 45) and smnACR.useSkill({"ruin4"}) then
			return true
		end
		
		-- Ruin Spam
		
		if SMN_Settings.SMN_AOE and smnACR.TargetFrom(currentTarget.id) > 2 then
			if (not Is_Moving) then
				if smnACR.useSkill({"outburst","tridisaster"}) then
					return true
				end
			else
				if smnACR:BuffActive("furtherruin") and smnACR.useSkill({"ruin4"}) then
					return true
				end
			end
		else
			if (not Is_Moving) then
				if smnACR.useSkill({"ruin","ruin3"}) then
					return true
				end
			else
				if smnACR:BuffActive("furtherruin") and smnACR.useSkill({"ruin4"}) then
					return true
				end
			end
		end
		
	return false
	end
end

function smnACR.Draw()
	if (smnACR.GUI.open) then
	smnACR.GUI.visible, smnACR.GUI.open = GUI:Begin(smnACR.GUI.name, smnACR.GUI.open, GUI.WindowFlags_NoResize)
	if (smnACR.GUI.visible) then
		GUI:Button("Main",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 1
		end
		GUI:SameLine()
		GUI:Button("Defensives",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 2
		end
		GUI:SameLine()
		GUI:Button("Toggles",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 3
		end
		GUI:SameLine()
		GUI:Button("Discord",80,30)
		if GUI:IsItemClicked() then
			TabIndex = 4
			discordLink = ("Click for link")
		end
		
		-- Tabs
		
		--Main Tab
			if (TabIndex == 1) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:BulletText("Wxlfee's Summoner ACR")
				GUI:Text("0.7.4 Changelogs:")
				GUI:Text("L60 tested.")
				GUI:Text("Currently Missing L60 Summon's AOE")
				GUI:Text("attacks.")
				GUI:Text("_________________________________________________")
				-- if oGCDisReady then
					-- weavecheck = "True"
				-- else
					-- weavecheck = "False"
				-- end
				-- GUI:Text("Weaving Ready: "..weavecheck)
				-- GUI:Text("_________________________________________________")
			end
		--Defensives Tab
			if (TabIndex == 2) then
				GUI:SetWindowSize(367,184,0)
				GUI:Text("_________________________________________________")
				GUI:Text("Lucid Dreaming")
				SMN_Settings.SMN_Lucid_Slider, lucid = GUI:SliderInt("%", SMN_Settings.SMN_Lucid_Slider,0,100)
				if lucid then
					d(SMN_Settings.SMN_Lucid_Slider)
					SMN_Settings.SMN_Lucid_Slider =	SMN_Settings.SMN_Lucid_Slider
					smnACR.SaveSettings()
				end
				GUI:Text("_________________________________________________")
				GUI:Text("Addle")
				SMN_Settings.SMN_Addle_Slider, addle = GUI:SliderInt("HP%", SMN_Settings.SMN_Addle_Slider,0,100)
				if addle then
					d(SMN_Settings.SMN_Addle_Slider)
					SMN_Settings.SMN_Addle_Slider =	SMN_Settings.SMN_Addle_Slider
					smnACR.SaveSettings()
				end
				GUI:Text("_________________________________________________")
				GUI:Text("Radiant Aegis")
				SMN_Settings.SMN_Aegis_Slider, aegis = GUI:SliderInt("HP%##", SMN_Settings.SMN_Aegis_Slider,0,100)
				if aegis then
					d(SMN_Settings.SMN_Aegis_Slider)
					SMN_Settings.SMN_Aegis_Slider = SMN_Settings.SMN_Aegis_Slider
					smnACR.SaveSettings()
				end
				GUI:Text("_________________________________________________")
			end
			if (TabIndex == 3) then
				GUI:SetWindowSize(0,0,0)
				GUI:Text("_________________________________________________")
				GUI:Button("Open Quick Toggles",344,25)
				if GUI:IsItemClicked() then
					SMNOpenQT()
				end				
			end
			if (TabIndex == 4) then
				GUI:SetWindowSize(0,0,0)				
				GUI:Text("_________________________________________________")				
				GUI:MenuItem(discordLink)
				if GUI:IsItemClicked() then
					GUI:SetClipboardText("discord.gg/ykQanPZtHE")
					discordLink = ("Link copied, paste in browser")
				end
				GUI:Text("_________________________________________________")
			end
		
		end
		GUI:End()
		
		if (SMN_Settings.SMN_QT_GUI) then
		local flags2 = (GUI.WindowFlags_NoResize + GUI.WindowFlags_NoScrollbar + GUI.WindowFlags_NoScrollWithMouse + GUI.WindowFlags_NoCollapse + GUI.WindowFlags_NoTitleBar)
			smnACR.GUIQT.visible, smnACR.GUIQT.open = GUI:Begin(smnACR.GUIQT.name, smnACR.GUIQT.open, flags2)
			if (smnACR.GUIQT.visible) then
				GUI:SetWindowSize(0,0,0)
				GUI:PushStyleColor(GUI.Col_Button, SMNCDr, SMNCDg, SMNCDb, SMNCDa)
				SMNCDButton = GUI:Button("CD",90,30)
				GUI:PopStyleColor()
				if GUI:IsItemClicked() then
					SMNCDQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, SMNAOEr, SMNAOEg, SMNAOEb, SMNAOEa)
				SMNAOEButton = GUI:Button("AOE",90,30)
				GUI:PopStyleColor()
				if GUI:IsItemClicked() then
					SMNAOEQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, SMNDEFr, SMNDEFg, SMNDEFb, SMNDEFa)
				SMNDEFButton = GUI:Button("Defensives",90,30)
				GUI:PopStyleColor()
				if GUI:IsItemClicked() then
					SMNDEFQTfunc()
				end
				GUI:PushStyleColor(GUI.Col_Button, SMNPETr, SMNPETg, SMNPETb, SMNPETa)
				SMNSTCButton = GUI:Button("Pets",90,30)
				GUI:PopStyleColor()
				if GUI:IsItemClicked() then
					SMNPETQTfunc()
				end
				GUI:SameLine()
				GUI:PushStyleColor(GUI.Col_Button, SMNJMPr, SMNJMPg, SMNJMPb, SMNJMPa)
				SMNJMPButton = GUI:Button("Jumps",90,30)
				GUI:PopStyleColor()
				if GUI:IsItemClicked() then
					SMNJMPQTfunc()
				end
				GUI:Separator()
				local tsize = table.size(smnACR.summonOrder.Summons)
				if smnACR.summonOrder.pos ~= 0 and smnACR.summonOrder.lastPos ~= -1 and (GUI:IsMouseReleased(0) or not GUI:IsMouseDown(0)) then
					local insertPos = smnACR.summonOrder.lastPos
					if (insertPos == 0) then
						insertPos = 1
					elseif (insertPos > tsize) then
						insertPos = tsize
					else
						-- If moving lower, all items will shift up one, must correct.
						if (insertPos > smnACR.summonOrder.pos) then
							insertPos = insertPos - 1
						end
					end
					
					-- Check that the logic makes sense with the separator placement.
					if (math.abs(insertPos-smnACR.summonOrder.pos) > 0) then
						local move = smnACR.summonOrder.Summons[smnACR.summonOrder.pos]
						table.remove(smnACR.summonOrder.Summons,smnACR.summonOrder.pos)
						table.insert(smnACR.summonOrder.Summons,insertPos,move)
					end
					
					-- Process the release, regardless if smnACR.summonOrder changes were done.
					smnACR.summonOrder.pos = 0
					smnACR.summonOrder.lastPos = -1
				end
				
				local startPos,newPos = 0,-1

				local itemspacingx = GUI:GetStyle().itemspacing.x
				
				if (smnACR.summonOrder.lastPos == 1) then
					--GUI:Separator()
				end
					
				for i=1,tsize do
					local dragging = (smnACR.summonOrder.pos == i)
					if smnACR.summonOrder.Summons[i] == "Ifrit" then
						GUI:PushStyleColor(GUI.Col_Button, 0.7,0.2,0.2,1)
					end
					if smnACR.summonOrder.Summons[i] == "Titan" then
						GUI:PushStyleColor(GUI.Col_Button, 0.6,0.3,0,1)
					end
					if smnACR.summonOrder.Summons[i] == "Garuda" then
						GUI:PushStyleColor(GUI.Col_Button,0.1,0.5,0.1,1)
					end
					GUI:Button(smnACR.summonOrder.Summons[i], 90, 30)
					GUI:SameLine()
					if smnACR.summonOrder.Summons[i] == "Ifrit" then
						GUI:PopStyleColor(1)
					end
					if smnACR.summonOrder.Summons[i] == "Titan" then
						GUI:PopStyleColor(1)
					end
					if smnACR.summonOrder.Summons[i] == "Garuda" then
						GUI:PopStyleColor(1)
					end
					if GUI:IsItemHovered(GUI.HoveredFlags_AllowWhenBlockedByPopup + GUI.HoveredFlags_AllowWhenBlockedByActiveItem + GUI.HoveredFlags_AllowWhenOverlapped) then
						local minx,miny = GUI:GetItemRectMin()
						local maxx,maxy = GUI:GetItemRectMax()
						local sizex,sizey = GUI:GetItemRectSize()
						local mousex,mousey = GUI:GetMousePos()
						
						if GUI:IsMouseDragging(0) then
							if smnACR.summonOrder.pos == 0 then
								startPos = i
							else
								if smnACR.summonOrder.pos ~= i then
									newPos = CalculateNewPosition(mousex, minx, maxx, sizex, i, tsize)
								end
							end
						end
					end
					
					if (i == (smnACR.summonOrder.lastPos - 1)) then
						--GUI:Separator()
					end
				end
				
				if (startPos ~= 0) then
					smnACR.summonOrder.pos = startPos
				end
				if (newPos ~= -1) then
					smnACR.summonOrder.lastPos = newPos
				end
					
				end
		GUI:End()
	end
end
end

function smnACR.OnOpen()
	smnACR.GUI.open = true
end

function smnACR.QTOnOpen()
	smnACR.GUIQT.open = true
end

function smnACR.SaveSettings()
	d("[WxlfeeCore] Settings have been saved.")
	WXSave()
end

function validDepth(...)
    local tbl = {...}
    local size = #tbl
    if size > 0 then
        local count = tbl[1]
        if type(count) == "number" then
            if size == (count + 1) then
                for i = 2, size do
                    if not v(tbl[i]) then return false end
                end
                return true
            end
        else
            for i = 1, size do
                if not v(tbl[i]) then return false end
            end
            return true
        end
    end
    return false
end

function SMNloadsettings(tbl)
    local tbl = FileLoad(ModuleSettings)
    local function scan(tbl,tbl2,depth)
        depth = depth or 0
        if validDepth(2,tbl,tbl2) then
            for k,v in pairs(tbl2) do
                if type(v) == "table" then
                    if tbl[k] and validDepth(tbl[k]) then
                        tbl[k] = table.merge(tbl[k],scan(tbl[k],v,depth+1))
                    else
                        tbl[k] = v
                    end
                else
                    if tbl[k] ~= tbl2[k] then tbl[k] = tbl2[k] end
                end
            end
        end
        return tbl
    end
    SMN_Settings = scan(SMN_Settings,tbl)
end

function smnACR.LoadSettings()
	SMNloadsettings(tbl)
end

function smnACR.OnLoad()
	checkFile()
	TabIndex = 1
	smnACR.LoadSettings()
	SMNLoadQTColor()	
end

function smnACR.OnClick(mouse, shiftState, controlState,altState,entity)

end

function smnACR.OnUpdate(event, tickcount)
	SMN_oGCDReady()
	CheckMovement()
	check4Buncle()
	SMN_TwoMinCheck()
end

return smnACR